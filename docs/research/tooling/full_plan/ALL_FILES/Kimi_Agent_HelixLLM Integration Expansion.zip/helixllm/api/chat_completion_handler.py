"""
Chat completion handler for HelixLLM API.

Handles /v1/chat/completions endpoint.
"""

import time
import uuid
from typing import Any, AsyncIterator, Dict, List, Optional, Union
import logging

from ..core.helix_llm import HelixLLM
from ..core.chat_session import ChatSession
from .streaming_response import StreamingResponse


class ChatCompletionHandler:
    """
    Handles chat completion API requests.
    
    Processes chat completion requests in OpenAI-compatible format,
    supporting both streaming and non-streaming responses.
    
    Attributes:
        helix: HelixLLM instance
    
    Example:
        >>> handler = ChatCompletionHandler(helix)
        >>> response = await handler.create_chat_completion(request)
    """
    
    def __init__(
        self,
        helix: HelixLLM,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize chat completion handler.
        
        Args:
            helix: HelixLLM instance
            logger: Optional logger
        """
        self.helix = helix
        self.logger = logger or logging.getLogger(__name__)
    
    async def create_chat_completion(
        self,
        request: Dict[str, Any],
    ) -> Union[Dict[str, Any], AsyncIterator[str]]:
        """
        Create a chat completion.
        
        Args:
            request: OpenAI-compatible request
        
        Returns:
            Response or streaming iterator
        """
        # Extract request parameters
        model = request.get("model", "default")
        messages = request.get("messages", [])
        stream = request.get("stream", False)
        temperature = request.get("temperature")
        max_tokens = request.get("max_tokens")
        top_p = request.get("top_p")
        stop = request.get("stop")
        
        # Generate request ID
        request_id = f"chatcmpl-{uuid.uuid4().hex}"
        created = int(time.time())
        
        self.logger.info(f"Chat completion request: model={model}, stream={stream}")
        
        # Check if model is loaded
        if not self.helix.model_manager.is_loaded:
            return self._create_error_response(
                "No model loaded",
                "invalid_request_error",
            )
        
        # Create session from messages
        session = self._create_session_from_messages(messages)
        
        # Get last user message
        last_message = self._get_last_user_message(messages)
        
        if not last_message:
            return self._create_error_response(
                "No user message found",
                "invalid_request_error",
            )
        
        if stream:
            # Return streaming response
            return self._stream_response(
                session=session,
                message=last_message,
                model=model,
                request_id=request_id,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p,
                stop=stop,
            )
        else:
            # Return complete response
            return self._complete_response(
                session=session,
                message=last_message,
                model=model,
                request_id=request_id,
                created=created,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p,
                stop=stop,
            )
    
    def _create_session_from_messages(
        self,
        messages: List[Dict[str, str]],
    ) -> ChatSession:
        """Create a chat session from message list."""
        # Extract system prompt
        system_prompt = None
        for msg in messages:
            if msg.get("role") == "system":
                system_prompt = msg.get("content")
                break
        
        # Create session
        session = self.helix.create_session(system_prompt=system_prompt)
        
        # Add messages to session
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content", "")
            
            if role == "user":
                session.add_user_message(content)
            elif role == "assistant":
                session.add_assistant_message(content)
        
        return session
    
    def _get_last_user_message(self, messages: List[Dict[str, str]]) -> Optional[str]:
        """Get the last user message."""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                return msg.get("content")
        return None
    
    def _complete_response(
        self,
        session: ChatSession,
        message: str,
        model: str,
        request_id: str,
        created: int,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stop: Optional[Union[str, List[str]]] = None,
    ) -> Dict[str, Any]:
        """Generate complete response."""
        try:
            # Generate response
            response_text = self.helix.chat(
                message=message,
                session=session,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p,
                stop_sequences=[stop] if isinstance(stop, str) else stop,
            )
            
            # Estimate token usage
            prompt_tokens = self.helix.model_manager.count_tokens(
                session.get_history_text()
            )
            completion_tokens = self.helix.model_manager.count_tokens(response_text)
            
            return {
                "id": request_id,
                "object": "chat.completion",
                "created": created,
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": response_text,
                        },
                        "finish_reason": "stop",
                    }
                ],
                "usage": {
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": prompt_tokens + completion_tokens,
                },
            }
            
        except Exception as e:
            self.logger.error(f"Chat completion failed: {e}")
            return self._create_error_response(str(e), "internal_error")
    
    def _stream_response(
        self,
        session: ChatSession,
        message: str,
        model: str,
        request_id: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stop: Optional[Union[str, List[str]]] = None,
    ) -> AsyncIterator[str]:
        """Generate streaming response."""
        
        async def generate():
            try:
                # Stream response
                for chunk in self.helix.chat_stream(
                    message=message,
                    session=session,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    top_p=top_p,
                    stop_sequences=[stop] if isinstance(stop, str) else stop,
                ):
                    yield StreamingResponse.create_chat_completion_chunk(
                        content=chunk,
                        model=model,
                        request_id=request_id,
                    )
                
                # Send final chunk with finish_reason
                yield StreamingResponse.create_chat_completion_chunk(
                    content="",
                    model=model,
                    request_id=request_id,
                    finish_reason="stop",
                )
                
                # Send done marker
                yield StreamingResponse.format_done()
                
            except Exception as e:
                self.logger.error(f"Streaming failed: {e}")
                yield StreamingResponse.create_error_chunk(str(e))
        
        return generate()
    
    def _create_error_response(
        self,
        message: str,
        error_type: str,
        code: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create error response."""
        return {
            "error": {
                "message": message,
                "type": error_type,
                "code": code,
            }
        }
    
    def validate_request(self, request: Dict[str, Any]) -> List[str]:
        """
        Validate a chat completion request.
        
        Args:
            request: Request dictionary
        
        Returns:
            List of validation errors
        """
        errors = []
        
        # Check messages
        messages = request.get("messages")
        if not messages:
            errors.append("messages is required")
        elif not isinstance(messages, list):
            errors.append("messages must be a list")
        else:
            for i, msg in enumerate(messages):
                if not isinstance(msg, dict):
                    errors.append(f"message[{i}] must be an object")
                elif "role" not in msg:
                    errors.append(f"message[{i}] must have a 'role' field")
                elif "content" not in msg:
                    errors.append(f"message[{i}] must have a 'content' field")
        
        # Validate temperature
        temperature = request.get("temperature")
        if temperature is not None:
            if not isinstance(temperature, (int, float)):
                errors.append("temperature must be a number")
            elif temperature < 0 or temperature > 2:
                errors.append("temperature must be between 0 and 2")
        
        # Validate max_tokens
        max_tokens = request.get("max_tokens")
        if max_tokens is not None:
            if not isinstance(max_tokens, int):
                errors.append("max_tokens must be an integer")
            elif max_tokens <= 0:
                errors.append("max_tokens must be positive")
        
        # Validate top_p
        top_p = request.get("top_p")
        if top_p is not None:
            if not isinstance(top_p, (int, float)):
                errors.append("top_p must be a number")
            elif top_p < 0 or top_p > 1:
                errors.append("top_p must be between 0 and 1")
        
        return errors
