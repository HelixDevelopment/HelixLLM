"""
Model handler for HelixLLM API.

Handles /v1/models endpoint for listing available models.
"""

import time
from typing import Any, Dict, List, Optional
import logging

from ..core.helix_llm import HelixLLM


class ModelHandler:
    """
    Handles model-related API endpoints.
    
    Provides model listing and information in OpenAI-compatible format.
    
    Attributes:
        helix: HelixLLM instance
    
    Example:
        >>> handler = ModelHandler(helix)
        >>> models = handler.list_models()
    """
    
    def __init__(
        self,
        helix: HelixLLM,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize model handler.
        
        Args:
            helix: HelixLLM instance
            logger: Optional logger
        """
        self.helix = helix
        self.logger = logger or logging.getLogger(__name__)
    
    def list_models(self) -> Dict[str, Any]:
        """
        List available models.
        
        Returns:
            OpenAI-compatible models list
        """
        models = []
        
        # Add currently loaded model
        if self.helix.model_manager.is_loaded:
            model_info = self.helix.model_manager.model_info
            if model_info:
                models.append({
                    "id": model_info.name,
                    "object": "model",
                    "created": int(model_info.loaded_at),
                    "owned_by": "helixllm",
                    "permission": [],
                    "root": model_info.name,
                    "parent": None,
                })
        
        # Add configured model even if not loaded
        if not models and self.helix.config.model.path:
            model_name = self._extract_model_name(self.helix.config.model.path)
            models.append({
                "id": model_name,
                "object": "model",
                "created": int(time.time()),
                "owned_by": "helixllm",
                "permission": [],
                "root": model_name,
                "parent": None,
            })
        
        return {
            "object": "list",
            "data": models,
        }
    
    def get_model(self, model_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific model.
        
        Args:
            model_id: Model ID
        
        Returns:
            Model information or None
        """
        models = self.list_models()
        
        for model in models.get("data", []):
            if model.get("id") == model_id:
                return model
        
        return None
    
    def model_exists(self, model_id: str) -> bool:
        """
        Check if a model exists.
        
        Args:
            model_id: Model ID
        
        Returns:
            True if model exists
        """
        return self.get_model(model_id) is not None
    
    def _extract_model_name(self, path: str) -> str:
        """Extract model name from path."""
        from pathlib import Path
        return Path(path).stem
    
    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        Get detailed model information.
        
        Args:
            model_id: Model ID
        
        Returns:
            Detailed model information
        """
        model = self.get_model(model_id)
        
        if not model:
            return {
                "error": {
                    "message": f"Model '{model_id}' not found",
                    "type": "invalid_request_error",
                    "code": "model_not_found",
                }
            }
        
        # Add additional info if model is loaded
        if self.helix.model_manager.is_loaded:
            model_info = self.helix.model_manager.model_info
            if model_info and model_info.name == model_id:
                model.update({
                    "context_length": model_info.context_length,
                    "vocab_size": model_info.vocab_size,
                    "embedding_length": model_info.embedding_length,
                })
        
        return model
