"""
OpenAI-compatible API server for HelixLLM.

FastAPI-based server providing OpenAI-compatible endpoints.
"""

from typing import Any, Dict, List, Optional
import logging
import uuid

try:
    from fastapi import FastAPI, HTTPException, Request, Depends
    from fastapi.responses import StreamingResponse as FastAPIStreamingResponse
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel, Field
    from uvicorn import Config, Server
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    FastAPI = None
    BaseModel = object

from ..core.helix_llm import HelixLLM
from ..core.configuration import Configuration
from .chat_completion_handler import ChatCompletionHandler
from .model_handler import ModelHandler
from .streaming_response import StreamingResponse


# Pydantic models for request/response
class ChatMessage(BaseModel):
    """Chat message model."""
    role: str
    content: str
    name: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    """Chat completion request model."""
    model: str = "default"
    messages: List[ChatMessage]
    temperature: Optional[float] = Field(default=0.7, ge=0, le=2)
    top_p: Optional[float] = Field(default=1.0, ge=0, le=1)
    n: Optional[int] = Field(default=1, ge=1, le=10)
    stream: Optional[bool] = False
    stop: Optional[Union[str, List[str]]] = None
    max_tokens: Optional[int] = Field(default=None, ge=1)
    presence_penalty: Optional[float] = Field(default=0, ge=-2, le=2)
    frequency_penalty: Optional[float] = Field(default=0, ge=-2, le=2)
    user: Optional[str] = None


class ChatCompletionChoice(BaseModel):
    """Chat completion choice model."""
    index: int
    message: ChatMessage
    finish_reason: Optional[str] = None


class ChatCompletionResponse(BaseModel):
    """Chat completion response model."""
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: Dict[str, int]


class ModelInfo(BaseModel):
    """Model information model."""
    id: str
    object: str = "model"
    created: int
    owned_by: str


class ModelListResponse(BaseModel):
    """Model list response model."""
    object: str = "list"
    data: List[ModelInfo]


class OpenAICompatibleAPI:
    """
    OpenAI-compatible API server for HelixLLM.
    
    Provides FastAPI-based endpoints compatible with OpenAI's API:
    - POST /v1/chat/completions
    - GET /v1/models
    - GET /health
    
    Attributes:
        helix: HelixLLM instance
        app: FastAPI application
        config: Server configuration
    
    Example:
        >>> api = OpenAICompatibleAPI(helix)
        >>> api.run(host="0.0.0.0", port=8000)
    """
    
    def __init__(
        self,
        helix: HelixLLM,
        config: Optional[Configuration] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize API server.
        
        Args:
            helix: HelixLLM instance
            config: Server configuration
            logger: Optional logger
        """
        if not FASTAPI_AVAILABLE:
            raise ImportError(
                "FastAPI is required for API server. "
                "Install with: pip install fastapi uvicorn"
            )
        
        self.helix = helix
        self.config = config or helix.config
        self.logger = logger or logging.getLogger(__name__)
        
        # Initialize handlers
        self.chat_handler = ChatCompletionHandler(helix, self.logger)
        self.model_handler = ModelHandler(helix, self.logger)
        
        # Create FastAPI app
        self.app = self._create_app()
        
        self.logger.info("OpenAI-compatible API initialized")
    
    def _create_app(self) -> FastAPI:
        """Create and configure FastAPI application."""
        app = FastAPI(
            title="HelixLLM API",
            description="OpenAI-compatible API for HelixLLM",
            version="1.0.0",
        )
        
        # Add CORS middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self.config.api.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # Register routes
        self._register_routes(app)
        
        return app
    
    def _register_routes(self, app: FastAPI) -> None:
        """Register API routes."""
        
        @app.get("/health")
        async def health():
            """Health check endpoint."""
            return self.helix.health_check()
        
        @app.get("/v1/models", response_model=ModelListResponse)
        async def list_models():
            """List available models."""
            return self.model_handler.list_models()
        
        @app.get("/v1/models/{model_id}")
        async def get_model(model_id: str):
            """Get model information."""
            model = self.model_handler.get_model(model_id)
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")
            return model
        
        @app.post("/v1/chat/completions")
        async def create_chat_completion(request: ChatCompletionRequest):
            """Create chat completion."""
            # Convert to dict
            request_dict = request.dict(exclude_none=True)
            
            # Validate request
            errors = self.chat_handler.validate_request(request_dict)
            if errors:
                raise HTTPException(
                    status_code=400,
                    detail={"errors": errors},
                )
            
            # Process request
            response = await self.chat_handler.create_chat_completion(request_dict)
            
            # Handle streaming
            if request.stream:
                return FastAPIStreamingResponse(
                    response,
                    media_type="text/event-stream",
                )
            
            return response
        
        @app.post("/v1/completions")
        async def create_completion(request: Dict[str, Any]):
            """Create completion (legacy endpoint)."""
            # Convert to chat completion format
            prompt = request.get("prompt", "")
            chat_request = {
                "model": request.get("model", "default"),
                "messages": [{"role": "user", "content": prompt}],
                "temperature": request.get("temperature"),
                "max_tokens": request.get("max_tokens"),
                "top_p": request.get("top_p"),
                "stream": request.get("stream", False),
                "stop": request.get("stop"),
            }
            
            response = await self.chat_handler.create_chat_completion(chat_request)
            
            if request.get("stream"):
                return FastAPIStreamingResponse(
                    response,
                    media_type="text/event-stream",
                )
            
            # Convert chat completion to legacy format
            if "choices" in response:
                response["choices"] = [
                    {
                        "text": choice.get("message", {}).get("content", ""),
                        "index": choice.get("index", 0),
                        "finish_reason": choice.get("finish_reason"),
                    }
                    for choice in response["choices"]
                ]
            
            return response
        
        @app.get("/v1/stats")
        async def get_stats():
            """Get system statistics."""
            return self.helix.get_stats()
    
    def run(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        **kwargs,
    ) -> None:
        """
        Run the API server.
        
        Args:
            host: Host to bind to
            port: Port to bind to
            **kwargs: Additional uvicorn arguments
        """
        host = host or self.config.api.host
        port = port or self.config.api.port
        
        self.logger.info(f"Starting API server on {host}:{port}")
        
        import uvicorn
        uvicorn.run(
            self.app,
            host=host,
            port=port,
            **kwargs,
        )
    
    async def run_async(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        **kwargs,
    ) -> None:
        """
        Run the API server asynchronously.
        
        Args:
            host: Host to bind to
            port: Port to bind to
            **kwargs: Additional uvicorn arguments
        """
        host = host or self.config.api.host
        port = port or self.config.api.port
        
        self.logger.info(f"Starting API server on {host}:{port}")
        
        config = Config(
            app=self.app,
            host=host,
            port=port,
            **kwargs,
        )
        server = Server(config)
        await server.serve()
    
    def get_app(self) -> FastAPI:
        """
        Get the FastAPI application.
        
        Returns:
            FastAPI application instance
        """
        return self.app


# Type hint for Union
from typing import Union
