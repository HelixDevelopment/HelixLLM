"""
Streaming response for HelixLLM API.

Server-Sent Events (SSE) implementation for streaming responses.
"""

import json
import time
from typing import Any, AsyncIterator, Dict, Iterator, Optional, Union
import asyncio


class StreamingResponse:
    """
    Server-Sent Events (SSE) streaming response.
    
    Formats and yields SSE events for streaming LLM responses.
    
    Attributes:
        data_iterator: Iterator of response chunks
        event_type: SSE event type
    
    Example:
        >>> async for chunk in StreamingResponse.stream_chat_completion(generator):
        ...     yield chunk
    """
    
    SSE_PREFIX = "data: "
    SSE_SUFFIX = "\n\n"
    DONE_MARKER = "[DONE]"
    
    def __init__(
        self,
        data_iterator: Union[Iterator[Any], AsyncIterator[Any]],
        event_type: Optional[str] = None,
    ):
        """
        Initialize streaming response.
        
        Args:
            data_iterator: Iterator of response data
            event_type: SSE event type
        """
        self.data_iterator = data_iterator
        self.event_type = event_type
    
    @classmethod
    def format_sse(
        cls,
        data: Any,
        event_type: Optional[str] = None,
    ) -> str:
        """
        Format data as SSE event.
        
        Args:
            data: Data to format
            event_type: Optional event type
        
        Returns:
            Formatted SSE string
        """
        lines = []
        
        if event_type:
            lines.append(f"event: {event_type}")
        
        # Convert data to JSON string
        if isinstance(data, str):
            data_str = data
        else:
            data_str = json.dumps(data)
        
        # Split multi-line data
        for line in data_str.split("\n"):
            lines.append(f"{cls.SSE_PREFIX}{line}")
        
        lines.append("")  # Empty line before suffix
        
        return "\n".join(lines) + cls.SSE_SUFFIX
    
    @classmethod
    def format_done(cls) -> str:
        """Format the SSE done marker."""
        return cls.format_sse(cls.DONE_MARKER)
    
    @classmethod
    async def stream_chat_completion(
        cls,
        chunk_generator: AsyncIterator[Dict[str, Any]],
        model: str,
        request_id: str,
    ) -> AsyncIterator[str]:
        """
        Stream chat completion in OpenAI format.
        
        Args:
            chunk_generator: Generator of response chunks
            model: Model name
            request_id: Request ID
        
        Yields:
            SSE formatted chunks
        """
        created = int(time.time())
        
        async for chunk in chunk_generator:
            # Format in OpenAI streaming format
            response_chunk = {
                "id": request_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {
                            "content": chunk.get("text", ""),
                        },
                        "finish_reason": chunk.get("finish_reason"),
                    }
                ],
            }
            
            yield cls.format_sse(response_chunk)
            
            if chunk.get("is_finished"):
                break
        
        yield cls.format_done()
    
    @classmethod
    def stream_chat_completion_sync(
        cls,
        chunk_generator: Iterator[Dict[str, Any]],
        model: str,
        request_id: str,
    ) -> Iterator[str]:
        """
        Synchronous streaming chat completion.
        
        Args:
            chunk_generator: Generator of response chunks
            model: Model name
            request_id: Request ID
        
        Yields:
            SSE formatted chunks
        """
        created = int(time.time())
        
        for chunk in chunk_generator:
            response_chunk = {
                "id": request_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {
                            "content": chunk.get("text", ""),
                        },
                        "finish_reason": chunk.get("finish_reason"),
                    }
                ],
            }
            
            yield cls.format_sse(response_chunk)
            
            if chunk.get("is_finished"):
                break
        
        yield cls.format_done()
    
    @classmethod
    def create_chat_completion_chunk(
        cls,
        content: str,
        model: str,
        request_id: str,
        finish_reason: Optional[str] = None,
    ) -> str:
        """
        Create a single chat completion chunk.
        
        Args:
            content: Response content
            model: Model name
            request_id: Request ID
            finish_reason: Optional finish reason
        
        Returns:
            SSE formatted chunk
        """
        chunk = {
            "id": request_id,
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "delta": {
                        "content": content,
                    },
                    "finish_reason": finish_reason,
                }
            ],
        }
        
        return cls.format_sse(chunk)
    
    @classmethod
    def create_completion_chunk(
        cls,
        text: str,
        model: str,
        request_id: str,
        finish_reason: Optional[str] = None,
    ) -> str:
        """
        Create a single completion chunk (legacy format).
        
        Args:
            text: Response text
            model: Model name
            request_id: Request ID
            finish_reason: Optional finish reason
        
        Returns:
            SSE formatted chunk
        """
        chunk = {
            "id": request_id,
            "object": "text_completion",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "text": text,
                    "index": 0,
                    "finish_reason": finish_reason,
                }
            ],
        }
        
        return cls.format_sse(chunk)
    
    @classmethod
    def create_error_chunk(
        cls,
        error_message: str,
        error_type: str = "internal_error",
        error_code: Optional[str] = None,
    ) -> str:
        """
        Create an error chunk.
        
        Args:
            error_message: Error message
            error_type: Error type
            error_code: Error code
        
        Returns:
            SSE formatted error
        """
        error_data = {
            "error": {
                "message": error_message,
                "type": error_type,
                "code": error_code,
            }
        }
        
        return cls.format_sse(error_data)


class AsyncStreamAdapter:
    """Adapter to convert sync iterators to async iterators."""
    
    def __init__(self, sync_iterator: Iterator[Any]):
        self.sync_iterator = sync_iterator
    
    def __aiter__(self):
        return self
    
    async def __anext__(self):
        try:
            return next(self.sync_iterator)
        except StopIteration:
            raise StopAsyncIteration
