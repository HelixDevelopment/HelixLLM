"""
HelixLLM - Main Entry Point

Command-line interface for running HelixLLM.
"""

import argparse
import sys
from pathlib import Path
from typing import Optional

from .core.helix_llm import HelixLLM
from .core.configuration import Configuration
from .api.openai_compatible_api import OpenAICompatibleAPI
from .utils.logger import Logger


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser."""
    parser = argparse.ArgumentParser(
        description="HelixLLM - Local LLM System with RAG and Tool Use",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run API server with config file
  python -m helixllm server --config config.yaml

  # Interactive chat mode
  python -m helixllm chat --model path/to/model.gguf

  # Download a model
  python -m helixllm download --model llama-2-7b --quant Q4_K_M
        """,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Server command
    server_parser = subparsers.add_parser(
        "server",
        help="Run API server",
    )
    server_parser.add_argument(
        "--config",
        "-c",
        type=str,
        help="Path to configuration file",
    )
    server_parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind to (default: 0.0.0.0)",
    )
    server_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8000,
        help="Port to bind to (default: 8000)",
    )
    server_parser.add_argument(
        "--model",
        "-m",
        type=str,
        help="Path to GGUF model file",
    )
    
    # Chat command
    chat_parser = subparsers.add_parser(
        "chat",
        help="Interactive chat mode",
    )
    chat_parser.add_argument(
        "--config",
        "-c",
        type=str,
        help="Path to configuration file",
    )
    chat_parser.add_argument(
        "--model",
        "-m",
        type=str,
        required=True,
        help="Path to GGUF model file",
    )
    chat_parser.add_argument(
        "--system",
        "-s",
        type=str,
        help="System prompt",
    )
    chat_parser.add_argument(
        "--rag",
        action="store_true",
        help="Enable RAG",
    )
    chat_parser.add_argument(
        "--documents",
        "-d",
        nargs="+",
        help="Documents for RAG",
    )
    
    # Download command
    download_parser = subparsers.add_parser(
        "download",
        help="Download a model from HuggingFace",
    )
    download_parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name (e.g., llama-2-7b, mistral-7b)",
    )
    download_parser.add_argument(
        "--quant",
        type=str,
        default="Q4_K_M",
        help="Quantization level (default: Q4_K_M)",
    )
    download_parser.add_argument(
        "--cache-dir",
        type=str,
        default="./models",
        help="Cache directory (default: ./models)",
    )
    
    # Profile command
    profile_parser = subparsers.add_parser(
        "profile",
        help="Profile hardware and show recommendations",
    )
    
    return parser


def run_server(args: argparse.Namespace) -> int:
    """Run API server."""
    logger = Logger("helixllm")
    
    # Load configuration
    if args.config:
        config = Configuration.load(args.config)
    else:
        config = Configuration()
    
    # Override with command-line arguments
    config.api.host = args.host
    config.api.port = args.port
    
    if args.model:
        config.model.path = args.model
    
    # Validate
    errors = config.validate()
    if errors:
        logger.error(f"Configuration errors: {errors}")
        return 1
    
    # Initialize HelixLLM
    logger.info("Initializing HelixLLM...")
    helix = HelixLLM(config, logger)
    
    # Load model if specified
    if config.model.path:
        helix.load_model()
    
    # Create and run API server
    api = OpenAICompatibleAPI(helix, config, logger)
    api.run(host=args.host, port=args.port)
    
    return 0


def run_chat(args: argparse.Namespace) -> int:
    """Run interactive chat."""
    logger = Logger("helixllm")
    
    # Load configuration
    if args.config:
        config = Configuration.load(args.config)
    else:
        config = Configuration()
    
    config.model.path = args.model
    
    if args.rag:
        config.rag.enabled = True
    
    # Initialize HelixLLM
    logger.info("Initializing HelixLLM...")
    helix = HelixLLM(config, logger)
    
    # Load model
    helix.load_model()
    
    # Add documents if specified
    if args.documents:
        logger.info(f"Adding {len(args.documents)} documents...")
        helix.add_documents(args.documents)
    
    # Create session
    session = helix.create_session(system_prompt=args.system)
    
    print("\n" + "=" * 50)
    print("HelixLLM Interactive Chat")
    print("=" * 50)
    print("Type 'exit' or 'quit' to end the conversation")
    print("Type 'clear' to clear conversation history")
    print("=" * 50 + "\n")
    
    # Chat loop
    while True:
        try:
            # Get user input
            user_input = input("\nYou: ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ("exit", "quit"):
                print("\nGoodbye!")
                break
            
            if user_input.lower() == "clear":
                session.clear_history()
                print("\nConversation history cleared.")
                continue
            
            # Generate response
            print("\nAssistant: ", end="", flush=True)
            
            response = helix.chat(
                message=user_input,
                session=session,
                use_rag=args.rag,
            )
            
            print(response)
            
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except Exception as e:
            logger.error(f"Error: {e}")
            print(f"\nError: {e}")
    
    return 0


def run_download(args: argparse.Namespace) -> int:
    """Download a model."""
    from .utils.model_downloader import ModelDownloader
    
    logger = Logger("helixllm")
    logger.info(f"Downloading model: {args.model} ({args.quant})")
    
    downloader = ModelDownloader(
        cache_dir=args.cache_dir,
        logger=logger,
    )
    
    try:
        path = downloader.download_popular(
            model_name=args.model,
            quantization=args.quant,
        )
        print(f"\nModel downloaded to: {path}")
        return 0
    except Exception as e:
        logger.error(f"Download failed: {e}")
        print(f"\nDownload failed: {e}")
        return 1


def run_profile(args: argparse.Namespace) -> int:
    """Profile hardware."""
    from .utils.hardware_profiler import HardwareProfiler
    
    logger = Logger("helixllm")
    logger.info("Profiling hardware...")
    
    profiler = HardwareProfiler(logger)
    profile = profiler.profile()
    config = profiler.get_optimization_config()
    
    print("\n" + "=" * 50)
    print("Hardware Profile")
    print("=" * 50)
    
    print("\nCPU:")
    print(f"  Model: {profile.cpu.model}")
    print(f"  Cores: {profile.cpu.cores_physical} physical, {profile.cpu.cores_logical} logical")
    print(f"  Architecture: {profile.cpu.architecture}")
    
    print("\nMemory:")
    print(f"  Total: {profile.memory.total_mb // 1024} GB")
    print(f"  Available: {profile.memory.available_mb // 1024} GB")
    
    print("\nGPUs:")
    if profile.gpus:
        for gpu in profile.gpus:
            print(f"  [{gpu.index}] {gpu.name}")
            print(f"      Memory: {gpu.total_memory_mb // 1024} GB")
    else:
        print("  No GPUs detected")
    
    print("\n" + "=" * 50)
    print("Optimization Recommendations")
    print("=" * 50)
    print(f"\nRecommended model size: {profiler.get_recommended_model_size()}")
    print(f"Recommended quantization: {profiler.get_recommended_quantization()}")
    
    print("\nOptimal llama.cpp parameters:")
    print(f"  n_gpu_layers: {config.n_gpu_layers}")
    print(f"  n_ctx: {config.n_ctx}")
    print(f"  n_batch: {config.n_batch}")
    print(f"  n_threads: {config.n_threads}")
    print(f"  use_mmap: {config.use_mmap}")
    print(f"  use_mlock: {config.use_mlock}")
    print(f"  flash_attn: {config.flash_attn}")
    
    return 0


def main(argv: Optional[list] = None) -> int:
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args(argv)
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Run appropriate command
    commands = {
        "server": run_server,
        "chat": run_chat,
        "download": run_download,
        "profile": run_profile,
    }
    
    command_func = commands.get(args.command)
    if command_func:
        return command_func(args)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
