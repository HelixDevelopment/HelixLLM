"""
Retrieval engine for HelixLLM RAG.

Performs semantic search over document embeddings.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import logging

from .vector_store import VectorStore
from .embedding_generator import EmbeddingGenerator


@dataclass
class RetrievedDocument:
    """A retrieved document with relevance score."""
    content: str
    source: str
    score: float
    metadata: Dict[str, Any]
    chunk_index: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "content": self.content[:200] + "..." if len(self.content) > 200 else self.content,
            "source": self.source,
            "score": round(self.score, 4),
            "metadata": self.metadata,
            "chunk_index": self.chunk_index,
        }


class RetrievalEngine:
    """
    Performs semantic search over document embeddings.
    
    Coordinates embedding generation and vector store queries to retrieve
    relevant documents for a given query.
    
    Attributes:
        vector_store: Vector store instance
        embedding_generator: Embedding generator instance
        top_k: Default number of results to return
        similarity_threshold: Minimum similarity score
    
    Example:
        >>> engine = RetrievalEngine(vector_store, embedding_generator)
        >>> results = engine.retrieve("What is machine learning?", top_k=5)
    """
    
    def __init__(
        self,
        vector_store: VectorStore,
        embedding_generator: EmbeddingGenerator,
        top_k: int = 5,
        similarity_threshold: float = 0.7,
        rerank_results: bool = False,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize retrieval engine.
        
        Args:
            vector_store: Vector store instance
            embedding_generator: Embedding generator instance
            top_k: Default number of results
            similarity_threshold: Minimum similarity score (0-1)
            rerank_results: Whether to rerank results
            logger: Optional logger
        """
        self.vector_store = vector_store
        self.embedding_generator = embedding_generator
        self.top_k = top_k
        self.similarity_threshold = similarity_threshold
        self.rerank_results = rerank_results
        self.logger = logger or logging.getLogger(__name__)
        
        self.logger.info(
            f"Retrieval engine initialized: top_k={top_k}, "
            f"threshold={similarity_threshold}"
        )
    
    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None,
        filter_dict: Optional[Dict[str, Any]] = None,
        min_score: Optional[float] = None,
    ) -> List[RetrievedDocument]:
        """
        Retrieve relevant documents for a query.
        
        Args:
            query: Search query
            top_k: Number of results (uses default if not specified)
            filter_dict: Metadata filter
            min_score: Minimum similarity score
        
        Returns:
            List of retrieved documents
        """
        top_k = top_k or self.top_k
        min_score = min_score or self.similarity_threshold
        
        self.logger.debug(f"Retrieving documents for query: {query[:50]}...")
        
        # Generate query embedding
        query_embedding = self.embedding_generator.generate_query_embedding(query)
        
        # Search vector store
        results = self.vector_store.similarity_search(
            query_embedding=query_embedding,
            top_k=top_k * 2 if self.rerank_results else top_k,  # Get more for reranking
            filter_dict=filter_dict,
        )
        
        # Convert to RetrievedDocument objects
        documents = []
        for result in results:
            score = result.get("score", 0.0)
            
            # Filter by minimum score
            if score < min_score:
                continue
            
            metadata = result.get("metadata", {})
            
            documents.append(RetrievedDocument(
                content=result.get("content", ""),
                source=metadata.get("source", metadata.get("source_path", "unknown")),
                score=score,
                metadata=metadata,
                chunk_index=metadata.get("chunk_index"),
            ))
        
        # Rerank if enabled
        if self.rerank_results and len(documents) > top_k:
            documents = self._rerank_documents(query, documents, top_k)
        
        # Limit to top_k
        documents = documents[:top_k]
        
        self.logger.debug(f"Retrieved {len(documents)} documents")
        
        return documents
    
    def retrieve_with_scores(
        self,
        query: str,
        top_k: Optional[int] = None,
    ) -> List[tuple]:
        """
        Retrieve documents with their scores.
        
        Args:
            query: Search query
            top_k: Number of results
        
        Returns:
            List of (document, score) tuples
        """
        documents = self.retrieve(query, top_k)
        return [(doc, doc.score) for doc in documents]
    
    def batch_retrieve(
        self,
        queries: List[str],
        top_k: Optional[int] = None,
    ) -> List[List[RetrievedDocument]]:
        """
        Retrieve documents for multiple queries.
        
        Args:
            queries: List of queries
            top_k: Number of results per query
        
        Returns:
            List of document lists
        """
        return [self.retrieve(q, top_k) for q in queries]
    
    def add_documents(
        self,
        documents: List[Union[str, Dict[str, Any]]],
        embeddings: Optional[List[List[float]]] = None,
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> List[str]:
        """
        Add documents to the retrieval index.
        
        Args:
            documents: List of documents or text strings
            embeddings: Optional pre-computed embeddings
            metadatas: Optional metadata for each document
        
        Returns:
            List of document IDs
        """
        # Prepare documents
        prepared_docs = []
        
        for i, doc in enumerate(documents):
            if isinstance(doc, str):
                prepared_docs.append({
                    "content": doc,
                    "metadata": metadatas[i] if metadatas and i < len(metadatas) else {},
                })
            else:
                prepared_docs.append(doc)
        
        # Generate embeddings if not provided
        if embeddings is None:
            texts = [d["content"] for d in prepared_docs]
            embedding_results = self.embedding_generator.generate(texts)
            embeddings = [r.embedding for r in embedding_results]
        
        # Add to vector store
        doc_ids = self.vector_store.add_documents(
            documents=prepared_docs,
            embeddings=embeddings,
        )
        
        self.logger.info(f"Added {len(documents)} documents to retrieval index")
        
        return doc_ids
    
    def delete_documents(self, doc_ids: List[str]) -> bool:
        """
        Delete documents from the retrieval index.
        
        Args:
            doc_ids: List of document IDs
        
        Returns:
            True if successful
        """
        return self.vector_store.delete_documents(doc_ids)
    
    def _rerank_documents(
        self,
        query: str,
        documents: List[RetrievedDocument],
        top_k: int,
    ) -> List[RetrievedDocument]:
        """
        Rerank documents using additional signals.
        
        Args:
            query: Original query
            documents: Retrieved documents
            top_k: Number to return
        
        Returns:
            Reranked documents
        """
        # Simple reranking based on:
        # 1. Original similarity score
        # 2. Keyword overlap
        # 3. Document length (prefer medium-length docs)
        
        query_words = set(query.lower().split())
        
        scored_docs = []
        for doc in documents:
            score = doc.score
            
            # Keyword overlap bonus
            doc_words = set(doc.content.lower().split())
            overlap = len(query_words & doc_words) / max(len(query_words), 1)
            score += overlap * 0.1
            
            # Length preference (prefer docs around 200-500 tokens)
            doc_length = len(doc.content.split())
            if 100 <= doc_length <= 500:
                score += 0.05
            
            scored_docs.append((score, doc))
        
        # Sort by new score
        scored_docs.sort(key=lambda x: x[0], reverse=True)
        
        return [doc for _, doc in scored_docs[:top_k]]
    
    def get_context_string(
        self,
        query: str,
        top_k: Optional[int] = None,
        format_template: str = "Source {index}:\n{content}\n",
    ) -> str:
        """
        Get retrieved documents as formatted context string.
        
        Args:
            query: Search query
            top_k: Number of documents
            format_template: Template for formatting
        
        Returns:
            Formatted context string
        """
        documents = self.retrieve(query, top_k)
        
        if not documents:
            return ""
        
        context_parts = []
        for i, doc in enumerate(documents, 1):
            context_parts.append(format_template.format(
                index=i,
                content=doc.content,
                source=doc.source,
                score=doc.score,
            ))
        
        return "\n".join(context_parts)
    
    def hybrid_search(
        self,
        query: str,
        keywords: Optional[List[str]] = None,
        top_k: Optional[int] = None,
        semantic_weight: float = 0.7,
    ) -> List[RetrievedDocument]:
        """
        Perform hybrid search combining semantic and keyword search.
        
        Args:
            query: Semantic query
            keywords: Keyword terms for filtering
            top_k: Number of results
            semantic_weight: Weight for semantic vs keyword (0-1)
        
        Returns:
            List of retrieved documents
        """
        # Get semantic results
        semantic_results = self.retrieve(query, top_k=top_k * 2)
        
        if not keywords:
            return semantic_results[:top_k]
        
        # Score by keyword presence
        keyword_lower = [k.lower() for k in keywords]
        
        scored_docs = []
        for doc in semantic_results:
            semantic_score = doc.score
            
            # Keyword score
            content_lower = doc.content.lower()
            keyword_matches = sum(1 for kw in keyword_lower if kw in content_lower)
            keyword_score = keyword_matches / max(len(keywords), 1)
            
            # Combined score
            combined_score = (semantic_weight * semantic_score + 
                            (1 - semantic_weight) * keyword_score)
            
            scored_docs.append((combined_score, doc))
        
        # Sort by combined score
        scored_docs.sort(key=lambda x: x[0], reverse=True)
        
        return [doc for _, doc in scored_docs[:top_k]]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get retrieval engine statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            "vector_store": self.vector_store.get_stats(),
            "top_k": self.top_k,
            "similarity_threshold": self.similarity_threshold,
            "rerank_results": self.rerank_results,
        }
