"""
Document processing for HelixLLM RAG.

Handles loading, parsing, and chunking of various document formats.
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Union
import logging


@dataclass
class DocumentChunk:
    """A chunk of processed document content."""
    content: str
    source: str
    chunk_index: int
    total_chunks: int
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "content": self.content,
            "source": self.source,
            "chunk_index": self.chunk_index,
            "total_chunks": self.total_chunks,
            "metadata": self.metadata,
        }


class DocumentProcessor:
    """
    Processes documents for RAG ingestion.
    
    Handles multiple document formats and provides configurable chunking
    strategies for optimal retrieval performance.
    
    Attributes:
        chunk_size: Target size of each chunk in tokens
        chunk_overlap: Number of tokens to overlap between chunks
        separators: List of separators for chunking
    
    Example:
        >>> processor = DocumentProcessor(chunk_size=512, chunk_overlap=50)
        >>> chunks = processor.process_document("document.pdf")
    """
    
    # Supported file extensions
    SUPPORTED_EXTENSIONS = {
        ".txt": "text",
        ".md": "markdown",
        ".markdown": "markdown",
        ".pdf": "pdf",
        ".docx": "docx",
        ".doc": "doc",
        ".html": "html",
        ".htm": "html",
        ".json": "json",
        ".csv": "csv",
        ".py": "code",
        ".js": "code",
        ".ts": "code",
        ".java": "code",
        ".cpp": "code",
        ".c": "code",
        ".h": "code",
        ".rs": "code",
        ".go": "code",
    }
    
    # Default separators for chunking
    DEFAULT_SEPARATORS = [
        "\n\n\n",  # Paragraph breaks
        "\n\n",    # Double newlines
        "\n",      # Single newlines
        ". ",      # Sentences
        "! ",      # Exclamations
        "? ",      # Questions
        "; ",      # Semicolons
        ", ",      # Commas
        " ",       # Spaces
        "",         # Characters
    ]
    
    def __init__(
        self,
        chunk_size: int = 512,
        chunk_overlap: int = 50,
        separators: Optional[List[str]] = None,
        length_function: Optional[callable] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize document processor.
        
        Args:
            chunk_size: Target chunk size in characters (approximate tokens)
            chunk_overlap: Number of characters to overlap between chunks
            separators: List of separators for recursive chunking
            length_function: Function to calculate text length
            logger: Optional logger
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or self.DEFAULT_SEPARATORS.copy()
        self.length_function = length_function or len
        self.logger = logger or logging.getLogger(__name__)
        
        # Optional dependencies
        self._load_optional_dependencies()
    
    def _load_optional_dependencies(self) -> None:
        """Load optional dependencies for document parsing."""
        self._pypdf_available = False
        self._docx_available = False
        self._bs4_available = False
        
        try:
            import pypdf
            self._pypdf_available = True
        except ImportError:
            pass
        
        try:
            import docx
            self._docx_available = True
        except ImportError:
            pass
        
        try:
            from bs4 import BeautifulSoup
            self._bs4_available = True
        except ImportError:
            pass
    
    def process_document(
        self,
        source: Union[str, Path],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[DocumentChunk]:
        """
        Process a document and return chunks.
        
        Args:
            source: Path to document or raw content
            metadata: Additional metadata for the document
        
        Returns:
            List of document chunks
        """
        # Determine if source is a file path or raw content
        source_path = Path(source) if not isinstance(source, str) or len(source) < 1000 else None
        
        if source_path and source_path.exists():
            content = self._load_file(source_path)
            doc_metadata = {"source_path": str(source_path), **(metadata or {})}
        else:
            content = str(source)
            doc_metadata = {"source": "raw_content", **(metadata or {})}
        
        # Chunk the content
        chunks = self._chunk_text(content)
        
        # Create DocumentChunk objects
        total_chunks = len(chunks)
        return [
            DocumentChunk(
                content=chunk,
                source=str(source) if isinstance(source, Path) else "raw_content",
                chunk_index=i,
                total_chunks=total_chunks,
                metadata=doc_metadata,
            )
            for i, chunk in enumerate(chunks)
        ]
    
    def process_documents(
        self,
        sources: List[Union[str, Path]],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[DocumentChunk]:
        """
        Process multiple documents.
        
        Args:
            sources: List of document paths or content
            metadata: Additional metadata
        
        Returns:
            Combined list of chunks from all documents
        """
        all_chunks = []
        for source in sources:
            try:
                chunks = self.process_document(source, metadata)
                all_chunks.extend(chunks)
            except Exception as e:
                self.logger.error(f"Failed to process {source}: {e}")
        
        return all_chunks
    
    def _load_file(self, path: Path) -> str:
        """Load content from file based on extension."""
        extension = path.suffix.lower()
        doc_type = self.SUPPORTED_EXTENSIONS.get(extension, "text")
        
        self.logger.debug(f"Loading {doc_type} file: {path}")
        
        if doc_type == "pdf":
            return self._load_pdf(path)
        elif doc_type == "docx":
            return self._load_docx(path)
        elif doc_type == "html":
            return self._load_html(path)
        elif doc_type == "json":
            return self._load_json(path)
        elif doc_type == "csv":
            return self._load_csv(path)
        else:
            return self._load_text(path)
    
    def _load_text(self, path: Path) -> str:
        """Load plain text file."""
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    
    def _load_pdf(self, path: Path) -> str:
        """Load PDF file."""
        if not self._pypdf_available:
            raise ImportError(
                "pypdf is required for PDF processing. "
                "Install with: pip install pypdf"
            )
        
        import pypdf
        
        text_parts = []
        with open(path, "rb") as f:
            reader = pypdf.PdfReader(f)
            for page in reader.pages:
                text_parts.append(page.extract_text() or "")
        
        return "\n\n".join(text_parts)
    
    def _load_docx(self, path: Path) -> str:
        """Load DOCX file."""
        if not self._docx_available:
            raise ImportError(
                "python-docx is required for DOCX processing. "
                "Install with: pip install python-docx"
            )
        
        import docx
        
        doc = docx.Document(path)
        text_parts = [paragraph.text for paragraph in doc.paragraphs]
        
        return "\n\n".join(text_parts)
    
    def _load_html(self, path: Path) -> str:
        """Load HTML file."""
        if not self._bs4_available:
            return self._load_text(path)
        
        from bs4 import BeautifulSoup
        
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            soup = BeautifulSoup(f.read(), "html.parser")
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()
        
        return soup.get_text(separator="\n", strip=True)
    
    def _load_json(self, path: Path) -> str:
        """Load JSON file and convert to text."""
        import json
        
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        # Convert JSON to formatted text
        return json.dumps(data, indent=2)
    
    def _load_csv(self, path: Path) -> str:
        """Load CSV file and convert to text."""
        import csv
        
        rows = []
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            reader = csv.reader(f)
            for row in reader:
                rows.append(" | ".join(row))
        
        return "\n".join(rows)
    
    def _chunk_text(self, text: str) -> List[str]:
        """
        Split text into chunks using recursive character chunking.
        
        Args:
            text: Text to chunk
        
        Returns:
            List of text chunks
        """
        # Clean text
        text = self._clean_text(text)
        
        # Use recursive chunking
        return self._recursive_chunk(text, self.separators.copy())
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text."""
        # Remove excessive whitespace
        text = re.sub(r"\n{4,}", "\n\n\n", text)
        text = re.sub(r" {2,}", " ", text)
        text = re.sub(r"\t+", " ", text)
        
        # Remove null bytes
        text = text.replace("\x00", "")
        
        return text.strip()
    
    def _recursive_chunk(self, text: str, separators: List[str]) -> List[str]:
        """
        Recursively chunk text using separators.
        
        Args:
            text: Text to chunk
            separators: List of separators to try
        
        Returns:
            List of chunks
        """
        if not text:
            return []
        
        # If text is small enough, return as single chunk
        if self.length_function(text) <= self.chunk_size:
            return [text]
        
        # If no more separators, split by character
        if not separators:
            return self._fixed_size_chunk(text)
        
        separator = separators[0]
        remaining_separators = separators[1:]
        
        # Split by current separator
        if separator:
            parts = text.split(separator)
        else:
            parts = list(text)
        
        # Process parts
        chunks = []
        current_chunk = ""
        
        for part in parts:
            part = part.strip()
            if not part:
                continue
            
            # Check if adding this part would exceed chunk size
            test_chunk = current_chunk + separator + part if current_chunk else part
            
            if self.length_function(test_chunk) <= self.chunk_size:
                current_chunk = test_chunk
            else:
                # Save current chunk
                if current_chunk:
                    chunks.append(current_chunk.strip())
                
                # If part itself is too big, recursively chunk it
                if self.length_function(part) > self.chunk_size:
                    sub_chunks = self._recursive_chunk(part, remaining_separators)
                    chunks.extend(sub_chunks)
                    current_chunk = ""
                else:
                    current_chunk = part
        
        # Don't forget the last chunk
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        # Add overlap between chunks
        return self._add_overlap(chunks)
    
    def _fixed_size_chunk(self, text: str) -> List[str]:
        """Split text into fixed-size chunks."""
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.chunk_size
            chunk = text[start:end]
            chunks.append(chunk.strip())
            start = end - self.chunk_overlap
        
        return chunks
    
    def _add_overlap(self, chunks: List[str]) -> List[str]:
        """Add overlap between chunks."""
        if not chunks or self.chunk_overlap <= 0:
            return chunks
        
        overlapped = [chunks[0]]
        
        for i in range(1, len(chunks)):
            prev_chunk = chunks[i - 1]
            current_chunk = chunks[i]
            
            # Get overlap from previous chunk
            overlap_text = prev_chunk[-self.chunk_overlap:] if len(prev_chunk) > self.chunk_overlap else prev_chunk
            
            # Prepend overlap to current chunk
            overlapped_chunk = overlap_text + " " + current_chunk
            overlapped.append(overlapped_chunk)
        
        return overlapped
    
    def estimate_tokens(self, text: str, chars_per_token: float = 4.0) -> int:
        """
        Estimate token count for text.
        
        Args:
            text: Input text
            chars_per_token: Average characters per token
        
        Returns:
            Estimated token count
        """
        return int(len(text) / chars_per_token)
    
    def get_stats(self, chunks: List[DocumentChunk]) -> Dict[str, Any]:
        """
        Get statistics about processed chunks.
        
        Args:
            chunks: List of chunks
        
        Returns:
            Statistics dictionary
        """
        if not chunks:
            return {"count": 0}
        
        sizes = [self.length_function(c.content) for c in chunks]
        
        return {
            "count": len(chunks),
            "avg_size": sum(sizes) / len(sizes),
            "min_size": min(sizes),
            "max_size": max(sizes),
            "total_size": sum(sizes),
            "estimated_tokens": self.estimate_tokens("".join(c.content for c in chunks)),
        }
