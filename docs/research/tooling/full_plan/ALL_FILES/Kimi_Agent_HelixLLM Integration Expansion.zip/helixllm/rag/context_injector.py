"""
Context injection for HelixLLM RAG.

Injects retrieved documents into prompts for context-aware generation.
"""

from typing import Any, Dict, List, Optional, Union
import logging

from .retrieval_engine import RetrievedDocument


class ContextInjector:
    """
    Injects retrieved context into prompts for RAG.
    
    Formats retrieved documents and injects them into conversation
    history or standalone prompts.
    
    Attributes:
        max_context_length: Maximum length of injected context
        context_template: Template for formatting context
        include_sources: Whether to include source information
    
    Example:
        >>> injector = ContextInjector(max_context_length=2048)
        >>> messages = injector.inject_context(messages, retrieved_docs)
    """
    
    DEFAULT_CONTEXT_TEMPLATE = """Use the following context to answer the question. If the context doesn't contain relevant information, say so.

Context:
{context}

---"""
    
    DEFAULT_SOURCE_TEMPLATE = "[{index}] {source}"
    
    def __init__(
        self,
        max_context_length: int = 2048,
        context_template: Optional[str] = None,
        source_template: Optional[str] = None,
        include_sources: bool = True,
        source_format: str = "inline",  # "inline", "footer", "none"
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize context injector.
        
        Args:
            max_context_length: Maximum characters of context to inject
            context_template: Template for formatting context block
            source_template: Template for formatting source citations
            include_sources: Include source information in context
            source_format: How to format sources ("inline", "footer", "none")
            logger: Optional logger
        """
        self.max_context_length = max_context_length
        self.context_template = context_template or self.DEFAULT_CONTEXT_TEMPLATE
        self.source_template = source_template or self.DEFAULT_SOURCE_TEMPLATE
        self.include_sources = include_sources
        self.source_format = source_format
        self.logger = logger or logging.getLogger(__name__)
    
    def inject_context(
        self,
        messages: List[Dict[str, str]],
        documents: List[RetrievedDocument],
        max_length: Optional[int] = None,
    ) -> List[Dict[str, str]]:
        """
        Inject retrieved documents into conversation messages.
        
        Args:
            messages: List of conversation messages
            documents: Retrieved documents to inject
            max_length: Maximum context length (uses default if not specified)
        
        Returns:
            Modified messages with context injected
        """
        if not documents:
            return messages
        
        max_length = max_length or self.max_context_length
        
        # Format context from documents
        context = self._format_context(documents, max_length)
        
        if not context:
            return messages
        
        # Find system message or create new one
        messages = list(messages)  # Copy to avoid modifying original
        
        # Create context message
        context_message = {
            "role": "system",
            "content": self.context_template.format(context=context),
        }
        
        # Check if there's already a system message
        system_idx = None
        for i, msg in enumerate(messages):
            if msg.get("role") == "system":
                system_idx = i
                break
        
        if system_idx is not None:
            # Append context to existing system message
            existing_content = messages[system_idx].get("content", "")
            messages[system_idx]["content"] = f"{context_message['content']}\n\n{existing_content}"
        else:
            # Add context as first message
            messages.insert(0, context_message)
        
        return messages
    
    def inject_into_prompt(
        self,
        prompt: str,
        documents: List[RetrievedDocument],
        max_length: Optional[int] = None,
    ) -> str:
        """
        Inject context into a standalone prompt.
        
        Args:
            prompt: Original prompt
            documents: Retrieved documents
            max_length: Maximum context length
        
        Returns:
            Prompt with context injected
        """
        if not documents:
            return prompt
        
        max_length = max_length or self.max_context_length
        
        # Format context
        context = self._format_context(documents, max_length)
        
        if not context:
            return prompt
        
        # Combine context with prompt
        return f"{self.context_template.format(context=context)}\n\n{prompt}"
    
    def _format_context(
        self,
        documents: List[RetrievedDocument],
        max_length: int,
    ) -> str:
        """
        Format retrieved documents into context string.
        
        Args:
            documents: Retrieved documents
            max_length: Maximum length
        
        Returns:
            Formatted context string
        """
        context_parts = []
        current_length = 0
        
        for i, doc in enumerate(documents, 1):
            # Format document with optional source
            if self.include_sources and self.source_format == "inline":
                source_str = self.source_template.format(
                    index=i,
                    source=doc.source,
                    score=doc.score,
                )
                doc_text = f"[{source_str}] {doc.content}"
            else:
                doc_text = doc.content
            
            # Check if adding this would exceed limit
            if current_length + len(doc_text) > max_length:
                # Try to truncate
                remaining = max_length - current_length
                if remaining > 100:  # Only add if we have reasonable space
                    doc_text = doc_text[:remaining - 3] + "..."
                else:
                    break
            
            context_parts.append(doc_text)
            current_length += len(doc_text) + 2  # +2 for newlines
        
        context = "\n\n".join(context_parts)
        
        # Add source footer if requested
        if self.include_sources and self.source_format == "footer":
            source_footer = self._format_source_footer(documents[:len(context_parts)])
            if len(context) + len(source_footer) + 2 <= max_length:
                context += f"\n\n{source_footer}"
        
        return context
    
    def _format_source_footer(self, documents: List[RetrievedDocument]) -> str:
        """Format source citations footer."""
        sources = []
        for i, doc in enumerate(documents, 1):
            sources.append(f"[{i}] {doc.source}")
        
        return "Sources:\n" + "\n".join(sources)
    
    def create_rag_prompt(
        self,
        query: str,
        documents: List[RetrievedDocument],
        system_prompt: Optional[str] = None,
        max_length: Optional[int] = None,
    ) -> str:
        """
        Create a complete RAG prompt with context.
        
        Args:
            query: User query
            documents: Retrieved documents
            system_prompt: Optional system prompt
            max_length: Maximum context length
        
        Returns:
            Complete RAG prompt
        """
        max_length = max_length or self.max_context_length
        
        # Format context
        context = self._format_context(documents, max_length)
        
        # Build prompt
        parts = []
        
        if system_prompt:
            parts.append(f"System: {system_prompt}")
        
        parts.append(self.context_template.format(context=context))
        parts.append(f"Question: {query}")
        parts.append("Answer:")
        
        return "\n\n".join(parts)
    
    def estimate_context_tokens(
        self,
        documents: List[RetrievedDocument],
        chars_per_token: float = 4.0,
    ) -> int:
        """
        Estimate token count for context.
        
        Args:
            documents: Documents to estimate
            chars_per_token: Average characters per token
        
        Returns:
            Estimated token count
        """
        total_chars = sum(len(doc.content) for doc in documents)
        return int(total_chars / chars_per_token)
    
    def select_optimal_documents(
        self,
        documents: List[RetrievedDocument],
        max_tokens: int,
        chars_per_token: float = 4.0,
    ) -> List[RetrievedDocument]:
        """
        Select optimal subset of documents within token limit.
        
        Args:
            documents: Available documents
            max_tokens: Maximum tokens allowed
            chars_per_token: Characters per token estimate
        
        Returns:
            Selected documents
        """
        max_chars = int(max_tokens * chars_per_token)
        
        selected = []
        current_chars = 0
        
        for doc in documents:
            doc_chars = len(doc.content)
            
            if current_chars + doc_chars <= max_chars:
                selected.append(doc)
                current_chars += doc_chars
            else:
                break
        
        return selected
