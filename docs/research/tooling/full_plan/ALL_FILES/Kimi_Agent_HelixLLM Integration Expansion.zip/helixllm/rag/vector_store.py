"""
Vector store for HelixLLM RAG.

ChromaDB wrapper for storing and retrieving document embeddings.
"""

import json
import threading
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import logging
import numpy as np

try:
    import chromadb
    from chromadb.config import Settings
    CHROMADB_AVAILABLE = True
except ImportError:
    CHROMADB_AVAILABLE = False


@dataclass
class StoredDocument:
    """A document stored in the vector store."""
    id: str
    content: str
    embedding: Optional[List[float]]
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata,
        }


class VectorStore:
    """
    Vector store for document embeddings using ChromaDB.
    
    Provides storage, retrieval, and similarity search for document chunks.
    
    Attributes:
        collection_name: Name of the ChromaDB collection
        persist_directory: Directory for persistent storage
        embedding_function: Optional embedding function
    
    Example:
        >>> store = VectorStore(persist_directory="./data/vector_store")
        >>> store.add_documents([{"id": "1", "content": "Hello", "embedding": [...]}])
        >>> results = store.similarity_search("query", top_k=5)
    """
    
    DEFAULT_COLLECTION_NAME = "helixllm_documents"
    
    def __init__(
        self,
        persist_directory: Union[str, Path] = "./data/vector_store",
        collection_name: str = DEFAULT_COLLECTION_NAME,
        embedding_function: Optional[Any] = None,
        distance_metric: str = "cosine",
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize vector store.
        
        Args:
            persist_directory: Directory for persistent storage
            collection_name: Name of the collection
            embedding_function: Optional embedding function
            distance_metric: Distance metric ("cosine", "l2", "ip")
            logger: Optional logger
        """
        if not CHROMADB_AVAILABLE:
            raise ImportError(
                "chromadb is required for vector storage. "
                "Install with: pip install chromadb"
            )
        
        self.persist_directory = Path(persist_directory)
        self.collection_name = collection_name
        self.embedding_function = embedding_function
        self.distance_metric = distance_metric
        self.logger = logger or logging.getLogger(__name__)
        
        self._lock = threading.RLock()
        self._client: Optional[chromadb.Client] = None
        self._collection: Optional[chromadb.Collection] = None
        
        # Initialize ChromaDB
        self._init_chromadb()
    
    def _init_chromadb(self) -> None:
        """Initialize ChromaDB client and collection."""
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        
        self.logger.info(f"Initializing ChromaDB at {self.persist_directory}")
        
        # Create client with persistence
        settings = Settings(
            persist_directory=str(self.persist_directory),
            anonymized_telemetry=False,
        )
        
        self._client = chromadb.Client(settings)
        
        # Get or create collection
        try:
            self._collection = self._client.get_collection(
                name=self.collection_name,
            )
            self.logger.info(f"Using existing collection: {self.collection_name}")
        except Exception:
            self._collection = self._client.create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": self.distance_metric},
            )
            self.logger.info(f"Created new collection: {self.collection_name}")
    
    def add_documents(
        self,
        documents: List[Union[StoredDocument, Dict[str, Any]]],
        embeddings: Optional[List[List[float]]] = None,
    ) -> List[str]:
        """
        Add documents to the vector store.
        
        Args:
            documents: List of documents to add
            embeddings: Optional pre-computed embeddings
        
        Returns:
            List of document IDs
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            # Convert to StoredDocument objects
            stored_docs = []
            for doc in documents:
                if isinstance(doc, dict):
                    stored_docs.append(StoredDocument(
                        id=doc.get("id", str(uuid.uuid4())),
                        content=doc["content"],
                        embedding=doc.get("embedding"),
                        metadata=doc.get("metadata", {}),
                    ))
                else:
                    stored_docs.append(doc)
            
            # Prepare data for ChromaDB
            ids = [doc.id for doc in stored_docs]
            texts = [doc.content for doc in stored_docs]
            metadatas = [doc.metadata for doc in stored_docs]
            
            # Use provided embeddings or generate them
            if embeddings is None:
                doc_embeddings = [doc.embedding for doc in stored_docs if doc.embedding is not None]
                if len(doc_embeddings) == len(stored_docs):
                    embeddings = doc_embeddings
            
            # Add to collection
            if embeddings:
                self._collection.add(
                    ids=ids,
                    documents=texts,
                    embeddings=embeddings,
                    metadatas=metadatas,
                )
            else:
                self._collection.add(
                    ids=ids,
                    documents=texts,
                    metadatas=metadatas,
                )
            
            self.logger.info(f"Added {len(documents)} documents to vector store")
            
            return ids
    
    def add_texts(
        self,
        texts: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        ids: Optional[List[str]] = None,
    ) -> List[str]:
        """
        Add raw texts to the vector store.
        
        Args:
            texts: List of text strings
            metadatas: Optional metadata for each text
            ids: Optional IDs for each text
        
        Returns:
            List of document IDs
        """
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in texts]
        
        if metadatas is None:
            metadatas = [{} for _ in texts]
        
        documents = [
            StoredDocument(
                id=id,
                content=text,
                embedding=None,
                metadata=meta,
            )
            for id, text, meta in zip(ids, texts, metadatas)
        ]
        
        return self.add_documents(documents)
    
    def similarity_search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        filter_dict: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search for similar documents using embedding.
        
        Args:
            query_embedding: Query embedding vector
            top_k: Number of results to return
            filter_dict: Optional metadata filter
        
        Returns:
            List of matching documents with similarity scores
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            results = self._collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                where=filter_dict,
                include=["documents", "metadatas", "distances"],
            )
            
            # Format results
            formatted_results = []
            
            if results["ids"] and len(results["ids"]) > 0:
                for i, doc_id in enumerate(results["ids"][0]):
                    formatted_results.append({
                        "id": doc_id,
                        "content": results["documents"][0][i] if results["documents"] else "",
                        "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                        "distance": results["distances"][0][i] if results["distances"] else 0.0,
                        "score": 1.0 - (results["distances"][0][i] if results["distances"] else 0.0),
                    })
            
            return formatted_results
    
    def text_search(
        self,
        query_text: str,
        top_k: int = 5,
        filter_dict: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search for similar documents using text query.
        
        Args:
            query_text: Query text
            top_k: Number of results to return
            filter_dict: Optional metadata filter
        
        Returns:
            List of matching documents with similarity scores
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            results = self._collection.query(
                query_texts=[query_text],
                n_results=top_k,
                where=filter_dict,
                include=["documents", "metadatas", "distances"],
            )
            
            # Format results
            formatted_results = []
            
            if results["ids"] and len(results["ids"]) > 0:
                for i, doc_id in enumerate(results["ids"][0]):
                    formatted_results.append({
                        "id": doc_id,
                        "content": results["documents"][0][i] if results["documents"] else "",
                        "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                        "distance": results["distances"][0][i] if results["distances"] else 0.0,
                        "score": 1.0 - (results["distances"][0][i] if results["distances"] else 0.0),
                    })
            
            return formatted_results
    
    def get_document(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a document by ID.
        
        Args:
            doc_id: Document ID
        
        Returns:
            Document or None if not found
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            try:
                result = self._collection.get(
                    ids=[doc_id],
                    include=["documents", "metadatas"],
                )
                
                if result["ids"] and len(result["ids"]) > 0:
                    return {
                        "id": result["ids"][0],
                        "content": result["documents"][0] if result["documents"] else "",
                        "metadata": result["metadatas"][0] if result["metadatas"] else {},
                    }
            except Exception as e:
                self.logger.debug(f"Document not found: {doc_id}")
            
            return None
    
    def delete_documents(self, doc_ids: List[str]) -> bool:
        """
        Delete documents by ID.
        
        Args:
            doc_ids: List of document IDs to delete
        
        Returns:
            True if successful
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            self._collection.delete(ids=doc_ids)
            self.logger.info(f"Deleted {len(doc_ids)} documents")
            return True
    
    def update_document(
        self,
        doc_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        embedding: Optional[List[float]] = None,
    ) -> bool:
        """
        Update a document.
        
        Args:
            doc_id: Document ID
            content: New content
            metadata: New metadata
            embedding: New embedding
        
        Returns:
            True if successful
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            # Get existing document
            existing = self.get_document(doc_id)
            if not existing:
                return False
            
            # Update
            update_data: Dict[str, Any] = {"ids": [doc_id]}
            
            if content is not None:
                update_data["documents"] = [content]
            if metadata is not None:
                update_data["metadatas"] = [metadata]
            if embedding is not None:
                update_data["embeddings"] = [embedding]
            
            self._collection.update(**update_data)
            
            return True
    
    def get_all_documents(
        self,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get all documents in the store.
        
        Args:
            limit: Maximum number of documents
            offset: Offset for pagination
        
        Returns:
            List of documents
        """
        with self._lock:
            if self._collection is None:
                raise RuntimeError("Collection not initialized")
            
            result = self._collection.get(
                limit=limit,
                offset=offset,
                include=["documents", "metadatas"],
            )
            
            documents = []
            if result["ids"]:
                for i, doc_id in enumerate(result["ids"]):
                    documents.append({
                        "id": doc_id,
                        "content": result["documents"][i] if result["documents"] else "",
                        "metadata": result["metadatas"][i] if result["metadatas"] else {},
                    })
            
            return documents
    
    def count(self) -> int:
        """
        Get total number of documents.
        
        Returns:
            Document count
        """
        with self._lock:
            if self._collection is None:
                return 0
            
            return self._collection.count()
    
    def clear(self) -> bool:
        """
        Clear all documents from the store.
        
        Returns:
            True if successful
        """
        with self._lock:
            if self._collection is None:
                return False
            
            # Delete and recreate collection
            self._client.delete_collection(self.collection_name)
            self._collection = self._client.create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": self.distance_metric},
            )
            
            self.logger.info("Vector store cleared")
            return True
    
    def persist(self) -> None:
        """Persist changes to disk."""
        with self._lock:
            if self._client:
                # ChromaDB auto-persists, but we can force it
                self.logger.debug("Persisting vector store")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get store statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            "collection_name": self.collection_name,
            "document_count": self.count(),
            "persist_directory": str(self.persist_directory),
            "distance_metric": self.distance_metric,
        }


class InMemoryVectorStore:
    """Simple in-memory vector store for testing."""
    
    def __init__(self, **kwargs):
        self.documents: Dict[str, Dict[str, Any]] = {}
        self.logger = logging.getLogger(__name__)
    
    def add_documents(self, documents: List[Any], embeddings: Optional[List[List[float]]] = None) -> List[str]:
        """Add documents to store."""
        ids = []
        for i, doc in enumerate(documents):
            doc_id = str(uuid.uuid4())
            if isinstance(doc, dict):
                self.documents[doc_id] = doc
            else:
                self.documents[doc_id] = {"content": str(doc)}
            if embeddings and i < len(embeddings):
                self.documents[doc_id]["embedding"] = embeddings[i]
            ids.append(doc_id)
        return ids
    
    def similarity_search(self, query_embedding: List[float], top_k: int = 5, **kwargs) -> List[Dict[str, Any]]:
        """Mock similarity search."""
        return [
            {"id": doc_id, "content": doc.get("content", ""), "score": 0.5}
            for doc_id, doc in list(self.documents.items())[:top_k]
        ]
    
    def count(self) -> int:
        """Get document count."""
        return len(self.documents)
    
    def clear(self) -> bool:
        """Clear store."""
        self.documents.clear()
        return True
