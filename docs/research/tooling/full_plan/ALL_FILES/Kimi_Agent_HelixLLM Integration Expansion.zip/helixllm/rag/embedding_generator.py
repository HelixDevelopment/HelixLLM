"""
Embedding generation for HelixLLM RAG.

Generates embeddings using local embedding models (nomic-embed-text).
"""

import hashlib
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import logging
import numpy as np

# llama-cpp-python for embeddings
try:
    from llama_cpp import Llama
    LLAMA_CPP_AVAILABLE = True
except ImportError:
    LLAMA_CPP_AVAILABLE = False


@dataclass
class EmbeddingResult:
    """Result of embedding generation."""
    text: str
    embedding: List[float]
    model: str
    dimensions: int
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "text": self.text[:100] + "..." if len(self.text) > 100 else self.text,
            "embedding": self.embedding[:10] + ["..."] if len(self.embedding) > 10 else self.embedding,
            "model": self.model,
            "dimensions": self.dimensions,
        }


class EmbeddingGenerator:
    """
    Generates embeddings for text using local models.
    
    Supports nomic-embed-text and other GGUF embedding models.
    Provides batch processing and caching for efficiency.
    
    Attributes:
        model_path: Path to embedding model
        embedding_dim: Dimensionality of embeddings
        batch_size: Batch size for processing
    
    Example:
        >>> generator = EmbeddingGenerator("nomic-embed-text-v1.5.Q4_K_M.gguf")
        >>> embeddings = generator.generate(["Hello world", "Test text"])
    """
    
    # Known embedding models and their dimensions
    MODEL_DIMENSIONS = {
        "nomic": 768,
        "nomic-embed": 768,
        "bge": 768,
        "bge-small": 384,
        "bge-base": 768,
        "bge-large": 1024,
        "e5": 768,
        "e5-small": 384,
        "e5-base": 768,
        "e5-large": 1024,
    }
    
    def __init__(
        self,
        model_path: Union[str, Path],
        embedding_dim: Optional[int] = None,
        batch_size: int = 32,
        normalize: bool = True,
        pooling: str = "mean",
        cache_embeddings: bool = True,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize embedding generator.
        
        Args:
            model_path: Path to GGUF embedding model
            embedding_dim: Embedding dimension (auto-detected if not specified)
            batch_size: Batch size for processing
            normalize: Normalize embeddings to unit length
            pooling: Pooling strategy ("mean", "cls", "last")
            cache_embeddings: Cache embeddings in memory
            logger: Optional logger
        """
        if not LLAMA_CPP_AVAILABLE:
            raise ImportError(
                "llama-cpp-python is required for embeddings. "
                "Install with: pip install llama-cpp-python"
            )
        
        self.model_path = Path(model_path)
        self.batch_size = batch_size
        self.normalize = normalize
        self.pooling = pooling
        self.cache_embeddings = cache_embeddings
        self.logger = logger or logging.getLogger(__name__)
        
        # Detect embedding dimension
        self.embedding_dim = embedding_dim or self._detect_embedding_dim()
        
        # Model instance
        self._model: Optional[Llama] = None
        self._lock = threading.RLock()
        
        # Embedding cache
        self._cache: Dict[str, List[float]] = {}
        
        # Load model
        self._load_model()
    
    def _detect_embedding_dim(self) -> int:
        """Detect embedding dimension from model name."""
        model_name = self.model_path.name.lower()
        
        for key, dim in self.MODEL_DIMENSIONS.items():
            if key in model_name:
                return dim
        
        # Default dimension
        self.logger.warning(f"Could not detect embedding dimension, using default: 768")
        return 768
    
    def _load_model(self) -> None:
        """Load the embedding model."""
        if not self.model_path.exists():
            raise FileNotFoundError(f"Embedding model not found: {self.model_path}")
        
        self.logger.info(f"Loading embedding model: {self.model_path.name}")
        
        try:
            self._model = Llama(
                model_path=str(self.model_path),
                embedding=True,
                n_ctx=8192,
                verbose=False,
            )
            
            self.logger.info(f"Embedding model loaded: {self.embedding_dim} dimensions")
            
        except Exception as e:
            self.logger.error(f"Failed to load embedding model: {e}")
            raise
    
    def generate(self, texts: Union[str, List[str]]) -> Union[EmbeddingResult, List[EmbeddingResult]]:
        """
        Generate embeddings for text(s).
        
        Args:
            texts: Single text or list of texts
        
        Returns:
            Embedding result(s)
        """
        single_input = isinstance(texts, str)
        if single_input:
            texts = [texts]
        
        results = []
        
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i:i + self.batch_size]
            batch_results = self._generate_batch(batch)
            results.extend(batch_results)
        
        return results[0] if single_input else results
    
    def _generate_batch(self, texts: List[str]) -> List[EmbeddingResult]:
        """Generate embeddings for a batch of texts."""
        with self._lock:
            if self._model is None:
                raise RuntimeError("Embedding model not loaded")
            
            results = []
            
            for text in texts:
                # Check cache
                cache_key = self._get_cache_key(text)
                if self.cache_embeddings and cache_key in self._cache:
                    embedding = self._cache[cache_key]
                else:
                    # Generate embedding
                    embedding = self._model.embed(text)
                    
                    # Normalize if requested
                    if self.normalize:
                        embedding = self._normalize_embedding(embedding)
                    
                    # Cache if enabled
                    if self.cache_embeddings:
                        self._cache[cache_key] = embedding
                
                results.append(EmbeddingResult(
                    text=text,
                    embedding=embedding,
                    model=self.model_path.name,
                    dimensions=len(embedding),
                ))
            
            return results
    
    def _get_cache_key(self, text: str) -> str:
        """Generate cache key for text."""
        return hashlib.md5(text.encode()).hexdigest()
    
    def _normalize_embedding(self, embedding: List[float]) -> List[float]:
        """Normalize embedding to unit length."""
        arr = np.array(embedding)
        norm = np.linalg.norm(arr)
        
        if norm > 0:
            arr = arr / norm
        
        return arr.tolist()
    
    def generate_query_embedding(self, query: str) -> List[float]:
        """
        Generate embedding optimized for search queries.
        
        Args:
            query: Search query
        
        Returns:
            Query embedding
        """
        # Add search prefix for some models
        if "nomic" in self.model_path.name.lower():
            query = f"search_query: {query}"
        elif "e5" in self.model_path.name.lower():
            query = f"query: {query}"
        
        result = self.generate(query)
        
        if isinstance(result, list):
            return result[0].embedding
        return result.embedding
    
    def generate_document_embedding(self, document: str) -> List[float]:
        """
        Generate embedding optimized for documents.
        
        Args:
            document: Document text
        
        Returns:
            Document embedding
        """
        # Add document prefix for some models
        if "nomic" in self.model_path.name.lower():
            document = f"search_document: {document}"
        elif "e5" in self.model_path.name.lower():
            document = f"passage: {document}"
        
        result = self.generate(document)
        
        if isinstance(result, list):
            return result[0].embedding
        return result.embedding
    
    def compute_similarity(
        self,
        embedding1: List[float],
        embedding2: List[float],
    ) -> float:
        """
        Compute cosine similarity between two embeddings.
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
        
        Returns:
            Cosine similarity (-1 to 1)
        """
        arr1 = np.array(embedding1)
        arr2 = np.array(embedding2)
        
        dot_product = np.dot(arr1, arr2)
        norm1 = np.linalg.norm(arr1)
        norm2 = np.linalg.norm(arr2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return float(dot_product / (norm1 * norm2))
    
    def find_similar(
        self,
        query_embedding: List[float],
        candidate_embeddings: List[List[float]],
        top_k: int = 5,
    ) -> List[tuple]:
        """
        Find most similar embeddings to query.
        
        Args:
            query_embedding: Query embedding
            candidate_embeddings: List of candidate embeddings
            top_k: Number of top results to return
        
        Returns:
            List of (index, similarity) tuples
        """
        similarities = [
            (i, self.compute_similarity(query_embedding, emb))
            for i, emb in enumerate(candidate_embeddings)
        ]
        
        # Sort by similarity (descending)
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        return similarities[:top_k]
    
    def clear_cache(self) -> None:
        """Clear embedding cache."""
        with self._lock:
            self._cache.clear()
            self.logger.debug("Embedding cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            "cache_size": len(self._cache),
            "cache_mb": sum(len(v) * 4 for v in self._cache.values()) / (1024 * 1024),
        }
    
    def unload(self) -> None:
        """Unload the embedding model."""
        with self._lock:
            if self._model is not None:
                del self._model
                self._model = None
                self.logger.info("Embedding model unloaded")


class MockEmbeddingGenerator:
    """Mock embedding generator for testing."""
    
    def __init__(self, embedding_dim: int = 768, **kwargs):
        self.embedding_dim = embedding_dim
        self.logger = logging.getLogger(__name__)
    
    def generate(self, texts: Union[str, List[str]]) -> Union[EmbeddingResult, List[EmbeddingResult]]:
        """Generate mock embeddings."""
        single_input = isinstance(texts, str)
        if single_input:
            texts = [texts]
        
        results = []
        for text in texts:
            # Generate deterministic mock embedding
            hash_val = int(hashlib.md5(text.encode()).hexdigest(), 16)
            np.random.seed(hash_val % (2**32))
            embedding = np.random.randn(self.embedding_dim).tolist()
            
            results.append(EmbeddingResult(
                text=text,
                embedding=embedding,
                model="mock",
                dimensions=self.embedding_dim,
            ))
        
        return results[0] if single_input else results
    
    def compute_similarity(self, emb1: List[float], emb2: List[float]) -> float:
        """Compute mock similarity."""
        return 0.5
    
    def clear_cache(self) -> None:
        """No-op for mock."""
        pass
