"""
HelixLLM - Local LLM System with RAG and Tool Use Capabilities

A production-ready local LLM system optimized for consumer hardware:
- AMD Ryzen 9 CPU
- 32GB RAM
- RTX GPU with 6GB VRAM
- 2TB NVMe SSD
"""

__version__ = "1.0.0"
__author__ = "HelixAI"

from .core.helix_llm import HelixLLM
from .core.model_manager import ModelManager
from .core.inference_engine import InferenceEngine
from .core.chat_session import ChatSession
from .core.configuration import Configuration

from .rag.document_processor import DocumentProcessor
from .rag.embedding_generator import EmbeddingGenerator
from .rag.vector_store import VectorStore
from .rag.retrieval_engine import RetrievalEngine
from .rag.context_injector import ContextInjector

from .tools.tool_registry import ToolRegistry
from .tools.tool_executor import ToolExecutor
from .tools.function_caller import FunctionCaller
from .tools.tool_schema import ToolSchema
from .tools.tool_result import ToolResult

from .api.openai_compatible_api import OpenAICompatibleAPI
from .api.chat_completion_handler import ChatCompletionHandler
from .api.model_handler import ModelHandler
from .api.streaming_response import StreamingResponse

from .utils.logger import Logger
from .utils.metrics_collector import MetricsCollector
from .utils.hardware_profiler import HardwareProfiler
from .utils.model_downloader import ModelDownloader

__all__ = [
    # Core
    "HelixLLM",
    "ModelManager",
    "InferenceEngine",
    "ChatSession",
    "Configuration",
    # RAG
    "DocumentProcessor",
    "EmbeddingGenerator",
    "VectorStore",
    "RetrievalEngine",
    "ContextInjector",
    # Tools
    "ToolRegistry",
    "ToolExecutor",
    "FunctionCaller",
    "ToolSchema",
    "ToolResult",
    # API
    "OpenAICompatibleAPI",
    "ChatCompletionHandler",
    "ModelHandler",
    "StreamingResponse",
    # Utils
    "Logger",
    "MetricsCollector",
    "HardwareProfiler",
    "ModelDownloader",
]
