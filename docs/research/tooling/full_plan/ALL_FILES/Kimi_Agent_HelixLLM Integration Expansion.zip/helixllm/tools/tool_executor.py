"""
Tool execution for HelixLLM.

Executes tool calls with parameter validation and error handling.
"""

import asyncio
import concurrent.futures
import time
from typing import Any, Dict, List, Optional, Union
import logging

from .tool_registry import ToolRegistry
from .tool_schema import ToolSchema
from .tool_result import ToolResult, BatchToolResult, ToolCall


class ToolExecutionError(Exception):
    """Exception raised during tool execution."""
    pass


class ToolExecutor:
    """
    Executes tool calls with validation and error handling.
    
    Handles parameter validation, execution, timeout, and result formatting.
    
    Attributes:
        registry: Tool registry
        default_timeout: Default execution timeout
    
    Example:
        >>> executor = ToolExecutor(registry)
        >>> result = executor.execute("calculator", {"expression": "2+2"})
    """
    
    def __init__(
        self,
        registry: ToolRegistry,
        logger: Optional[logging.Logger] = None,
        default_timeout: float = 30.0,
        max_workers: int = 4,
    ):
        """
        Initialize tool executor.
        
        Args:
            registry: Tool registry
            logger: Optional logger
            default_timeout: Default execution timeout in seconds
            max_workers: Maximum parallel workers
        """
        self.registry = registry
        self.logger = logger or logging.getLogger(__name__)
        self.default_timeout = default_timeout
        self.max_workers = max_workers
        
        # Thread pool for parallel execution
        self._executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=max_workers,
        )
    
    def execute(
        self,
        tool_name: str,
        parameters: Dict[str, Any],
        timeout: Optional[float] = None,
        validate: bool = True,
    ) -> ToolResult:
        """
        Execute a tool call.
        
        Args:
            tool_name: Name of tool to execute
            parameters: Tool parameters
            timeout: Execution timeout
            validate: Validate parameters before execution
        
        Returns:
            Tool execution result
        """
        timeout = timeout or self.default_timeout
        start_time = time.time()
        
        # Get tool
        tool = self.registry.get_tool(tool_name)
        if tool is None:
            return ToolResult.not_found(
                tool_name,
                available_tools=self.registry.list_tools(),
            )
        
        # Check if enabled
        if not tool.enabled:
            return ToolResult.error(
                tool_name,
                f"Tool '{tool_name}' is disabled",
            )
        
        # Validate parameters
        if validate:
            validation_errors = tool.schema.validate_parameters(parameters)
            if validation_errors:
                return ToolResult.invalid_parameters(
                    tool_name,
                    validation_errors,
                )
        
        # Apply defaults
        parameters = tool.schema.apply_defaults(parameters)
        
        # Execute with timeout
        try:
            execution_time = time.time() - start_time
            
            # Run in thread pool for timeout support
            future = self._executor.submit(tool.func, **parameters)
            result_data = future.result(timeout=timeout)
            
            execution_time = (time.time() - start_time) * 1000
            
            return ToolResult.success(
                tool_name=tool_name,
                data=result_data,
                execution_time_ms=execution_time,
            )
            
        except concurrent.futures.TimeoutError:
            return ToolResult.timeout(tool_name, timeout)
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            return ToolResult.error(
                tool_name=tool_name,
                error=str(e),
                execution_time_ms=execution_time,
                exception=e,
            )
    
    async def execute_async(
        self,
        tool_name: str,
        parameters: Dict[str, Any],
        timeout: Optional[float] = None,
    ) -> ToolResult:
        """
        Execute a tool call asynchronously.
        
        Args:
            tool_name: Name of tool to execute
            parameters: Tool parameters
            timeout: Execution timeout
        
        Returns:
            Tool execution result
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.execute(tool_name, parameters, timeout),
        )
    
    def execute_batch(
        self,
        tool_calls: List[Union[ToolCall, Dict[str, Any]]],
        parallel: bool = True,
        timeout: Optional[float] = None,
    ) -> BatchToolResult:
        """
        Execute multiple tool calls.
        
        Args:
            tool_calls: List of tool calls
            parallel: Execute in parallel
            timeout: Timeout per tool
        
        Returns:
            Batch result
        """
        start_time = time.time()
        
        # Convert to ToolCall objects
        calls = []
        for call in tool_calls:
            if isinstance(call, dict):
                calls.append(ToolCall(
                    tool_name=call["tool_name"],
                    parameters=call.get("parameters", {}),
                    call_id=call.get("call_id"),
                ))
            else:
                calls.append(call)
        
        results = []
        
        if parallel and len(calls) > 1:
            # Execute in parallel
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(len(calls), self.max_workers),
            ) as executor:
                futures = {
                    executor.submit(
                        self.execute,
                        call.tool_name,
                        call.parameters,
                        timeout,
                    ): call
                    for call in calls
                }
                
                for future in concurrent.futures.as_completed(futures):
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        call = futures[future]
                        results.append(ToolResult.error(
                            call.tool_name,
                            f"Execution failed: {e}",
                        ))
        else:
            # Execute sequentially
            for call in calls:
                result = self.execute(
                    call.tool_name,
                    call.parameters,
                    timeout,
                )
                results.append(result)
        
        total_time = (time.time() - start_time) * 1000
        
        return BatchToolResult(
            results=results,
            total_execution_time_ms=total_time,
        )
    
    async def execute_batch_async(
        self,
        tool_calls: List[Union[ToolCall, Dict[str, Any]]],
        parallel: bool = True,
        timeout: Optional[float] = None,
    ) -> BatchToolResult:
        """
        Execute multiple tool calls asynchronously.
        
        Args:
            tool_calls: List of tool calls
            parallel: Execute in parallel
            timeout: Timeout per tool
        
        Returns:
            Batch result
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.execute_batch(tool_calls, parallel, timeout),
        )
    
    def validate_call(
        self,
        tool_name: str,
        parameters: Dict[str, Any],
    ) -> List[str]:
        """
        Validate a tool call without executing.
        
        Args:
            tool_name: Tool name
            parameters: Parameters to validate
        
        Returns:
            List of validation errors (empty if valid)
        """
        tool = self.registry.get_tool(tool_name)
        if tool is None:
            return [f"Tool '{tool_name}' not found"]
        
        return tool.schema.validate_parameters(parameters)
    
    def get_tool_signature(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """
        Get the signature of a tool.
        
        Args:
            tool_name: Tool name
        
        Returns:
            Tool signature or None
        """
        tool = self.registry.get_tool(tool_name)
        if tool is None:
            return None
        
        return {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.schema.to_json_schema(),
        }
    
    def shutdown(self) -> None:
        """Shutdown the executor."""
        self._executor.shutdown(wait=True)
        self.logger.info("Tool executor shut down")
