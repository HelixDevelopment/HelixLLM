"""
Tool result handling for HelixLLM.

Represents and formats tool execution results.
"""

import json
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union


class ToolResultStatus(Enum):
    """Status of tool execution."""
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    INVALID_PARAMETERS = "invalid_parameters"
    NOT_FOUND = "not_found"


@dataclass
class ToolResult:
    """
    Result of tool execution.
    
    Encapsulates the output, status, and metadata of a tool call.
    
    Attributes:
        tool_name: Name of the tool that was called
        status: Execution status
        data: Result data (if successful)
        error: Error message (if failed)
        execution_time_ms: Execution time in milliseconds
        metadata: Additional metadata
    
    Example:
        >>> result = ToolResult.success("calculator", result=42)
        >>> result = ToolResult.error("calculator", "Division by zero")
    """
    
    tool_name: str
    status: ToolResultStatus
    data: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def __post_init__(self):
        """Post-initialization validation."""
        if self.status == ToolResultStatus.SUCCESS and self.data is None:
            # Allow None data for success, but log warning
            pass
        if self.status != ToolResultStatus.SUCCESS and self.error is None:
            self.error = f"Tool {self.tool_name} failed with status {self.status.value}"
    
    @classmethod
    def success(
        cls,
        tool_name: str,
        data: Any,
        execution_time_ms: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ToolResult":
        """
        Create a successful result.
        
        Args:
            tool_name: Tool name
            data: Result data
            execution_time_ms: Execution time
            metadata: Additional metadata
        
        Returns:
            ToolResult instance
        """
        return cls(
            tool_name=tool_name,
            status=ToolResultStatus.SUCCESS,
            data=data,
            execution_time_ms=execution_time_ms,
            metadata=metadata or {},
        )
    
    @classmethod
    def error(
        cls,
        tool_name: str,
        error: str,
        execution_time_ms: float = 0.0,
        exception: Optional[Exception] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ToolResult":
        """
        Create an error result.
        
        Args:
            tool_name: Tool name
            error: Error message
            execution_time_ms: Execution time
            exception: Original exception
            metadata: Additional metadata
        
        Returns:
            ToolResult instance
        """
        meta = metadata or {}
        
        if exception:
            meta["exception_type"] = type(exception).__name__
            meta["traceback"] = traceback.format_exc()
        
        return cls(
            tool_name=tool_name,
            status=ToolResultStatus.ERROR,
            error=error,
            execution_time_ms=execution_time_ms,
            metadata=meta,
        )
    
    @classmethod
    def timeout(
        cls,
        tool_name: str,
        timeout_seconds: float,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ToolResult":
        """
        Create a timeout result.
        
        Args:
            tool_name: Tool name
            timeout_seconds: Timeout duration
            metadata: Additional metadata
        
        Returns:
            ToolResult instance
        """
        return cls(
            tool_name=tool_name,
            status=ToolResultStatus.TIMEOUT,
            error=f"Tool execution timed out after {timeout_seconds}s",
            execution_time_ms=timeout_seconds * 1000,
            metadata={"timeout_seconds": timeout_seconds, **(metadata or {})},
        )
    
    @classmethod
    def invalid_parameters(
        cls,
        tool_name: str,
        validation_errors: List[str],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ToolResult":
        """
        Create an invalid parameters result.
        
        Args:
            tool_name: Tool name
            validation_errors: List of validation error messages
            metadata: Additional metadata
        
        Returns:
            ToolResult instance
        """
        return cls(
            tool_name=tool_name,
            status=ToolResultStatus.INVALID_PARAMETERS,
            error=f"Invalid parameters: {'; '.join(validation_errors)}",
            metadata={"validation_errors": validation_errors, **(metadata or {})},
        )
    
    @classmethod
    def not_found(
        cls,
        tool_name: str,
        available_tools: Optional[List[str]] = None,
    ) -> "ToolResult":
        """
        Create a not found result.
        
        Args:
            tool_name: Tool name
            available_tools: List of available tool names
        
        Returns:
            ToolResult instance
        """
        error = f"Tool '{tool_name}' not found"
        if available_tools:
            error += f". Available tools: {', '.join(available_tools)}"
        
        return cls(
            tool_name=tool_name,
            status=ToolResultStatus.NOT_FOUND,
            error=error,
            metadata={"available_tools": available_tools or []},
        )
    
    @property
    def is_success(self) -> bool:
        """Check if result is successful."""
        return self.status == ToolResultStatus.SUCCESS
    
    @property
    def is_error(self) -> bool:
        """Check if result is an error."""
        return self.status != ToolResultStatus.SUCCESS
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            "tool_name": self.tool_name,
            "status": self.status.value,
            "data": self.data,
            "error": self.error,
            "execution_time_ms": round(self.execution_time_ms, 2),
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }
    
    def to_json(self, indent: Optional[int] = None) -> str:
        """
        Convert to JSON string.
        
        Args:
            indent: JSON indentation
        
        Returns:
            JSON string
        """
        return json.dumps(self.to_dict(), indent=indent, default=str)
    
    def to_text(self) -> str:
        """
        Convert to plain text representation.
        
        Returns:
            Plain text string
        """
        if self.is_success:
            if isinstance(self.data, str):
                return self.data
            return json.dumps(self.data, indent=2, default=str)
        else:
            return f"Error: {self.error}"
    
    def to_llm_format(self) -> str:
        """
        Convert to format suitable for LLM consumption.
        
        Returns:
            Formatted string for LLM
        """
        if self.is_success:
            return f"Tool '{self.tool_name}' result:\n{self.to_text()}"
        else:
            return f"Tool '{self.tool_name}' failed: {self.error}"
    
    def __str__(self) -> str:
        """String representation."""
        if self.is_success:
            return f"ToolResult({self.tool_name}: success)"
        else:
            return f"ToolResult({self.tool_name}: {self.status.value} - {self.error})"
    
    def __repr__(self) -> str:
        """Detailed representation."""
        return f"ToolResult(tool_name={self.tool_name}, status={self.status.value})"


@dataclass
class ToolCall:
    """Represents a tool call request."""
    tool_name: str
    parameters: Dict[str, Any]
    call_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "tool_name": self.tool_name,
            "parameters": self.parameters,
            "call_id": self.call_id,
        }


@dataclass
class BatchToolResult:
    """Results of multiple tool calls."""
    results: List[ToolResult]
    total_execution_time_ms: float = 0.0
    
    def __post_init__(self):
        """Calculate total execution time."""
        if not self.total_execution_time_ms:
            self.total_execution_time_ms = sum(
                r.execution_time_ms for r in self.results
            )
    
    @property
    def successful_results(self) -> List[ToolResult]:
        """Get only successful results."""
        return [r for r in self.results if r.is_success]
    
    @property
    def failed_results(self) -> List[ToolResult]:
        """Get only failed results."""
        return [r for r in self.results if r.is_error]
    
    @property
    def success_count(self) -> int:
        """Count successful results."""
        return len(self.successful_results)
    
    @property
    def failure_count(self) -> int:
        """Count failed results."""
        return len(self.failed_results)
    
    @property
    def all_succeeded(self) -> bool:
        """Check if all results succeeded."""
        return self.failure_count == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "results": [r.to_dict() for r in self.results],
            "total_execution_time_ms": round(self.total_execution_time_ms, 2),
            "success_count": self.success_count,
            "failure_count": self.failure_count,
        }
    
    def to_text(self) -> str:
        """Convert to plain text."""
        parts = []
        for result in self.results:
            parts.append(result.to_llm_format())
        return "\n\n".join(parts)
