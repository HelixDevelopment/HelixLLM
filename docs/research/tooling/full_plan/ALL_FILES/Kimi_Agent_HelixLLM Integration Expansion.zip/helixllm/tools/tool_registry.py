"""
Tool registry for HelixLLM.

Manages registration and discovery of tools for function calling.
"""

import inspect
import threading
from typing import Any, Callable, Dict, List, Optional, Type, Union
import logging

from .tool_schema import ToolSchema, SchemaBuilder
from .tool_result import ToolResult


class RegisteredTool:
    """A registered tool with its metadata."""
    
    def __init__(
        self,
        name: str,
        func: Callable,
        schema: ToolSchema,
        description: str,
        category: Optional[str] = None,
        enabled: bool = True,
    ):
        self.name = name
        self.func = func
        self.schema = schema
        self.description = description
        self.category = category or "general"
        self.enabled = enabled
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "enabled": self.enabled,
            "schema": self.schema.to_openai_format(),
        }


class ToolRegistry:
    """
    Registry for managing tools.
    
    Provides registration, lookup, and discovery of tools for
    function calling capabilities.
    
    Attributes:
        tools: Dictionary of registered tools
    
    Example:
        >>> registry = ToolRegistry()
        >>> registry.register("calculator", calc_func, "Performs calculations")
        >>> tool = registry.get_tool("calculator")
    """
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Initialize tool registry.
        
        Args:
            logger: Optional logger
        """
        self.logger = logger or logging.getLogger(__name__)
        self._lock = threading.RLock()
        self._tools: Dict[str, RegisteredTool] = {}
        self._categories: Dict[str, List[str]] = {}
    
    def register(
        self,
        name: str,
        func: Callable,
        description: str,
        parameters: Optional[Dict[str, Any]] = None,
        schema: Optional[ToolSchema] = None,
        category: Optional[str] = None,
        enabled: bool = True,
    ) -> RegisteredTool:
        """
        Register a tool.
        
        Args:
            name: Tool name
            func: Tool function
            description: Tool description
            parameters: Parameter schema dict
            schema: Pre-built tool schema
            category: Tool category
            enabled: Whether tool is enabled
        
        Returns:
            Registered tool
        """
        with self._lock:
            # Create schema if not provided
            if schema is None:
                if parameters:
                    schema = ToolSchema(
                        name=name,
                        description=description,
                        parameters=[],  # Would parse from parameters dict
                    )
                else:
                    schema = ToolSchema.from_function(func, name, description)
            
            # Create registered tool
            tool = RegisteredTool(
                name=name,
                func=func,
                schema=schema,
                description=description,
                category=category,
                enabled=enabled,
            )
            
            # Register
            self._tools[name] = tool
            
            # Add to category
            cat = category or "general"
            if cat not in self._categories:
                self._categories[cat] = []
            if name not in self._categories[cat]:
                self._categories[cat].append(name)
            
            self.logger.info(f"Registered tool: {name}")
            
            return tool
    
    def unregister(self, name: str) -> bool:
        """
        Unregister a tool.
        
        Args:
            name: Tool name
        
        Returns:
            True if unregistered
        """
        with self._lock:
            if name in self._tools:
                tool = self._tools.pop(name)
                
                # Remove from category
                if tool.category in self._categories:
                    if name in self._categories[tool.category]:
                        self._categories[tool.category].remove(name)
                
                self.logger.info(f"Unregistered tool: {name}")
                return True
            
            return False
    
    def get_tool(self, name: str) -> Optional[RegisteredTool]:
        """
        Get a registered tool by name.
        
        Args:
            name: Tool name
        
        Returns:
            Registered tool or None
        """
        with self._lock:
            return self._tools.get(name)
    
    def get_tool_function(self, name: str) -> Optional[Callable]:
        """
        Get the function for a tool.
        
        Args:
            name: Tool name
        
        Returns:
            Tool function or None
        """
        tool = self.get_tool(name)
        return tool.func if tool else None
    
    def get_tool_schema(self, name: str) -> Optional[ToolSchema]:
        """
        Get the schema for a tool.
        
        Args:
            name: Tool name
        
        Returns:
            Tool schema or None
        """
        tool = self.get_tool(name)
        return tool.schema if tool else None
    
    def list_tools(
        self,
        category: Optional[str] = None,
        enabled_only: bool = True,
    ) -> List[str]:
        """
        List registered tool names.
        
        Args:
            category: Filter by category
            enabled_only: Only list enabled tools
        
        Returns:
            List of tool names
        """
        with self._lock:
            if category:
                names = self._categories.get(category, [])
            else:
                names = list(self._tools.keys())
            
            if enabled_only:
                names = [n for n in names if self._tools[n].enabled]
            
            return sorted(names)
    
    def list_categories(self) -> List[str]:
        """
        List all tool categories.
        
        Returns:
            List of category names
        """
        with self._lock:
            return sorted(self._categories.keys())
    
    def get_tools_in_category(self, category: str) -> List[RegisteredTool]:
        """
        Get all tools in a category.
        
        Args:
            category: Category name
        
        Returns:
            List of tools
        """
        with self._lock:
            names = self._categories.get(category, [])
            return [self._tools[n] for n in names if n in self._tools]
    
    def get_all_schemas(self) -> List[Dict[str, Any]]:
        """
        Get schemas for all enabled tools.
        
        Returns:
            List of tool schemas in OpenAI format
        """
        with self._lock:
            return [
                tool.schema.to_openai_format()
                for tool in self._tools.values()
                if tool.enabled
            ]
    
    def enable_tool(self, name: str) -> bool:
        """
        Enable a tool.
        
        Args:
            name: Tool name
        
        Returns:
            True if enabled
        """
        with self._lock:
            if name in self._tools:
                self._tools[name].enabled = True
                return True
            return False
    
    def disable_tool(self, name: str) -> bool:
        """
        Disable a tool.
        
        Args:
            name: Tool name
        
        Returns:
            True if disabled
        """
        with self._lock:
            if name in self._tools:
                self._tools[name].enabled = False
                return True
            return False
    
    def is_registered(self, name: str) -> bool:
        """
        Check if a tool is registered.
        
        Args:
            name: Tool name
        
        Returns:
            True if registered
        """
        with self._lock:
            return name in self._tools
    
    def is_enabled(self, name: str) -> bool:
        """
        Check if a tool is enabled.
        
        Args:
            name: Tool name
        
        Returns:
            True if enabled
        """
        with self._lock:
            return name in self._tools and self._tools[name].enabled
    
    def clear(self) -> None:
        """Clear all registered tools."""
        with self._lock:
            self._tools.clear()
            self._categories.clear()
            self.logger.info("Cleared all tools")
    
    def register_builtin_tools(self) -> None:
        """Register built-in tools."""
        # Calculator tool
        self.register(
            name="calculator",
            func=self._calculator,
            description="Perform mathematical calculations",
            schema=SchemaBuilder("calculator", "Perform mathematical calculations")
                .add_string("expression", "Mathematical expression to evaluate", required=True)
                .build(),
            category="math",
        )
        
        # Date/time tool
        self.register(
            name="get_current_time",
            func=self._get_current_time,
            description="Get the current date and time",
            category="datetime",
        )
        
        self.logger.info("Registered built-in tools")
    
    def _calculator(self, expression: str) -> Union[int, float]:
        """Built-in calculator tool."""
        # Safe evaluation - only allow basic math
        allowed_names = {
            "abs": abs,
            "max": max,
            "min": min,
            "pow": pow,
            "round": round,
            "sum": sum,
        }
        
        # Basic safety check
        if any(c in expression for c in "__{}[]'"):
            raise ValueError("Invalid characters in expression")
        
        try:
            result = eval(expression, {"__builtins__": {}}, allowed_names)
            return result
        except Exception as e:
            raise ValueError(f"Invalid expression: {e}")
    
    def _get_current_time(self) -> str:
        """Built-in time tool."""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert registry to dictionary."""
        with self._lock:
            return {
                "tools": {name: tool.to_dict() for name, tool in self._tools.items()},
                "categories": self._categories,
                "total_count": len(self._tools),
                "enabled_count": sum(1 for t in self._tools.values() if t.enabled),
            }


# Decorator for registering tools
def tool(
    name: Optional[str] = None,
    description: Optional[str] = None,
    category: Optional[str] = None,
):
    """
    Decorator for registering tools.
    
    Args:
        name: Tool name (uses function name if not specified)
        description: Tool description (uses docstring if not specified)
        category: Tool category
    
    Example:
        >>> registry = ToolRegistry()
        >>> @tool(registry, description="Adds two numbers")
        ... def add(a: int, b: int) -> int:
        ...     return a + b
    """
    def decorator(func: Callable) -> Callable:
        func._tool_name = name or func.__name__
        func._tool_description = description or func.__doc__ or ""
        func._tool_category = category
        func._is_tool = True
        return func
    
    return decorator
