"""
Function calling for HelixLLM.

Parses and handles function calls from LLM output.
"""

import json
import re
from typing import Any, Dict, List, Optional, Union
import logging

from .tool_registry import ToolRegistry
from .tool_result import ToolCall


class FunctionCaller:
    """
    Parses and handles function calls from LLM output.
    
    Supports multiple formats for function calling including:
    - JSON format
    - XML-like tags
    - Natural language
    
    Attributes:
        registry: Tool registry
    
    Example:
        >>> caller = FunctionCaller(registry)
        >>> calls = caller.detect_tool_calls(llm_output)
    """
    
    def __init__(
        self,
        registry: ToolRegistry,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize function caller.
        
        Args:
            registry: Tool registry
            logger: Optional logger
        """
        self.registry = registry
        self.logger = logger or logging.getLogger(__name__)
    
    def detect_tool_calls(self, text: str) -> List[ToolCall]:
        """
        Detect tool calls in text.
        
        Tries multiple parsing strategies.
        
        Args:
            text: Text to parse
        
        Returns:
            List of detected tool calls
        """
        calls = []
        
        # Try JSON format
        json_calls = self._parse_json_calls(text)
        calls.extend(json_calls)
        
        # Try XML format
        xml_calls = self._parse_xml_calls(text)
        calls.extend(xml_calls)
        
        # Try markdown code blocks
        code_calls = self._parse_code_block_calls(text)
        calls.extend(code_calls)
        
        # Remove duplicates
        seen = set()
        unique_calls = []
        for call in calls:
            key = (call.tool_name, json.dumps(call.parameters, sort_keys=True))
            if key not in seen:
                seen.add(key)
                unique_calls.append(call)
        
        return unique_calls
    
    def _parse_json_calls(self, text: str) -> List[ToolCall]:
        """Parse JSON-formatted tool calls."""
        calls = []
        
        # Pattern for function call JSON
        patterns = [
            # OpenAI format
            r'\{\s*"name"\s*:\s*"([^"]+)"\s*,\s*"arguments"\s*:\s*(\{[^}]*\})\s*\}',
            # Simple format
            r'\{\s*"tool"\s*:\s*"([^"]+)"\s*,\s*"parameters"\s*:\s*(\{[^}]*\})\s*\}',
            # Alternative format
            r'\{\s*"function"\s*:\s*"([^"]+)"\s*,\s*"args"\s*:\s*(\{[^}]*\})\s*\}',
        ]
        
        for pattern in patterns:
            matches = re.finditer(pattern, text, re.DOTALL)
            for match in matches:
                try:
                    tool_name = match.group(1)
                    args_json = match.group(2)
                    parameters = json.loads(args_json)
                    
                    if self.registry.is_registered(tool_name):
                        calls.append(ToolCall(
                            tool_name=tool_name,
                            parameters=parameters,
                        ))
                except (json.JSONDecodeError, IndexError):
                    continue
        
        # Try finding JSON objects with tool names as keys
        try:
            # Look for {"tool_name": {"param": value}}
            registered_tools = set(self.registry.list_tools())
            
            # Find all JSON objects
            json_pattern = r'\{[^{}]*\}'
            for match in re.finditer(json_pattern, text):
                try:
                    obj = json.loads(match.group())
                    for key, value in obj.items():
                        if key in registered_tools and isinstance(value, dict):
                            calls.append(ToolCall(
                                tool_name=key,
                                parameters=value,
                            ))
                except json.JSONDecodeError:
                    continue
        except Exception:
            pass
        
        return calls
    
    def _parse_xml_calls(self, text: str) -> List[ToolCall]:
        """Parse XML-like tool calls."""
        calls = []
        
        # Pattern: <tool name="tool_name"><param>value</param></tool>
        tool_pattern = r'<tool\s+name="([^"]+)"[^>]*>(.*?)</tool>'
        
        matches = re.finditer(tool_pattern, text, re.DOTALL)
        for match in matches:
            try:
                tool_name = match.group(1)
                content = match.group(2)
                
                # Parse parameters from content
                parameters = {}
                param_pattern = r'<(\w+)>(.*?)</\1>'
                for param_match in re.finditer(param_pattern, content, re.DOTALL):
                    param_name = param_match.group(1)
                    param_value = param_match.group(2).strip()
                    
                    # Try to parse as JSON
                    try:
                        param_value = json.loads(param_value)
                    except json.JSONDecodeError:
                        pass
                    
                    parameters[param_name] = param_value
                
                if self.registry.is_registered(tool_name):
                    calls.append(ToolCall(
                        tool_name=tool_name,
                        parameters=parameters,
                    ))
            except Exception:
                continue
        
        return calls
    
    def _parse_code_block_calls(self, text: str) -> List[ToolCall]:
        """Parse tool calls in markdown code blocks."""
        calls = []
        
        # Pattern: ```json\n{...}\n```
        code_pattern = r'```(?:json)?\s*\n(.*?)\n```'
        
        matches = re.finditer(code_pattern, text, re.DOTALL)
        for match in matches:
            try:
                content = match.group(1).strip()
                obj = json.loads(content)
                
                # Check for function call format
                if "name" in obj and "arguments" in obj:
                    tool_name = obj["name"]
                    parameters = obj["arguments"]
                    
                    if isinstance(parameters, str):
                        parameters = json.loads(parameters)
                    
                    if self.registry.is_registered(tool_name):
                        calls.append(ToolCall(
                            tool_name=tool_name,
                            parameters=parameters,
                        ))
                
                # Check for tool as key
                elif isinstance(obj, dict):
                    registered_tools = set(self.registry.list_tools())
                    for key, value in obj.items():
                        if key in registered_tools and isinstance(value, dict):
                            calls.append(ToolCall(
                                tool_name=key,
                                parameters=value,
                            ))
                
            except (json.JSONDecodeError, Exception):
                continue
        
        return calls
    
    def format_tool_call(
        self,
        tool_name: str,
        parameters: Dict[str, Any],
        format: str = "json",
    ) -> str:
        """
        Format a tool call for LLM consumption.
        
        Args:
            tool_name: Tool name
            parameters: Tool parameters
            format: Output format ("json", "xml")
        
        Returns:
            Formatted tool call
        """
        if format == "json":
            return json.dumps({
                "name": tool_name,
                "arguments": parameters,
            }, indent=2)
        
        elif format == "xml":
            params_xml = "\n".join(
                f"  <{k}>{json.dumps(v)}</{k}>"
                for k, v in parameters.items()
            )
            return f'<tool name="{tool_name}">\n{params_xml}\n</tool>'
        
        else:
            raise ValueError(f"Unknown format: {format}")
    
    def create_tool_prompt(
        self,
        user_query: str,
        available_tools: Optional[List[str]] = None,
    ) -> str:
        """
        Create a prompt that instructs the LLM to use tools.
        
        Args:
            user_query: User's query
            available_tools: List of available tool names (uses all if not specified)
        
        Returns:
            Enhanced prompt with tool instructions
        """
        # Get tool schemas
        if available_tools:
            tools = [
                self.registry.get_tool(name)
                for name in available_tools
                if self.registry.is_registered(name)
            ]
        else:
            tools = [
                self.registry.get_tool(name)
                for name in self.registry.list_tools()
            ]
        
        # Build tool descriptions
        tool_descriptions = []
        for tool in tools:
            if tool:
                schema = tool.schema.to_json_schema()
                params_desc = self._format_parameters(schema.get("properties", {}))
                
                tool_descriptions.append(
                    f"- {tool.name}: {tool.description}\n  Parameters: {params_desc}"
                )
        
        # Create prompt
        prompt = f"""You have access to the following tools:

{chr(10).join(tool_descriptions)}

To use a tool, respond with a JSON object in this format:
```json
{{
  "name": "tool_name",
  "arguments": {{
    "param1": "value1",
    "param2": "value2"
  }}
}}
```

User query: {user_query}

If you need to use a tool, respond ONLY with the JSON object. Otherwise, answer directly."""
        
        return prompt
    
    def _format_parameters(self, properties: Dict[str, Any]) -> str:
        """Format parameter descriptions."""
        params = []
        for name, prop in properties.items():
            param_type = prop.get("type", "any")
            param_desc = prop.get("description", "")
            params.append(f"{name} ({param_type})")
        
        return ", ".join(params) if params else "none"
    
    def extract_final_response(self, text: str) -> str:
        """
        Extract the final response from text containing tool calls.
        
        Args:
            text: Text that may contain tool calls
        
        Returns:
            Clean response text
        """
        # Remove JSON tool calls
        text = re.sub(r'\{[^}]*"name"[^}]*"arguments"[^}]*\}', '', text)
        
        # Remove XML tool calls
        text = re.sub(r'<tool[^>]*>.*?</tool>', '', text, flags=re.DOTALL)
        
        # Remove code blocks
        text = re.sub(r'```.*?```', '', text, flags=re.DOTALL)
        
        # Clean up
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        return text.strip()
