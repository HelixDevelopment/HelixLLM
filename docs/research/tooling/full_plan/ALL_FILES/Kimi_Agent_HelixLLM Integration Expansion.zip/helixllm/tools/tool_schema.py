"""
Tool schema validation for HelixLLM.

JSON Schema validation for tool definitions and parameters.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union
import json
import logging

try:
    import jsonschema
    from jsonschema import validate, ValidationError as JSONSchemaValidationError
    JSONSCHEMA_AVAILABLE = True
except ImportError:
    JSONSCHEMA_AVAILABLE = False
    JSONSchemaValidationError = Exception


class SchemaValidationError(Exception):
    """Exception raised when schema validation fails."""
    pass


@dataclass
class ParameterSchema:
    """Schema for a tool parameter."""
    name: str
    type: str
    description: str
    required: bool = False
    default: Any = None
    enum: Optional[List[Any]] = None
    minimum: Optional[Union[int, float]] = None
    maximum: Optional[Union[int, float]] = None
    
    def to_json_schema(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        schema: Dict[str, Any] = {
            "type": self.type,
            "description": self.description,
        }
        
        if self.enum is not None:
            schema["enum"] = self.enum
        if self.minimum is not None:
            schema["minimum"] = self.minimum
        if self.maximum is not None:
            schema["maximum"] = self.maximum
        if self.default is not None:
            schema["default"] = self.default
        
        return schema


@dataclass
class ToolSchema:
    """
    JSON Schema definition for a tool.
    
    Defines the structure and validation rules for tool parameters
    following the OpenAI function calling format.
    
    Attributes:
        name: Tool name
        description: Tool description
        parameters: List of parameter schemas
        required: List of required parameter names
    
    Example:
        >>> schema = ToolSchema(
        ...     name="get_weather",
        ...     description="Get weather for a location",
        ...     parameters=[
        ...         ParameterSchema("location", "string", "City name", required=True),
        ...         ParameterSchema("unit", "string", "Temperature unit", enum=["C", "F"]),
        ...     ],
        ... )
    """
    
    name: str
    description: str
    parameters: List[ParameterSchema] = field(default_factory=list)
    required: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate schema after initialization."""
        if not self.name:
            raise ValueError("Tool name is required")
        if not self.description:
            raise ValueError("Tool description is required")
        
        # Auto-populate required from parameters
        param_required = [p.name for p in self.parameters if p.required]
        for req in param_required:
            if req not in self.required:
                self.required.append(req)
    
    def to_json_schema(self) -> Dict[str, Any]:
        """
        Convert to JSON Schema format.
        
        Returns:
            JSON Schema dictionary
        """
        properties = {}
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
        
        return {
            "type": "object",
            "properties": properties,
            "required": self.required,
        }
    
    def to_openai_format(self) -> Dict[str, Any]:
        """
        Convert to OpenAI function calling format.
        
        Returns:
            OpenAI format dictionary
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.to_json_schema(),
            },
        }
    
    def validate_parameters(self, parameters: Dict[str, Any]) -> List[str]:
        """
        Validate parameters against schema.
        
        Args:
            parameters: Parameters to validate
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Check required parameters
        for req in self.required:
            if req not in parameters:
                errors.append(f"Missing required parameter: {req}")
        
        # Validate parameter types
        for name, value in parameters.items():
            param_schema = next((p for p in self.parameters if p.name == name), None)
            if param_schema:
                type_errors = self._validate_type(name, value, param_schema)
                errors.extend(type_errors)
        
        # Use jsonschema if available
        if JSONSCHEMA_AVAILABLE:
            try:
                validate(instance=parameters, schema=self.to_json_schema())
            except JSONSchemaValidationError as e:
                errors.append(str(e))
        
        return errors
    
    def _validate_type(
        self,
        name: str,
        value: Any,
        param: ParameterSchema,
    ) -> List[str]:
        """Validate a parameter value against its schema."""
        errors = []
        
        # Type validation
        type_map = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        
        expected_type = type_map.get(param.type)
        if expected_type and not isinstance(value, expected_type):
            errors.append(f"Parameter '{name}' should be of type {param.type}")
        
        # Enum validation
        if param.enum is not None and value not in param.enum:
            errors.append(f"Parameter '{name}' must be one of: {param.enum}")
        
        # Range validation
        if param.type in ("integer", "number"):
            if param.minimum is not None and value < param.minimum:
                errors.append(f"Parameter '{name}' must be >= {param.minimum}")
            if param.maximum is not None and value > param.maximum:
                errors.append(f"Parameter '{name}' must be <= {param.maximum}")
        
        return errors
    
    def apply_defaults(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply default values to parameters.
        
        Args:
            parameters: Input parameters
        
        Returns:
            Parameters with defaults applied
        """
        result = dict(parameters)
        
        for param in self.parameters:
            if param.name not in result and param.default is not None:
                result[param.name] = param.default
        
        return result
    
    @classmethod
    def from_function(
        cls,
        func: Callable,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> "ToolSchema":
        """
        Create schema from a function.
        
        Args:
            func: Function to create schema from
            name: Override function name
            description: Override function description
        
        Returns:
            Tool schema
        """
        import inspect
        
        func_name = name or func.__name__
        func_description = description or func.__doc__ or f"Function {func_name}"
        
        # Parse function signature
        sig = inspect.signature(func)
        parameters = []
        required = []
        
        for param_name, param in sig.parameters.items():
            param_type = "string"  # Default type
            param_required = param.default is inspect.Parameter.empty
            param_default = None if param_required else param.default
            
            # Try to infer type from annotation
            if param.annotation != inspect.Parameter.empty:
                if param.annotation == str:
                    param_type = "string"
                elif param.annotation == int:
                    param_type = "integer"
                elif param.annotation == float:
                    param_type = "number"
                elif param.annotation == bool:
                    param_type = "boolean"
                elif param.annotation == list:
                    param_type = "array"
                elif param.annotation == dict:
                    param_type = "object"
            
            parameters.append(ParameterSchema(
                name=param_name,
                type=param_type,
                description=f"Parameter {param_name}",
                required=param_required,
                default=param_default,
            ))
            
            if param_required:
                required.append(param_name)
        
        return cls(
            name=func_name,
            description=func_description,
            parameters=parameters,
            required=required,
        )
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ToolSchema":
        """
        Create schema from dictionary.
        
        Args:
            data: Schema dictionary
        
        Returns:
            Tool schema
        """
        parameters = []
        
        for param_name, param_data in data.get("parameters", {}).items():
            parameters.append(ParameterSchema(
                name=param_name,
                type=param_data.get("type", "string"),
                description=param_data.get("description", ""),
                required=param_name in data.get("required", []),
                default=param_data.get("default"),
                enum=param_data.get("enum"),
                minimum=param_data.get("minimum"),
                maximum=param_data.get("maximum"),
            ))
        
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            parameters=parameters,
            required=data.get("required", []),
        )


class SchemaBuilder:
    """Builder for creating tool schemas."""
    
    def __init__(self, name: str, description: str):
        """
        Initialize schema builder.
        
        Args:
            name: Tool name
            description: Tool description
        """
        self.name = name
        self.description = description
        self.parameters: List[ParameterSchema] = []
    
    def add_string(
        self,
        name: str,
        description: str,
        required: bool = False,
        default: Optional[str] = None,
        enum: Optional[List[str]] = None,
    ) -> "SchemaBuilder":
        """Add string parameter."""
        self.parameters.append(ParameterSchema(
            name=name,
            type="string",
            description=description,
            required=required,
            default=default,
            enum=enum,
        ))
        return self
    
    def add_integer(
        self,
        name: str,
        description: str,
        required: bool = False,
        default: Optional[int] = None,
        minimum: Optional[int] = None,
        maximum: Optional[int] = None,
    ) -> "SchemaBuilder":
        """Add integer parameter."""
        self.parameters.append(ParameterSchema(
            name=name,
            type="integer",
            description=description,
            required=required,
            default=default,
            minimum=minimum,
            maximum=maximum,
        ))
        return self
    
    def add_number(
        self,
        name: str,
        description: str,
        required: bool = False,
        default: Optional[float] = None,
        minimum: Optional[float] = None,
        maximum: Optional[float] = None,
    ) -> "SchemaBuilder":
        """Add number parameter."""
        self.parameters.append(ParameterSchema(
            name=name,
            type="number",
            description=description,
            required=required,
            default=default,
            minimum=minimum,
            maximum=maximum,
        ))
        return self
    
    def add_boolean(
        self,
        name: str,
        description: str,
        required: bool = False,
        default: Optional[bool] = None,
    ) -> "SchemaBuilder":
        """Add boolean parameter."""
        self.parameters.append(ParameterSchema(
            name=name,
            type="boolean",
            description=description,
            required=required,
            default=default,
        ))
        return self
    
    def add_array(
        self,
        name: str,
        description: str,
        required: bool = False,
        default: Optional[List[Any]] = None,
    ) -> "SchemaBuilder":
        """Add array parameter."""
        self.parameters.append(ParameterSchema(
            name=name,
            type="array",
            description=description,
            required=required,
            default=default,
        ))
        return self
    
    def add_object(
        self,
        name: str,
        description: str,
        required: bool = False,
        default: Optional[Dict[str, Any]] = None,
    ) -> "SchemaBuilder":
        """Add object parameter."""
        self.parameters.append(ParameterSchema(
            name=name,
            type="object",
            description=description,
            required=required,
            default=default,
        ))
        return self
    
    def build(self) -> ToolSchema:
        """Build and return the tool schema."""
        return ToolSchema(
            name=self.name,
            description=self.description,
            parameters=self.parameters,
        )
