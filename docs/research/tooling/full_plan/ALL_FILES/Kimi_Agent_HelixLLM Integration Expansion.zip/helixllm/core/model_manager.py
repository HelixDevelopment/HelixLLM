"""
Model management for HelixLLM.

Handles loading, unloading, and lifecycle management of llama.cpp models.
"""

import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import logging

# llama-cpp-python import
try:
    from llama_cpp import Llama, LlamaCache
    LLAMA_CPP_AVAILABLE = True
except ImportError:
    LLAMA_CPP_AVAILABLE = False
    Llama = None
    LlamaCache = None

from .configuration import Configuration, ModelConfig


@dataclass
class ModelInfo:
    """Information about a loaded model."""
    path: str
    name: str
    context_length: int
    vocab_size: int
    embedding_length: int
    loaded_at: float
    last_used: float
    use_count: int
    
    @property
    def loaded_duration_seconds(self) -> float:
        """Time since model was loaded."""
        return time.time() - self.loaded_at
    
    @property
    def idle_duration_seconds(self) -> float:
        """Time since model was last used."""
        return time.time() - self.last_used


class ModelLoadError(Exception):
    """Exception raised when model fails to load."""
    pass


class ModelNotFoundError(Exception):
    """Exception raised when model is not found."""
    pass


class ModelManager:
    """
    Manages llama.cpp model loading and lifecycle.
    
    Handles model loading with optimized parameters, caching, and automatic
    unloading based on resource constraints.
    
    Attributes:
        config: Configuration instance
        current_model: Currently loaded model
        model_info: Information about loaded model
    
    Example:
        >>> manager = ModelManager(config)
        >>> manager.load("path/to/model.gguf")
        >>> output = manager.current_model("Hello, ")
    """
    
    def __init__(
        self,
        config: Configuration,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize model manager.
        
        Args:
            config: Configuration instance
            logger: Optional logger
        """
        if not LLAMA_CPP_AVAILABLE:
            raise ImportError(
                "llama-cpp-python is required. "
                "Install with: pip install llama-cpp-python"
            )
        
        self.config = config
        self.logger = logger or logging.getLogger(__name__)
        
        self._lock = threading.RLock()
        self._model: Optional[Llama] = None
        self._model_info: Optional[ModelInfo] = None
        self._cache: Optional[LlamaCache] = None
        self._loaded_models: Dict[str, Dict[str, Any]] = {}
    
    @property
    def current_model(self) -> Optional[Llama]:
        """Get currently loaded model."""
        with self._lock:
            return self._model
    
    @property
    def model_info(self) -> Optional[ModelInfo]:
        """Get information about loaded model."""
        with self._lock:
            return self._model_info
    
    @property
    def is_loaded(self) -> bool:
        """Check if a model is currently loaded."""
        with self._lock:
            return self._model is not None
    
    def load(
        self,
        model_path: Optional[str] = None,
        config: Optional[ModelConfig] = None,
        **kwargs,
    ) -> Llama:
        """
        Load a model from file.
        
        Args:
            model_path: Path to GGUF model (uses config if not specified)
            config: Model configuration (uses self.config if not specified)
            **kwargs: Additional arguments for Llama constructor
        
        Returns:
            Loaded Llama model
        
        Raises:
            ModelLoadError: If model fails to load
            ModelNotFoundError: If model file not found
        """
        with self._lock:
            model_path = model_path or self.config.model.path
            config = config or self.config.model
            
            if not model_path:
                raise ValueError("Model path not specified")
            
            model_path = Path(model_path)
            
            if not model_path.exists():
                raise ModelNotFoundError(f"Model not found: {model_path}")
            
            # Check if already loaded
            if self._model is not None and self._model_info is not None:
                if Path(self._model_info.path) == model_path:
                    self.logger.debug(f"Model already loaded: {model_path.name}")
                    self._model_info.last_used = time.time()
                    self._model_info.use_count += 1
                    return self._model
                else:
                    # Unload current model
                    self.unload()
            
            self.logger.info(f"Loading model: {model_path.name}")
            
            try:
                # Build load parameters
                load_kwargs = self._build_load_kwargs(config, kwargs)
                
                # Load the model
                start_time = time.time()
                self._model = Llama(
                    model_path=str(model_path),
                    verbose=self.logger.isEnabledFor(logging.DEBUG),
                    **load_kwargs,
                )
                load_time = time.time() - start_time
                
                # Setup cache
                self._cache = LlamaCache()
                self._model.set_cache(self._cache)
                
                # Create model info
                self._model_info = ModelInfo(
                    path=str(model_path),
                    name=model_path.name,
                    context_length=self._model.n_ctx(),
                    vocab_size=self._model.n_vocab(),
                    embedding_length=self._model.n_embd(),
                    loaded_at=time.time(),
                    last_used=time.time(),
                    use_count=1,
                )
                
                self.logger.info(
                    f"Model loaded in {load_time:.2f}s: "
                    f"{self._model_info.name} "
                    f"(ctx={self._model_info.context_length}, "
                    f"vocab={self._model_info.vocab_size})"
                )
                
                return self._model
                
            except Exception as e:
                self._model = None
                self._model_info = None
                raise ModelLoadError(f"Failed to load model: {e}")
    
    def unload(self) -> bool:
        """
        Unload the current model.
        
        Returns:
            True if model was unloaded, False if no model was loaded
        """
        with self._lock:
            if self._model is None:
                return False
            
            self.logger.info(f"Unloading model: {self._model_info.name if self._model_info else 'unknown'}")
            
            # Clear cache
            if self._cache:
                self._cache.clear()
            
            # Release model
            del self._model
            self._model = None
            self._model_info = None
            self._cache = None
            
            return True
    
    def reload(self) -> Llama:
        """
        Reload the current model.
        
        Returns:
            Reloaded model
        """
        with self._lock:
            if self._model_info is None:
                raise ModelLoadError("No model to reload")
            
            path = self._model_info.path
            self.unload()
            return self.load(path)
    
    def _build_load_kwargs(
        self,
        config: ModelConfig,
        override_kwargs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Build kwargs for Llama constructor."""
        kwargs = {
            "n_ctx": config.context_length,
            "n_batch": config.batch_size,
        }
        
        # GPU layers
        if config.gpu_layers >= 0:
            kwargs["n_gpu_layers"] = config.gpu_layers
        elif self.config.hardware.use_gpu:
            kwargs["n_gpu_layers"] = -1  # Auto
        
        # Threads
        if config.threads > 0:
            kwargs["n_threads"] = config.threads
            kwargs["n_threads_batch"] = config.threads
        
        # RoPE settings
        if config.rope_scaling:
            kwargs["rope_scaling_type"] = config.rope_scaling
        if config.rope_freq_base != 10000.0:
            kwargs["rope_freq_base"] = config.rope_freq_base
        
        # Hardware settings
        kwargs["use_mmap"] = self.config.hardware.use_mmap
        kwargs["use_mlock"] = self.config.hardware.use_mlock
        kwargs["offload_kqv"] = self.config.hardware.offload_kqv
        
        # Flash attention
        if self.config.hardware.flash_attention:
            kwargs["flash_attn"] = True
        
        # Tensor split for multi-GPU
        if self.config.hardware.tensor_split:
            kwargs["tensor_split"] = self.config.hardware.tensor_split
        
        # Apply overrides
        kwargs.update(override_kwargs)
        
        # Remove None values
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        
        return kwargs
    
    def get_embeddings(self, text: str) -> List[float]:
        """
        Get embeddings for text using loaded model.
        
        Args:
            text: Input text
        
        Returns:
            Embedding vector
        """
        with self._lock:
            if self._model is None:
                raise ModelLoadError("No model loaded")
            
            self._model_info.last_used = time.time()
            return self._model.embed(text)
    
    def tokenize(self, text: str) -> List[int]:
        """
        Tokenize text using loaded model.
        
        Args:
            text: Input text
        
        Returns:
            List of token IDs
        """
        with self._lock:
            if self._model is None:
                raise ModelLoadError("No model loaded")
            
            return self._model.tokenize(text.encode("utf-8"))
    
    def detokenize(self, tokens: List[int]) -> str:
        """
        Detokenize tokens using loaded model.
        
        Args:
            tokens: List of token IDs
        
        Returns:
            Decoded text
        """
        with self._lock:
            if self._model is None:
                raise ModelLoadError("No model loaded")
            
            return self._model.detokenize(tokens).decode("utf-8", errors="ignore")
    
    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text.
        
        Args:
            text: Input text
        
        Returns:
            Token count
        """
        return len(self.tokenize(text))
    
    def get_model_metadata(self) -> Dict[str, Any]:
        """
        Get metadata from loaded model.
        
        Returns:
            Model metadata dictionary
        """
        with self._lock:
            if self._model is None:
                raise ModelLoadError("No model loaded")
            
            metadata = {}
            
            # Try to get metadata from model
            if hasattr(self._model, "metadata"):
                metadata = self._model.metadata
            
            # Add our info
            if self._model_info:
                metadata.update({
                    "helixllm.loaded_at": self._model_info.loaded_at,
                    "helixllm.use_count": self._model_info.use_count,
                })
            
            return metadata
    
    def clear_cache(self) -> None:
        """Clear model KV cache."""
        with self._lock:
            if self._cache:
                self._cache.clear()
                self.logger.debug("Model cache cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get model statistics.
        
        Returns:
            Statistics dictionary
        """
        with self._lock:
            stats = {
                "loaded": self.is_loaded,
            }
            
            if self._model_info:
                stats.update({
                    "name": self._model_info.name,
                    "path": self._model_info.path,
                    "context_length": self._model_info.context_length,
                    "vocab_size": self._model_info.vocab_size,
                    "embedding_length": self._model_info.embedding_length,
                    "loaded_duration_seconds": self._model_info.loaded_duration_seconds,
                    "idle_duration_seconds": self._model_info.idle_duration_seconds,
                    "use_count": self._model_info.use_count,
                })
            
            return stats
