"""
Inference engine for HelixLLM.

Handles text generation with support for streaming, batched generation,
and various sampling parameters.
"""

import queue
import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, AsyncIterator, Callable, Dict, Iterator, List, Optional, Union
import logging

from .configuration import Configuration, GenerationConfig
from .model_manager import ModelManager


class GenerationState(Enum):
    """State of text generation."""
    IDLE = "idle"
    GENERATING = "generating"
    COMPLETED = "completed"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class GenerationResult:
    """Result of text generation."""
    text: str
    tokens_generated: int
    tokens_per_second: float
    generation_time_seconds: float
    stop_reason: str  # "max_tokens", "stop_sequence", "eos", "user_cancel"
    finish_reason: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "text": self.text,
            "tokens_generated": self.tokens_generated,
            "tokens_per_second": round(self.tokens_per_second, 2),
            "generation_time_seconds": round(self.generation_time_seconds, 2),
            "stop_reason": self.stop_reason,
            "finish_reason": self.finish_reason,
        }


@dataclass
class StreamChunk:
    """Chunk of streamed generation."""
    text: str
    token_id: int
    is_finished: bool = False
    finish_reason: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "text": self.text,
            "token_id": self.token_id,
            "is_finished": self.is_finished,
            "finish_reason": self.finish_reason,
        }


class InferenceEngine:
    """
    Text generation engine for HelixLLM.
    
    Provides synchronous and streaming text generation with support for
    various sampling parameters and stop sequences.
    
    Attributes:
        model_manager: Model manager instance
        config: Generation configuration
    
    Example:
        >>> engine = InferenceEngine(model_manager, config)
        >>> result = engine.generate("Hello, ", max_tokens=100)
        >>> for chunk in engine.generate_stream("Hello, "):
        ...     print(chunk.text, end="")
    """
    
    def __init__(
        self,
        model_manager: ModelManager,
        config: Optional[Configuration] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize inference engine.
        
        Args:
            model_manager: Model manager instance
            config: Configuration instance
            logger: Optional logger
        """
        self.model_manager = model_manager
        self.config = config or Configuration()
        self.logger = logger or logging.getLogger(__name__)
        
        self._lock = threading.RLock()
        self._state = GenerationState.IDLE
        self._stop_event = threading.Event()
        self._current_generation: Optional[threading.Thread] = None
    
    @property
    def state(self) -> GenerationState:
        """Get current generation state."""
        with self._lock:
            return self._state
    
    def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        stop_sequences: Optional[List[str]] = None,
        seed: Optional[int] = None,
        **kwargs,
    ) -> GenerationResult:
        """
        Generate text synchronously.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            top_k: Top-k sampling parameter
            repetition_penalty: Repetition penalty
            stop_sequences: Sequences to stop generation
            seed: Random seed
            **kwargs: Additional generation parameters
        
        Returns:
            Generation result
        """
        with self._lock:
            if self._state == GenerationState.GENERATING:
                raise RuntimeError("Generation already in progress")
            
            self._state = GenerationState.GENERATING
            self._stop_event.clear()
        
        try:
            model = self.model_manager.current_model
            if model is None:
                raise RuntimeError("No model loaded")
            
            # Build generation parameters
            gen_kwargs = self._build_generation_kwargs(
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                repetition_penalty=repetition_penalty,
                stop_sequences=stop_sequences,
                seed=seed,
                **kwargs,
            )
            
            self.logger.debug(f"Generating with params: {gen_kwargs}")
            
            # Generate
            start_time = time.time()
            output = model(
                prompt,
                **gen_kwargs,
            )
            generation_time = time.time() - start_time
            
            # Extract generated text
            if isinstance(output, dict):
                generated_text = output.get("choices", [{}])[0].get("text", "")
                tokens_generated = output.get("usage", {}).get("completion_tokens", 0)
            else:
                generated_text = str(output)
                tokens_generated = len(self.model_manager.tokenize(generated_text))
            
            tokens_per_second = tokens_generated / generation_time if generation_time > 0 else 0
            
            # Determine stop reason
            stop_reason = self._determine_stop_reason(
                generated_text, stop_sequences or [], tokens_generated, max_tokens
            )
            
            result = GenerationResult(
                text=generated_text,
                tokens_generated=tokens_generated,
                tokens_per_second=tokens_per_second,
                generation_time_seconds=generation_time,
                stop_reason=stop_reason,
                finish_reason=stop_reason,
            )
            
            self._state = GenerationState.COMPLETED
            return result
            
        except Exception as e:
            self._state = GenerationState.ERROR
            self.logger.error(f"Generation failed: {e}")
            raise
    
    def generate_stream(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        stop_sequences: Optional[List[str]] = None,
        seed: Optional[int] = None,
        **kwargs,
    ) -> Iterator[StreamChunk]:
        """
        Generate text with streaming output.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            top_k: Top-k sampling parameter
            repetition_penalty: Repetition penalty
            stop_sequences: Sequences to stop generation
            seed: Random seed
            **kwargs: Additional generation parameters
        
        Yields:
            Stream chunks
        """
        with self._lock:
            if self._state == GenerationState.GENERATING:
                raise RuntimeError("Generation already in progress")
            
            self._state = GenerationState.GENERATING
            self._stop_event.clear()
        
        try:
            model = self.model_manager.current_model
            if model is None:
                raise RuntimeError("No model loaded")
            
            # Build generation parameters
            gen_kwargs = self._build_generation_kwargs(
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                repetition_penalty=repetition_penalty,
                stop_sequences=stop_sequences,
                seed=seed,
                stream=True,
                **kwargs,
            )
            
            self.logger.debug("Starting streaming generation")
            
            # Stream generation
            for output in model(prompt, **gen_kwargs):
                if self._stop_event.is_set():
                    self._state = GenerationState.STOPPED
                    yield StreamChunk(
                        text="",
                        token_id=-1,
                        is_finished=True,
                        finish_reason="stop",
                    )
                    return
                
                # Extract text from output
                if isinstance(output, dict):
                    text = output.get("choices", [{}])[0].get("text", "")
                    finish_reason = output.get("choices", [{}])[0].get("finish_reason")
                else:
                    text = str(output)
                    finish_reason = None
                
                is_finished = finish_reason is not None
                
                yield StreamChunk(
                    text=text,
                    token_id=0,  # Would need to extract from output
                    is_finished=is_finished,
                    finish_reason=finish_reason,
                )
                
                if is_finished:
                    break
            
            self._state = GenerationState.COMPLETED
            
        except Exception as e:
            self._state = GenerationState.ERROR
            self.logger.error(f"Streaming generation failed: {e}")
            raise
    
    async def generate_async(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> GenerationResult:
        """
        Generate text asynchronously.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            **kwargs: Additional generation parameters
        
        Returns:
            Generation result
        """
        import asyncio
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.generate(prompt, max_tokens, **kwargs),
        )
    
    async def generate_stream_async(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> AsyncIterator[StreamChunk]:
        """
        Generate text with async streaming.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            **kwargs: Additional generation parameters
        
        Yields:
            Stream chunks
        """
        import asyncio
        
        loop = asyncio.get_event_loop()
        
        # Create queue for streaming
        chunk_queue: queue.Queue[Optional[StreamChunk]] = queue.Queue()
        
        def generate_in_thread():
            try:
                for chunk in self.generate_stream(prompt, max_tokens, **kwargs):
                    chunk_queue.put(chunk)
            finally:
                chunk_queue.put(None)
        
        # Start generation in thread
        thread = threading.Thread(target=generate_in_thread)
        thread.start()
        
        # Yield chunks as they become available
        while True:
            try:
                chunk = chunk_queue.get(timeout=0.1)
                if chunk is None:
                    break
                yield chunk
            except queue.Empty:
                await asyncio.sleep(0.01)
        
        thread.join()
    
    def stop(self) -> bool:
        """
        Stop current generation.
        
        Returns:
            True if generation was stopped
        """
        with self._lock:
            if self._state == GenerationState.GENERATING:
                self._stop_event.set()
                return True
            return False
    
    def _build_generation_kwargs(
        self,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        stop_sequences: Optional[List[str]] = None,
        seed: Optional[int] = None,
        stream: bool = False,
        **extra_kwargs,
    ) -> Dict[str, Any]:
        """Build generation kwargs from parameters and config."""
        gen_config = self.config.generation
        
        kwargs: Dict[str, Any] = {
            "max_tokens": max_tokens or gen_config.max_tokens,
            "temperature": temperature if temperature is not None else gen_config.temperature,
            "top_p": top_p if top_p is not None else gen_config.top_p,
            "top_k": top_k if top_k is not None else gen_config.top_k,
            "repeat_penalty": repetition_penalty if repetition_penalty is not None else gen_config.repetition_penalty,
            "frequency_penalty": gen_config.frequency_penalty,
            "presence_penalty": gen_config.presence_penalty,
            "stream": stream,
        }
        
        # Add stop sequences
        stops = list(gen_config.stop_sequences) if gen_config.stop_sequences else []
        if stop_sequences:
            stops.extend(stop_sequences)
        if stops:
            kwargs["stop"] = stops
        
        # Add seed if specified
        if seed is not None and seed >= 0:
            kwargs["seed"] = seed
        elif gen_config.seed >= 0:
            kwargs["seed"] = gen_config.seed
        
        # Add extra kwargs
        kwargs.update(extra_kwargs)
        
        # Remove None values
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        
        return kwargs
    
    def _determine_stop_reason(
        self,
        text: str,
        stop_sequences: List[str],
        tokens_generated: int,
        max_tokens: Optional[int],
    ) -> str:
        """Determine why generation stopped."""
        # Check for stop sequences
        for stop_seq in stop_sequences:
            if stop_seq in text:
                return "stop"
        
        # Check for max tokens
        if max_tokens and tokens_generated >= max_tokens:
            return "length"
        
        # Default to stop (EOS)
        return "stop"
    
    def estimate_tokens(self, text: str) -> int:
        """
        Estimate token count for text.
        
        Args:
            text: Input text
        
        Returns:
            Estimated token count
        """
        return self.model_manager.count_tokens(text)
    
    def get_context_window(self) -> int:
        """
        Get available context window size.
        
        Returns:
            Context window size in tokens
        """
        model_info = self.model_manager.model_info
        if model_info:
            return model_info.context_length
        return self.config.model.context_length
