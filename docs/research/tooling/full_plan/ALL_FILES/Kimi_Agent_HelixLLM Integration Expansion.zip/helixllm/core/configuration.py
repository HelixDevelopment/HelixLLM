"""
Configuration management for HelixLLM.

Provides centralized configuration with validation, defaults, and persistence.
"""

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import yaml


@dataclass
class ModelConfig:
    """Model configuration."""
    path: str
    context_length: int = 4096
    gpu_layers: int = -1  # -1 for auto
    batch_size: int = 512
    threads: int = -1  # -1 for auto
    rope_scaling: Optional[str] = None
    rope_freq_base: float = 10000.0
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RAGConfig:
    """RAG configuration."""
    enabled: bool = True
    embedding_model: str = "nomic-embed-text-v1.5.Q4_K_M.gguf"
    chunk_size: int = 512
    chunk_overlap: int = 50
    top_k: int = 5
    similarity_threshold: float = 0.7
    vector_store_path: str = "./data/vector_store"
    max_context_length: int = 2048
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolConfig:
    """Tool use configuration."""
    enabled: bool = True
    max_tools_per_request: int = 5
    tool_timeout_seconds: int = 30
    enable_parallel_execution: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class APIConfig:
    """API server configuration."""
    host: str = "0.0.0.0"
    port: int = 8000
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    api_key: Optional[str] = None
    max_request_size_mb: int = 10
    request_timeout_seconds: int = 120
    enable_docs: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class GenerationConfig:
    """Text generation configuration."""
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    repetition_penalty: float = 1.1
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    max_tokens: int = 2048
    stop_sequences: List[str] = field(default_factory=list)
    seed: int = -1
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class LoggingConfig:
    """Logging configuration."""
    level: str = "INFO"
    log_dir: str = "./logs"
    max_file_size_mb: int = 10
    backup_count: int = 5
    json_format: bool = True
    console_output: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class HardwareConfig:
    """Hardware optimization configuration."""
    use_gpu: bool = True
    main_gpu: int = 0
    tensor_split: Optional[List[float]] = None
    use_mmap: bool = True
    use_mlock: bool = False
    offload_kqv: bool = True
    flash_attention: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class Configuration:
    """
    Centralized configuration management for HelixLLM.
    
    Manages all configuration aspects including model settings, RAG,
    tool use, API, generation parameters, and hardware optimization.
    
    Attributes:
        model: Model configuration
        rag: RAG configuration
        tools: Tool configuration
        api: API configuration
        generation: Generation configuration
        logging: Logging configuration
        hardware: Hardware configuration
    
    Example:
        >>> config = Configuration.load("config.yaml")
        >>> config.model.context_length = 8192
        >>> config.save("config.yaml")
    """
    
    DEFAULT_CONFIG_PATH = "helixllm.yaml"
    
    def __init__(
        self,
        model: Optional[ModelConfig] = None,
        rag: Optional[RAGConfig] = None,
        tools: Optional[ToolConfig] = None,
        api: Optional[APIConfig] = None,
        generation: Optional[GenerationConfig] = None,
        logging: Optional[LoggingConfig] = None,
        hardware: Optional[HardwareConfig] = None,
    ):
        """
        Initialize configuration.
        
        Args:
            model: Model configuration
            rag: RAG configuration
            tools: Tool configuration
            api: API configuration
            generation: Generation configuration
            logging: Logging configuration
            hardware: Hardware configuration
        """
        self.model = model or ModelConfig(path="")
        self.rag = rag or RAGConfig()
        self.tools = tools or ToolConfig()
        self.api = api or APIConfig()
        self.generation = generation or GenerationConfig()
        self.logging = logging or LoggingConfig()
        self.hardware = hardware or HardwareConfig()
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> "Configuration":
        """
        Load configuration from file.
        
        Supports YAML and JSON formats.
        
        Args:
            path: Path to configuration file
        
        Returns:
            Loaded configuration
        
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid
        """
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Configuration file not found: {path}")
        
        with open(path, "r") as f:
            if path.suffix in [".yaml", ".yml"]:
                data = yaml.safe_load(f)
            elif path.suffix == ".json":
                data = json.load(f)
            else:
                raise ValueError(f"Unsupported config format: {path.suffix}")
        
        return cls.from_dict(data)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Configuration":
        """
        Create configuration from dictionary.
        
        Args:
            data: Configuration dictionary
        
        Returns:
            Configuration instance
        """
        return cls(
            model=ModelConfig(**data.get("model", {})),
            rag=RAGConfig(**data.get("rag", {})),
            tools=ToolConfig(**data.get("tools", {})),
            api=APIConfig(**data.get("api", {})),
            generation=GenerationConfig(**data.get("generation", {})),
            logging=LoggingConfig(**data.get("logging", {})),
            hardware=HardwareConfig(**data.get("hardware", {})),
        )
    
    @classmethod
    def from_env(cls) -> "Configuration":
        """
        Create configuration from environment variables.
        
        Environment variables should be prefixed with HELIXLLM_
        and use __ as separator for nested values.
        
        Returns:
            Configuration instance
        """
        config = cls()
        
        for key, value in os.environ.items():
            if key.startswith("HELIXLLM_"):
                parts = key[9:].lower().split("__")
                
                # Navigate to the right config section
                current = config
                for part in parts[:-1]:
                    current = getattr(current, part)
                
                # Set the value
                attr_name = parts[-1]
                current_value = getattr(current, attr_name)
                
                # Type conversion
                if isinstance(current_value, bool):
                    value = value.lower() in ("true", "1", "yes")
                elif isinstance(current_value, int):
                    value = int(value)
                elif isinstance(current_value, float):
                    value = float(value)
                elif isinstance(current_value, list):
                    value = value.split(",")
                
                setattr(current, attr_name, value)
        
        return config
    
    def save(self, path: Union[str, Path]) -> None:
        """
        Save configuration to file.
        
        Args:
            path: Path to save configuration
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        data = self.to_dict()
        
        with open(path, "w") as f:
            if path.suffix in [".yaml", ".yml"]:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
            elif path.suffix == ".json":
                json.dump(data, f, indent=2)
            else:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.
        
        Returns:
            Configuration dictionary
        """
        return {
            "model": self.model.to_dict(),
            "rag": self.rag.to_dict(),
            "tools": self.tools.to_dict(),
            "api": self.api.to_dict(),
            "generation": self.generation.to_dict(),
            "logging": self.logging.to_dict(),
            "hardware": self.hardware.to_dict(),
        }
    
    def validate(self) -> List[str]:
        """
        Validate configuration.
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Model validation
        if not self.model.path:
            errors.append("Model path is required")
        
        if self.model.context_length < 512:
            errors.append("Context length must be at least 512")
        
        if self.model.context_length > 128000:
            errors.append("Context length exceeds maximum (128000)")
        
        # Generation validation
        if not 0 <= self.generation.temperature <= 2:
            errors.append("Temperature must be between 0 and 2")
        
        if not 0 <= self.generation.top_p <= 1:
            errors.append("Top-p must be between 0 and 1")
        
        if self.generation.repetition_penalty < 1:
            errors.append("Repetition penalty must be >= 1")
        
        # RAG validation
        if self.rag.chunk_size < 100:
            errors.append("Chunk size must be at least 100")
        
        if self.rag.chunk_overlap >= self.rag.chunk_size:
            errors.append("Chunk overlap must be less than chunk size")
        
        # API validation
        if self.api.port < 1 or self.api.port > 65535:
            errors.append("Port must be between 1 and 65535")
        
        return errors
    
    def is_valid(self) -> bool:
        """
        Check if configuration is valid.
        
        Returns:
            True if valid
        """
        return len(self.validate()) == 0
    
    def merge(self, other: "Configuration") -> "Configuration":
        """
        Merge another configuration into this one.
        
        Args:
            other: Configuration to merge
        
        Returns:
            Self for chaining
        """
        def merge_dataclass(base, override):
            for field_name in base.__dataclass_fields__:
                override_value = getattr(override, field_name)
                if override_value is not None and override_value != "":
                    setattr(base, field_name, override_value)
        
        merge_dataclass(self.model, other.model)
        merge_dataclass(self.rag, other.rag)
        merge_dataclass(self.tools, other.tools)
        merge_dataclass(self.api, other.api)
        merge_dataclass(self.generation, other.generation)
        merge_dataclass(self.logging, other.logging)
        merge_dataclass(self.hardware, other.hardware)
        
        return self
    
    def get_model_kwargs(self) -> Dict[str, Any]:
        """
        Get kwargs for llama.cpp model loading.
        
        Returns:
            Dictionary of model loading parameters
        """
        return {
            "n_ctx": self.model.context_length,
            "n_gpu_layers": self.model.gpu_layers if self.model.gpu_layers >= 0 else None,
            "n_batch": self.model.batch_size,
            "n_threads": self.model.threads if self.model.threads > 0 else None,
            "rope_scaling_type": self.model.rope_scaling,
            "rope_freq_base": self.model.rope_freq_base,
            "use_mmap": self.hardware.use_mmap,
            "use_mlock": self.hardware.use_mlock,
            "offload_kqv": self.hardware.offload_kqv,
        }
    
    def get_generation_kwargs(self) -> Dict[str, Any]:
        """
        Get kwargs for text generation.
        
        Returns:
            Dictionary of generation parameters
        """
        return {
            "temperature": self.generation.temperature,
            "top_p": self.generation.top_p,
            "top_k": self.generation.top_k,
            "repeat_penalty": self.generation.repetition_penalty,
            "frequency_penalty": self.generation.frequency_penalty,
            "presence_penalty": self.generation.presence_penalty,
            "max_tokens": self.generation.max_tokens,
            "stop": self.generation.stop_sequences or None,
            "seed": self.generation.seed if self.generation.seed >= 0 else None,
        }
    
    @classmethod
    def create_default(cls, model_path: str) -> "Configuration":
        """
        Create default configuration with specified model.
        
        Args:
            model_path: Path to GGUF model
        
        Returns:
            Default configuration
        """
        config = cls()
        config.model.path = model_path
        return config
