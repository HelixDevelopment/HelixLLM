"""
Main HelixLLM orchestrator class.

Coordinates all components including model management, inference,
RAG, tool use, and chat sessions.
"""

import asyncio
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Union
import logging

from .configuration import Configuration
from .model_manager import ModelManager
from .inference_engine import InferenceEngine, GenerationResult, StreamChunk
from .chat_session import ChatSession, SessionManager

from ..rag.retrieval_engine import RetrievalEngine
from ..rag.context_injector import ContextInjector

from ..tools.tool_registry import ToolRegistry
from ..tools.tool_executor import ToolExecutor
from ..tools.function_caller import FunctionCaller

from ..utils.logger import Logger
from ..utils.metrics_collector import MetricsCollector


class HelixLLM:
    """
    Main orchestrator for HelixLLM system.
    
    Coordinates all components:
    - Model management and inference
    - RAG (Retrieval Augmented Generation)
    - Tool use and function calling
    - Chat session management
    - Metrics and logging
    
    Attributes:
        config: System configuration
        model_manager: Model management component
        inference_engine: Text generation component
        session_manager: Chat session management
        retrieval_engine: RAG retrieval component
        tool_registry: Tool registration component
        tool_executor: Tool execution component
    
    Example:
        >>> helix = HelixLLM.from_config("config.yaml")
        >>> helix.load_model("path/to/model.gguf")
        >>> response = helix.chat("Hello, how are you?")
    """
    
    def __init__(
        self,
        config: Configuration,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize HelixLLM.
        
        Args:
            config: System configuration
            logger: Optional logger instance
        """
        self.config = config
        self.logger = logger or Logger("helixllm")
        
        # Initialize metrics
        self.metrics = MetricsCollector()
        
        # Initialize core components
        self.logger.info("Initializing HelixLLM components...")
        
        self.model_manager = ModelManager(config, self.logger)
        self.inference_engine = InferenceEngine(self.model_manager, config, self.logger)
        self.session_manager = SessionManager(
            save_dir=Path(config.rag.vector_store_path).parent / "sessions",
            logger=self.logger,
        )
        
        # Initialize RAG components
        self.retrieval_engine: Optional[RetrievalEngine] = None
        self.context_injector: Optional[ContextInjector] = None
        
        if config.rag.enabled:
            self._init_rag()
        
        # Initialize tool components
        self.tool_registry = ToolRegistry()
        self.tool_executor = ToolExecutor(self.tool_registry, self.logger)
        self.function_caller = FunctionCaller(self.tool_registry, self.logger)
        
        self.logger.info("HelixLLM initialized successfully")
    
    def _init_rag(self) -> None:
        """Initialize RAG components."""
        from ..rag.vector_store import VectorStore
        from ..rag.embedding_generator import EmbeddingGenerator
        from ..rag.retrieval_engine import RetrievalEngine
        from ..rag.context_injector import ContextInjector
        
        self.logger.info("Initializing RAG components...")
        
        # Initialize vector store
        vector_store = VectorStore(
            persist_directory=self.config.rag.vector_store_path,
        )
        
        # Initialize embedding generator
        embedding_gen = EmbeddingGenerator(
            model_path=self.config.rag.embedding_model,
        )
        
        # Initialize retrieval engine
        self.retrieval_engine = RetrievalEngine(
            vector_store=vector_store,
            embedding_generator=embedding_gen,
            top_k=self.config.rag.top_k,
            similarity_threshold=self.config.rag.similarity_threshold,
        )
        
        # Initialize context injector
        self.context_injector = ContextInjector(
            max_context_length=self.config.rag.max_context_length,
        )
        
        self.logger.info("RAG components initialized")
    
    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> "HelixLLM":
        """
        Create HelixLLM from configuration file.
        
        Args:
            config_path: Path to configuration file
        
        Returns:
            HelixLLM instance
        """
        config = Configuration.load(config_path)
        return cls(config)
    
    @classmethod
    def from_env(cls) -> "HelixLLM":
        """
        Create HelixLLM from environment variables.
        
        Returns:
            HelixLLM instance
        """
        config = Configuration.from_env()
        return cls(config)
    
    def load_model(self, model_path: Optional[str] = None) -> "HelixLLM":
        """
        Load a language model.
        
        Args:
            model_path: Path to GGUF model (uses config if not specified)
        
        Returns:
            Self for chaining
        """
        with self.metrics.timer("model_load"):
            self.model_manager.load(model_path)
        
        return self
    
    def unload_model(self) -> "HelixLLM":
        """
        Unload the current model.
        
        Returns:
            Self for chaining
        """
        self.model_manager.unload()
        return self
    
    def create_session(
        self,
        system_prompt: Optional[str] = None,
        **kwargs,
    ) -> ChatSession:
        """
        Create a new chat session.
        
        Args:
            system_prompt: System prompt for the session
            **kwargs: Additional session parameters
        
        Returns:
            New chat session
        """
        return self.session_manager.create_session(
            system_prompt=system_prompt,
            **kwargs,
        )
    
    def get_session(self, session_id: str) -> Optional[ChatSession]:
        """
        Get an existing chat session.
        
        Args:
            session_id: Session ID
        
        Returns:
            Chat session or None
        """
        return self.session_manager.get_session(session_id)
    
    def chat(
        self,
        message: str,
        session: Optional[ChatSession] = None,
        use_rag: bool = True,
        use_tools: bool = True,
        **generation_kwargs,
    ) -> str:
        """
        Send a chat message and get response.
        
        Args:
            message: User message
            session: Chat session (creates new if not provided)
            use_rag: Enable RAG retrieval
            use_tools: Enable tool use
            **generation_kwargs: Additional generation parameters
        
        Returns:
            Assistant response
        """
        with self.metrics.timer("chat_request"):
            # Create session if needed
            if session is None:
                session = self.create_session()
            
            # Add user message
            session.add_user_message(message)
            
            # Build prompt
            prompt = self._build_prompt(session, message, use_rag)
            
            # Check for tool calls
            if use_tools and self.config.tools.enabled:
                tool_calls = self.function_caller.detect_tool_calls(prompt)
                if tool_calls:
                    return self._handle_tool_calls(session, tool_calls, prompt, **generation_kwargs)
            
            # Generate response
            result = self.inference_engine.generate(
                prompt,
                **generation_kwargs,
            )
            
            # Add assistant message
            session.add_assistant_message(result.text)
            
            # Update metrics
            self.metrics.increment("chat_messages_total")
            self.metrics.gauge("chat_tokens_generated", result.tokens_generated)
            
            return result.text
    
    def chat_stream(
        self,
        message: str,
        session: Optional[ChatSession] = None,
        use_rag: bool = True,
        **generation_kwargs,
    ):
        """
        Send a chat message and get streaming response.
        
        Args:
            message: User message
            session: Chat session (creates new if not provided)
            use_rag: Enable RAG retrieval
            **generation_kwargs: Additional generation parameters
        
        Yields:
            Response chunks
        """
        # Create session if needed
        if session is None:
            session = self.create_session()
        
        # Add user message
        session.add_user_message(message)
        
        # Build prompt
        prompt = self._build_prompt(session, message, use_rag)
        
        # Stream generation
        full_response = []
        for chunk in self.inference_engine.generate_stream(prompt, **generation_kwargs):
            yield chunk.text
            full_response.append(chunk.text)
            
            if chunk.is_finished:
                break
        
        # Add assistant message
        session.add_assistant_message("".join(full_response))
    
    async def chat_async(
        self,
        message: str,
        session: Optional[ChatSession] = None,
        use_rag: bool = True,
        **generation_kwargs,
    ) -> str:
        """
        Async chat method.
        
        Args:
            message: User message
            session: Chat session
            use_rag: Enable RAG
            **generation_kwargs: Generation parameters
        
        Returns:
            Assistant response
        """
        # Create session if needed
        if session is None:
            session = self.create_session()
        
        # Add user message
        session.add_user_message(message)
        
        # Build prompt
        prompt = self._build_prompt(session, message, use_rag)
        
        # Generate response
        result = await self.inference_engine.generate_async(
            prompt,
            **generation_kwargs,
        )
        
        # Add assistant message
        session.add_assistant_message(result.text)
        
        return result.text
    
    def _build_prompt(
        self,
        session: ChatSession,
        message: str,
        use_rag: bool,
    ) -> str:
        """Build prompt for generation."""
        # Get conversation history
        messages = session.to_openai_format()
        
        # Apply RAG if enabled
        if use_rag and self.retrieval_engine and self.context_injector:
            with self.metrics.timer("rag_retrieval"):
                retrieved_docs = self.retrieval_engine.retrieve(message)
            
            if retrieved_docs:
                messages = self.context_injector.inject_context(
                    messages,
                    retrieved_docs,
                )
        
        # Convert to prompt format
        return self._messages_to_prompt(messages)
    
    def _messages_to_prompt(self, messages: List[Dict[str, str]]) -> str:
        """Convert messages to prompt string."""
        prompt_parts = []
        
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            if role == "system":
                prompt_parts.append(f"System: {content}")
            elif role == "user":
                prompt_parts.append(f"User: {content}")
            elif role == "assistant":
                prompt_parts.append(f"Assistant: {content}")
        
        prompt_parts.append("Assistant:")
        
        return "\n\n".join(prompt_parts)
    
    def _handle_tool_calls(
        self,
        session: ChatSession,
        tool_calls: List[Dict[str, Any]],
        prompt: str,
        **generation_kwargs,
    ) -> str:
        """Handle tool calls in the conversation."""
        # Execute tools
        tool_results = []
        for call in tool_calls:
            tool_name = call.get("name")
            tool_params = call.get("parameters", {})
            
            with self.metrics.timer(f"tool_execution", {"tool": tool_name}):
                result = self.tool_executor.execute(tool_name, tool_params)
            
            tool_results.append({
                "name": tool_name,
                "result": result.to_dict() if hasattr(result, "to_dict") else result,
            })
            
            # Add tool message to session
            session.add_tool_message(
                content=str(result),
                tool_name=tool_name,
            )
        
        # Generate final response with tool results
        tool_context = self._format_tool_results(tool_results)
        enhanced_prompt = f"{prompt}\n\nTool results:\n{tool_context}\n\nAssistant:"
        
        result = self.inference_engine.generate(
            enhanced_prompt,
            **generation_kwargs,
        )
        
        session.add_assistant_message(result.text)
        
        return result.text
    
    def _format_tool_results(self, results: List[Dict[str, Any]]) -> str:
        """Format tool results for prompt."""
        lines = []
        for result in results:
            lines.append(f"- {result['name']}: {result['result']}")
        return "\n".join(lines)
    
    def add_documents(
        self,
        documents: List[Union[str, Path]],
        **kwargs,
    ) -> "HelixLLM":
        """
        Add documents to RAG knowledge base.
        
        Args:
            documents: List of document paths or content
            **kwargs: Additional processing parameters
        
        Returns:
            Self for chaining
        """
        if not self.retrieval_engine:
            self.logger.warning("RAG not enabled, cannot add documents")
            return self
        
        from ..rag.document_processor import DocumentProcessor
        
        with self.metrics.timer("document_ingestion"):
            processor = DocumentProcessor(
                chunk_size=self.config.rag.chunk_size,
                chunk_overlap=self.config.rag.chunk_overlap,
            )
            
            for doc in documents:
                chunks = processor.process_document(doc, **kwargs)
                self.retrieval_engine.add_documents(chunks)
        
        self.logger.info(f"Added {len(documents)} documents to knowledge base")
        
        return self
    
    def register_tool(
        self,
        name: str,
        func: callable,
        description: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> "HelixLLM":
        """
        Register a tool for function calling.
        
        Args:
            name: Tool name
            func: Tool function
            description: Tool description
            parameters: Tool parameters schema
        
        Returns:
            Self for chaining
        """
        self.tool_registry.register(
            name=name,
            func=func,
            description=description,
            parameters=parameters,
        )
        
        return self
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get system statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            "model": self.model_manager.get_stats(),
            "sessions": len(self.session_manager.list_sessions()),
            "metrics": self.metrics.get_all_metrics(),
            "tools": len(self.tool_registry.list_tools()),
        }
    
    def health_check(self) -> Dict[str, Any]:
        """
        Perform health check.
        
        Returns:
            Health status dictionary
        """
        status = {
            "status": "healthy",
            "components": {},
        }
        
        # Check model
        status["components"]["model"] = {
            "loaded": self.model_manager.is_loaded,
        }
        
        # Check RAG
        status["components"]["rag"] = {
            "enabled": self.config.rag.enabled,
            "initialized": self.retrieval_engine is not None,
        }
        
        # Check tools
        status["components"]["tools"] = {
            "enabled": self.config.tools.enabled,
            "registered": len(self.tool_registry.list_tools()),
        }
        
        return status
