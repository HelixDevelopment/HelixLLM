"""
Chat session management for HelixLLM.

Manages conversation state, message history, and context window.
"""

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import logging


class MessageRole(Enum):
    """Role of a message in the conversation."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass
class Message:
    """A single message in the conversation."""
    role: MessageRole
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "role": self.role.value,
            "content": self.content,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
            "message_id": self.message_id,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Message":
        """Create from dictionary."""
        return cls(
            role=MessageRole(data.get("role", "user")),
            content=data["content"],
            timestamp=data.get("timestamp", time.time()),
            metadata=data.get("metadata", {}),
            message_id=data.get("message_id", str(uuid.uuid4())),
        )
    
    def to_openai_format(self) -> Dict[str, str]:
        """Convert to OpenAI API format."""
        return {
            "role": self.role.value,
            "content": self.content,
        }


@dataclass
class SessionStats:
    """Statistics for a chat session."""
    total_messages: int = 0
    user_messages: int = 0
    assistant_messages: int = 0
    total_tokens: int = 0
    created_at: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ChatSession:
    """
    Manages a chat conversation session.
    
    Handles message history, context window management, and conversation
    persistence. Supports system prompts and metadata.
    
    Attributes:
        session_id: Unique session identifier
        messages: List of messages in the conversation
        system_prompt: System prompt for the session
        stats: Session statistics
    
    Example:
        >>> session = ChatSession(system_prompt="You are a helpful assistant.")
        >>> session.add_user_message("Hello!")
        >>> session.add_assistant_message("Hi there!")
        >>> history = session.get_history()
    """
    
    def __init__(
        self,
        session_id: Optional[str] = None,
        system_prompt: Optional[str] = None,
        max_history: int = 100,
        max_context_tokens: int = 4096,
        metadata: Optional[Dict[str, Any]] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize chat session.
        
        Args:
            session_id: Unique session ID (generated if not provided)
            system_prompt: System prompt for the session
            max_history: Maximum number of messages to keep
            max_context_tokens: Maximum tokens in context window
            metadata: Session metadata
            logger: Optional logger
        """
        self.session_id = session_id or str(uuid.uuid4())
        self.system_prompt = system_prompt
        self.max_history = max_history
        self.max_context_tokens = max_context_tokens
        self.metadata = metadata or {}
        self.logger = logger or logging.getLogger(__name__)
        
        self._messages: List[Message] = []
        self._stats = SessionStats()
        
        # Add system message if provided
        if system_prompt:
            self._add_message(MessageRole.SYSTEM, system_prompt)
    
    @property
    def messages(self) -> List[Message]:
        """Get all messages in the session."""
        return self._messages.copy()
    
    @property
    def stats(self) -> SessionStats:
        """Get session statistics."""
        return self._stats
    
    def add_user_message(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Message:
        """
        Add a user message to the session.
        
        Args:
            content: Message content
            metadata: Optional metadata
        
        Returns:
            Created message
        """
        return self._add_message(MessageRole.USER, content, metadata)
    
    def add_assistant_message(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Message:
        """
        Add an assistant message to the session.
        
        Args:
            content: Message content
            metadata: Optional metadata
        
        Returns:
            Created message
        """
        return self._add_message(MessageRole.ASSISTANT, content, metadata)
    
    def add_tool_message(
        self,
        content: str,
        tool_name: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Message:
        """
        Add a tool result message to the session.
        
        Args:
            content: Message content (tool result)
            tool_name: Name of the tool that was called
            metadata: Optional metadata
        
        Returns:
            Created message
        """
        meta = metadata or {}
        meta["tool_name"] = tool_name
        return self._add_message(MessageRole.TOOL, content, meta)
    
    def _add_message(
        self,
        role: MessageRole,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Message:
        """Internal method to add a message."""
        message = Message(
            role=role,
            content=content,
            metadata=metadata or {},
        )
        
        self._messages.append(message)
        
        # Update stats
        self._stats.total_messages += 1
        self._stats.last_activity = time.time()
        
        if role == MessageRole.USER:
            self._stats.user_messages += 1
        elif role == MessageRole.ASSISTANT:
            self._stats.assistant_messages += 1
        
        # Trim history if needed
        self._trim_history()
        
        self.logger.debug(f"Added {role.value} message to session {self.session_id}")
        
        return message
    
    def _trim_history(self) -> None:
        """Trim message history to stay within limits."""
        # Keep system message and recent messages
        while len(self._messages) > self.max_history:
            # Never remove system message (first message if present)
            if len(self._messages) > 1 and self._messages[0].role == MessageRole.SYSTEM:
                # Remove second message (oldest non-system)
                self._messages.pop(1)
            else:
                # Remove oldest message
                self._messages.pop(0)
    
    def get_history(
        self,
        include_system: bool = True,
        limit: Optional[int] = None,
    ) -> List[Message]:
        """
        Get conversation history.
        
        Args:
            include_system: Include system message
            limit: Maximum number of messages to return
        
        Returns:
            List of messages
        """
        messages = self._messages
        
        if not include_system and messages and messages[0].role == MessageRole.SYSTEM:
            messages = messages[1:]
        
        if limit:
            messages = messages[-limit:]
        
        return messages
    
    def get_history_text(
        self,
        format_template: str = "{role}: {content}\n",
        include_system: bool = True,
    ) -> str:
        """
        Get conversation history as formatted text.
        
        Args:
            format_template: Template for formatting messages
            include_system: Include system message
        
        Returns:
            Formatted conversation text
        """
        messages = self.get_history(include_system=include_system)
        return "".join(
            format_template.format(role=m.role.value.upper(), content=m.content)
            for m in messages
        )
    
    def to_openai_format(
        self,
        include_system: bool = True,
        limit: Optional[int] = None,
    ) -> List[Dict[str, str]]:
        """
        Get conversation history in OpenAI API format.
        
        Args:
            include_system: Include system message
            limit: Maximum number of messages
        
        Returns:
            List of messages in OpenAI format
        """
        messages = self.get_history(include_system=include_system, limit=limit)
        return [m.to_openai_format() for m in messages]
    
    def get_last_message(self) -> Optional[Message]:
        """Get the last message in the session."""
        if self._messages:
            return self._messages[-1]
        return None
    
    def clear_history(self, keep_system: bool = True) -> None:
        """
        Clear conversation history.
        
        Args:
            keep_system: Keep the system message
        """
        if keep_system and self._messages and self._messages[0].role == MessageRole.SYSTEM:
            system_msg = self._messages[0]
            self._messages = [system_msg]
        else:
            self._messages = []
        
        self._stats = SessionStats(created_at=self._stats.created_at)
        self.logger.debug(f"Cleared history for session {self.session_id}")
    
    def update_system_prompt(self, system_prompt: str) -> None:
        """
        Update the system prompt.
        
        Args:
            system_prompt: New system prompt
        """
        self.system_prompt = system_prompt
        
        # Update existing system message or add new one
        if self._messages and self._messages[0].role == MessageRole.SYSTEM:
            self._messages[0].content = system_prompt
        else:
            self._messages.insert(
                0,
                Message(role=MessageRole.SYSTEM, content=system_prompt),
            )
        
        self.logger.debug(f"Updated system prompt for session {self.session_id}")
    
    def get_token_estimate(self, tokens_per_char: float = 0.25) -> int:
        """
        Estimate token count for the session.
        
        Args:
            tokens_per_char: Estimated tokens per character
        
        Returns:
            Estimated token count
        """
        total_chars = sum(len(m.content) for m in self._messages)
        return int(total_chars * tokens_per_char)
    
    def is_context_full(self, threshold: float = 0.9) -> bool:
        """
        Check if context window is nearly full.
        
        Args:
            threshold: Threshold ratio (0-1)
        
        Returns:
            True if context is nearly full
        """
        estimated_tokens = self.get_token_estimate()
        return estimated_tokens >= (self.max_context_tokens * threshold)
    
    def summarize(self, summary: str) -> None:
        """
        Summarize and compress conversation history.
        
        Replaces older messages with a summary message.
        
        Args:
            summary: Summary text to use
        """
        # Keep system message and last user-assistant pair
        system_msg = None
        if self._messages and self._messages[0].role == MessageRole.SYSTEM:
            system_msg = self._messages[0]
        
        # Get last user and assistant messages
        recent_messages = []
        for msg in reversed(self._messages):
            if msg.role in (MessageRole.USER, MessageRole.ASSISTANT):
                recent_messages.insert(0, msg)
                if len(recent_messages) >= 2:
                    break
        
        # Rebuild message list
        self._messages = []
        
        if system_msg:
            self._messages.append(system_msg)
        
        # Add summary
        self._messages.append(Message(
            role=MessageRole.SYSTEM,
            content=f"Previous conversation summary: {summary}",
        ))
        
        # Add recent messages
        self._messages.extend(recent_messages)
        
        self.logger.debug(f"Summarized session {self.session_id}")
    
    def save(self, path: Union[str, Path]) -> None:
        """
        Save session to file.
        
        Args:
            path: Path to save file
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            "session_id": self.session_id,
            "system_prompt": self.system_prompt,
            "max_history": self.max_history,
            "max_context_tokens": self.max_context_tokens,
            "metadata": self.metadata,
            "messages": [m.to_dict() for m in self._messages],
            "stats": self._stats.to_dict(),
        }
        
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        
        self.logger.debug(f"Saved session {self.session_id} to {path}")
    
    @classmethod
    def load(cls, path: Union[str, Path], logger: Optional[logging.Logger] = None) -> "ChatSession":
        """
        Load session from file.
        
        Args:
            path: Path to session file
            logger: Optional logger
        
        Returns:
            Loaded chat session
        """
        with open(path, "r") as f:
            data = json.load(f)
        
        session = cls(
            session_id=data["session_id"],
            system_prompt=data.get("system_prompt"),
            max_history=data.get("max_history", 100),
            max_context_tokens=data.get("max_context_tokens", 4096),
            metadata=data.get("metadata", {}),
            logger=logger,
        )
        
        # Restore messages
        session._messages = [Message.from_dict(m) for m in data.get("messages", [])]
        
        # Restore stats
        stats_data = data.get("stats", {})
        session._stats = SessionStats(**stats_data)
        
        return session
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary."""
        return {
            "session_id": self.session_id,
            "system_prompt": self.system_prompt,
            "max_history": self.max_history,
            "max_context_tokens": self.max_context_tokens,
            "metadata": self.metadata,
            "messages": [m.to_dict() for m in self._messages],
            "stats": self._stats.to_dict(),
        }


class SessionManager:
    """
    Manages multiple chat sessions.
    
    Provides session creation, retrieval, and lifecycle management.
    """
    
    def __init__(
        self,
        save_dir: Optional[Union[str, Path]] = None,
        max_sessions: int = 100,
        session_timeout_seconds: float = 3600,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize session manager.
        
        Args:
            save_dir: Directory for saving sessions
            max_sessions: Maximum number of active sessions
            session_timeout_seconds: Session timeout in seconds
            logger: Optional logger
        """
        self.save_dir = Path(save_dir) if save_dir else None
        self.max_sessions = max_sessions
        self.session_timeout_seconds = session_timeout_seconds
        self.logger = logger or logging.getLogger(__name__)
        
        self._sessions: Dict[str, ChatSession] = {}
    
    def create_session(
        self,
        session_id: Optional[str] = None,
        system_prompt: Optional[str] = None,
        **kwargs,
    ) -> ChatSession:
        """
        Create a new chat session.
        
        Args:
            session_id: Optional session ID
            system_prompt: Optional system prompt
            **kwargs: Additional session parameters
        
        Returns:
            Created session
        """
        # Clean up old sessions if needed
        self._cleanup_sessions()
        
        session = ChatSession(
            session_id=session_id,
            system_prompt=system_prompt,
            **kwargs,
        )
        
        self._sessions[session.session_id] = session
        
        self.logger.info(f"Created session {session.session_id}")
        
        return session
    
    def get_session(self, session_id: str) -> Optional[ChatSession]:
        """
        Get a session by ID.
        
        Args:
            session_id: Session ID
        
        Returns:
            Session or None if not found
        """
        return self._sessions.get(session_id)
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session.
        
        Args:
            session_id: Session ID
        
        Returns:
            True if deleted
        """
        if session_id in self._sessions:
            del self._sessions[session_id]
            self.logger.info(f"Deleted session {session_id}")
            return True
        return False
    
    def list_sessions(self) -> List[Dict[str, Any]]:
        """
        List all active sessions.
        
        Returns:
            List of session info dictionaries
        """
        return [
            {
                "session_id": sid,
                "message_count": len(session.messages),
                "last_activity": session.stats.last_activity,
            }
            for sid, session in self._sessions.items()
        ]
    
    def _cleanup_sessions(self) -> None:
        """Clean up old or excess sessions."""
        current_time = time.time()
        
        # Remove timed out sessions
        timed_out = [
            sid for sid, session in self._sessions.items()
            if current_time - session.stats.last_activity > self.session_timeout_seconds
        ]
        
        for sid in timed_out:
            self.save_session(sid)
            del self._sessions[sid]
            self.logger.debug(f"Cleaned up timed out session {sid}")
        
        # Remove excess sessions (oldest first)
        while len(self._sessions) >= self.max_sessions:
            oldest_sid = min(
                self._sessions.keys(),
                key=lambda s: self._sessions[s].stats.last_activity,
            )
            self.save_session(oldest_sid)
            del self._sessions[oldest_sid]
            self.logger.debug(f"Cleaned up excess session {oldest_sid}")
    
    def save_session(self, session_id: str) -> bool:
        """
        Save a session to disk.
        
        Args:
            session_id: Session ID
        
        Returns:
            True if saved
        """
        if not self.save_dir:
            return False
        
        session = self._sessions.get(session_id)
        if not session:
            return False
        
        path = self.save_dir / f"{session_id}.json"
        session.save(path)
        return True
    
    def load_session(self, session_id: str) -> Optional[ChatSession]:
        """
        Load a session from disk.
        
        Args:
            session_id: Session ID
        
        Returns:
            Loaded session or None
        """
        if not self.save_dir:
            return None
        
        path = self.save_dir / f"{session_id}.json"
        if not path.exists():
            return None
        
        session = ChatSession.load(path, self.logger)
        self._sessions[session_id] = session
        return session
