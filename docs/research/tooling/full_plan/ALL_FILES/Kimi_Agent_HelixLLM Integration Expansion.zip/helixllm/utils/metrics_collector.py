"""
Performance metrics collection for HelixLLM.

Provides comprehensive metrics tracking for inference, RAG, and tool execution.
"""

import time
import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union
import json
import statistics


class MetricType(Enum):
    """Types of metrics that can be collected."""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"


@dataclass
class MetricValue:
    """Single metric value with timestamp."""
    value: Union[int, float]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    labels: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "value": self.value,
            "timestamp": self.timestamp.isoformat() + "Z",
            "labels": self.labels,
        }


@dataclass
class TimerContext:
    """Context for timing operations."""
    name: str
    labels: Dict[str, str]
    start_time: float
    collector: "MetricsCollector"
    
    def stop(self) -> float:
        """Stop timer and record duration."""
        duration = time.perf_counter() - self.start_time
        self.collector.record_timer(self.name, duration, self.labels)
        return duration


class MetricsCollector:
    """
    Collects and manages performance metrics for HelixLLM.
    
    Thread-safe metrics collection with support for counters, gauges,
    histograms, and timers. Provides export capabilities for monitoring.
    
    Attributes:
        max_history: Maximum number of values to keep per metric
        metrics: Dictionary of collected metrics
    
    Example:
        >>> metrics = MetricsCollector()
        >>> metrics.increment("requests_total", {"endpoint": "chat"})
        >>> with metrics.timer("inference_duration"):
        ...     result = model.generate(prompt)
    """
    
    def __init__(self, max_history: int = 10000, export_path: Optional[Path] = None):
        """
        Initialize metrics collector.
        
        Args:
            max_history: Maximum values to keep per metric
            export_path: Path for metric exports
        """
        self.max_history = max_history
        self.export_path = export_path
        
        # Thread-safe storage
        self._lock = threading.RLock()
        self._metrics: Dict[str, Dict[str, Any]] = defaultdict(
            lambda: {
                "type": None,
                "values": deque(maxlen=max_history),
                "sum": 0.0,
                "count": 0,
            }
        )
        
        # Predefined metric categories
        self._categories = {
            "inference": [],
            "rag": [],
            "tools": [],
            "api": [],
            "system": [],
        }
    
    def increment(
        self,
        name: str,
        labels: Optional[Dict[str, str]] = None,
        value: int = 1,
    ) -> None:
        """
        Increment a counter metric.
        
        Args:
            name: Metric name
            labels: Metric labels/tags
            value: Amount to increment
        """
        with self._lock:
            metric = self._metrics[name]
            metric["type"] = MetricType.COUNTER
            metric["values"].append(MetricValue(value, labels=labels or {}))
            metric["sum"] += value
            metric["count"] += 1
    
    def decrement(
        self,
        name: str,
        labels: Optional[Dict[str, str]] = None,
        value: int = 1,
    ) -> None:
        """
        Decrement a counter metric.
        
        Args:
            name: Metric name
            labels: Metric labels/tags
            value: Amount to decrement
        """
        self.increment(name, labels, -value)
    
    def gauge(
        self,
        name: str,
        value: Union[int, float],
        labels: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Record a gauge metric (current value).
        
        Args:
            name: Metric name
            value: Current value
            labels: Metric labels/tags
        """
        with self._lock:
            metric = self._metrics[name]
            metric["type"] = MetricType.GAUGE
            metric["values"].append(MetricValue(value, labels=labels or {}))
            metric["sum"] = value  # For gauge, sum is the latest value
            metric["count"] = len(metric["values"])
    
    def record_timer(
        self,
        name: str,
        duration: float,
        labels: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Record a timer metric (duration in seconds).
        
        Args:
            name: Metric name
            duration: Duration in seconds
            labels: Metric labels/tags
        """
        with self._lock:
            metric = self._metrics[name]
            metric["type"] = MetricType.TIMER
            metric["values"].append(MetricValue(duration, labels=labels or {}))
            metric["sum"] += duration
            metric["count"] += 1
    
    def histogram(
        self,
        name: str,
        value: Union[int, float],
        labels: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Record a histogram metric.
        
        Args:
            name: Metric name
            value: Value to record
            labels: Metric labels/tags
        """
        with self._lock:
            metric = self._metrics[name]
            metric["type"] = MetricType.HISTOGRAM
            metric["values"].append(MetricValue(value, labels=labels or {}))
            metric["sum"] += value
            metric["count"] += 1
    
    def timer(self, name: str, labels: Optional[Dict[str, str]] = None) -> TimerContext:
        """
        Create a timer context for measuring operation duration.
        
        Args:
            name: Metric name
            labels: Metric labels/tags
        
        Returns:
            Timer context that records duration on exit
        
        Example:
            >>> with metrics.timer("inference_time"):
            ...     result = model.generate(prompt)
        """
        return TimerContext(
            name=name,
            labels=labels or {},
            start_time=time.perf_counter(),
            collector=self,
        )
    
    def timeit(self, name: str, labels: Optional[Dict[str, str]] = None) -> Callable:
        """
        Decorator for timing function execution.
        
        Args:
            name: Metric name
            labels: Metric labels/tags
        
        Returns:
            Decorated function
        
        Example:
            >>> @metrics.timeit("process_document")
            ... def process_document(doc):
            ...     return processor.process(doc)
        """
        def decorator(func: Callable) -> Callable:
            def wrapper(*args, **kwargs):
                with self.timer(name, labels):
                    return func(*args, **kwargs)
            return wrapper
        return decorator
    
    def get_metric(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Get metric data by name.
        
        Args:
            name: Metric name
        
        Returns:
            Metric data or None if not found
        """
        with self._lock:
            if name not in self._metrics:
                return None
            
            metric = self._metrics[name]
            values = list(metric["values"])
            
            if not values:
                return {
                    "name": name,
                    "type": metric["type"].value if metric["type"] else None,
                    "count": 0,
                }
            
            numeric_values = [v.value for v in values if isinstance(v.value, (int, float))]
            
            result = {
                "name": name,
                "type": metric["type"].value if metric["type"] else None,
                "count": len(values),
                "sum": metric["sum"],
                "latest": values[-1].value if values else None,
            }
            
            if numeric_values:
                result.update({
                    "min": min(numeric_values),
                    "max": max(numeric_values),
                    "mean": statistics.mean(numeric_values),
                })
                
                if len(numeric_values) > 1:
                    result["stddev"] = statistics.stdev(numeric_values)
                
                # Percentiles
                sorted_values = sorted(numeric_values)
                result["p50"] = sorted_values[len(sorted_values) // 2]
                result["p95"] = sorted_values[int(len(sorted_values) * 0.95)]
                result["p99"] = sorted_values[int(len(sorted_values) * 0.99)]
            
            return result
    
    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all collected metrics.
        
        Returns:
            Dictionary of all metrics
        """
        with self._lock:
            return {name: self.get_metric(name) for name in self._metrics.keys()}
    
    def get_metrics_by_prefix(self, prefix: str) -> Dict[str, Dict[str, Any]]:
        """
        Get metrics filtered by name prefix.
        
        Args:
            prefix: Metric name prefix
        
        Returns:
            Filtered metrics
        """
        with self._lock:
            return {
                name: self.get_metric(name)
                for name in self._metrics.keys()
                if name.startswith(prefix)
            }
    
    def reset(self, name: Optional[str] = None) -> None:
        """
        Reset metric(s).
        
        Args:
            name: Metric name to reset, or None to reset all
        """
        with self._lock:
            if name:
                if name in self._metrics:
                    del self._metrics[name]
            else:
                self._metrics.clear()
    
    def export_json(self, path: Optional[Path] = None) -> Path:
        """
        Export metrics to JSON file.
        
        Args:
            path: Export path (uses export_path if not specified)
        
        Returns:
            Path to exported file
        """
        export_path = path or self.export_path
        if not export_path:
            raise ValueError("No export path specified")
        
        export_path = Path(export_path)
        export_path.parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            "exported_at": datetime.utcnow().isoformat() + "Z",
            "metrics": self.get_all_metrics(),
        }
        
        with open(export_path, "w") as f:
            json.dump(data, f, indent=2, default=str)
        
        return export_path
    
    def export_prometheus(self, path: Optional[Path] = None) -> Path:
        """
        Export metrics in Prometheus format.
        
        Args:
            path: Export path
        
        Returns:
            Path to exported file
        """
        export_path = path or (self.export_path.parent / "metrics.prom" if self.export_path else None)
        if not export_path:
            raise ValueError("No export path specified")
        
        export_path = Path(export_path)
        export_path.parent.mkdir(parents=True, exist_ok=True)
        
        lines = []
        metrics = self.get_all_metrics()
        
        for name, data in metrics.items():
            if not data:
                continue
            
            metric_type = data.get("type", "gauge")
            
            # Prometheus metric type
            type_map = {
                "counter": "counter",
                "gauge": "gauge",
                "histogram": "histogram",
                "timer": "summary",
            }
            
            lines.append(f"# HELP {name} HelixLLM metric")
            lines.append(f"# TYPE {name} {type_map.get(metric_type, 'gauge')}")
            
            # Export summary statistics
            if "sum" in data:
                lines.append(f"{name}_sum {data['sum']}")
            if "count" in data:
                lines.append(f"{name}_count {data['count']}")
            
            lines.append("")
        
        with open(export_path, "w") as f:
            f.write("\n".join(lines))
        
        return export_path
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Get summary of all metrics.
        
        Returns:
            Summary dictionary
        """
        metrics = self.get_all_metrics()
        
        return {
            "total_metrics": len(metrics),
            "metric_types": defaultdict(int),
            "by_category": defaultdict(int),
        }


# Global metrics instance
_global_metrics: Optional[MetricsCollector] = None


def get_metrics() -> MetricsCollector:
    """Get global metrics collector."""
    global _global_metrics
    if _global_metrics is None:
        _global_metrics = MetricsCollector()
    return _global_metrics
