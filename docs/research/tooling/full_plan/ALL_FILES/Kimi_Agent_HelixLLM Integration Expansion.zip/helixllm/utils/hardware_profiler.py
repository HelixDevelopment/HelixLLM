"""
Hardware profiling and optimization for HelixLLM.

Detects available hardware and provides optimized configuration recommendations.
"""

import os
import platform
import subprocess
import threading
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import json
import logging

# Optional imports with fallbacks
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    import pynvml
    NVML_AVAILABLE = True
except ImportError:
    NVML_AVAILABLE = False


class HardwareType(Enum):
    """Types of hardware acceleration."""
    CPU = "cpu"
    CUDA = "cuda"
    ROCM = "rocm"
    METAL = "metal"
    VULKAN = "vulkan"
    OPENCL = "opencl"


class CPUVendor(Enum):
    """CPU vendor types."""
    AMD = "amd"
    INTEL = "intel"
    ARM = "arm"
    APPLE = "apple"
    UNKNOWN = "unknown"


@dataclass
class GPUInfo:
    """GPU information."""
    index: int
    name: str
    total_memory_mb: int
    free_memory_mb: int
    compute_capability: Optional[str] = None
    driver_version: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class CPUInfo:
    """CPU information."""
    vendor: CPUVendor
    model: str
    cores_physical: int
    cores_logical: int
    frequency_mhz: float
    architecture: str
    flags: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "vendor": self.vendor.value,
            "model": self.model,
            "cores_physical": self.cores_physical,
            "cores_logical": self.cores_logical,
            "frequency_mhz": self.frequency_mhz,
            "architecture": self.architecture,
            "flags": self.flags,
        }


@dataclass
class MemoryInfo:
    """System memory information."""
    total_mb: int
    available_mb: int
    used_mb: int
    percent_used: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class HardwareProfile:
    """Complete hardware profile."""
    cpu: CPUInfo
    memory: MemoryInfo
    gpus: List[GPUInfo]
    os_name: str
    os_version: str
    python_version: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "cpu": self.cpu.to_dict(),
            "memory": self.memory.to_dict(),
            "gpus": [gpu.to_dict() for gpu in self.gpus],
            "os_name": self.os_name,
            "os_version": self.os_version,
            "python_version": self.python_version,
        }


@dataclass
class OptimizationConfig:
    """Optimized configuration for detected hardware."""
    # Model loading
    n_gpu_layers: int
    main_gpu: int
    tensor_split: Optional[List[float]]
    
    # Context and batching
    n_ctx: int
    n_batch: int
    n_ubatch: int
    
    # Threading
    n_threads: int
    n_threads_batch: int
    
    # Memory
    use_mmap: bool
    use_mlock: bool
    
    # Offloading
    offload_kqv: bool
    
    # Flash attention
    flash_attn: bool
    
    # Hardware type
    hardware_type: HardwareType
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "n_gpu_layers": self.n_gpu_layers,
            "main_gpu": self.main_gpu,
            "tensor_split": self.tensor_split,
            "n_ctx": self.n_ctx,
            "n_batch": self.n_batch,
            "n_ubatch": self.n_ubatch,
            "n_threads": self.n_threads,
            "n_threads_batch": self.n_threads_batch,
            "use_mmap": self.use_mmap,
            "use_mlock": self.use_mlock,
            "offload_kqv": self.offload_kqv,
            "flash_attn": self.flash_attn,
            "hardware_type": self.hardware_type.value,
        }


class HardwareProfiler:
    """
    Profiles system hardware and provides optimization recommendations.
    
    Detects CPU, GPU, and memory capabilities to generate optimal
    llama.cpp configuration parameters.
    
    Attributes:
        profile: Detected hardware profile
        config: Recommended optimization configuration
    
    Example:
        >>> profiler = HardwareProfiler()
        >>> print(profiler.profile.to_dict())
        >>> print(profiler.config.to_dict())
    """
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Initialize hardware profiler.
        
        Args:
            logger: Optional logger instance
        """
        self.logger = logger or logging.getLogger(__name__)
        self._lock = threading.Lock()
        self._profile: Optional[HardwareProfile] = None
        self._config: Optional[OptimizationConfig] = None
        self._nvml_initialized = False
        
        # Initialize NVML if available
        if NVML_AVAILABLE:
            try:
                pynvml.nvmlInit()
                self._nvml_initialized = True
                self.logger.debug("NVML initialized successfully")
            except Exception as e:
                self.logger.warning(f"Failed to initialize NVML: {e}")
    
    def __del__(self):
        """Cleanup NVML on destruction."""
        if self._nvml_initialized:
            try:
                pynvml.nvmlShutdown()
            except:
                pass
    
    def profile(self, force_refresh: bool = False) -> HardwareProfile:
        """
        Profile system hardware.
        
        Args:
            force_refresh: Force re-profiling even if cached
        
        Returns:
            Hardware profile
        """
        with self._lock:
            if self._profile is None or force_refresh:
                self._profile = self._detect_hardware()
            return self._profile
    
    def get_optimization_config(self, force_refresh: bool = False) -> OptimizationConfig:
        """
        Get optimized configuration for detected hardware.
        
        Args:
            force_refresh: Force recalculation even if cached
        
        Returns:
            Optimization configuration
        """
        with self._lock:
            if self._config is None or force_refresh:
                hw_profile = self.profile(force_refresh)
                self._config = self._calculate_optimal_config(hw_profile)
            return self._config
    
    def _detect_hardware(self) -> HardwareProfile:
        """Detect system hardware capabilities."""
        self.logger.info("Detecting hardware...")
        
        cpu_info = self._detect_cpu()
        memory_info = self._detect_memory()
        gpus = self._detect_gpus()
        
        profile = HardwareProfile(
            cpu=cpu_info,
            memory=memory_info,
            gpus=gpus,
            os_name=platform.system(),
            os_version=platform.release(),
            python_version=platform.python_version(),
        )
        
        self.logger.info(f"Detected {len(gpus)} GPU(s), {cpu_info.cores_logical} CPU threads")
        
        return profile
    
    def _detect_cpu(self) -> CPUInfo:
        """Detect CPU information."""
        # Get CPU info
        cpu_info = platform.processor()
        machine = platform.machine()
        
        # Detect vendor
        vendor = CPUVendor.UNKNOWN
        cpu_info_lower = cpu_info.lower()
        
        if "amd" in cpu_info_lower:
            vendor = CPUVendor.AMD
        elif "intel" in cpu_info_lower:
            vendor = CPUVendor.INTEL
        elif "arm" in cpu_info_lower:
            vendor = CPUVendor.ARM
        elif "apple" in cpu_info_lower:
            vendor = CPUVendor.APPLE
        
        # Get core counts
        if PSUTIL_AVAILABLE:
            cores_physical = psutil.cpu_count(logical=False) or 1
            cores_logical = psutil.cpu_count(logical=True) or 1
            freq = psutil.cpu_freq()
            frequency_mhz = freq.current if freq else 0.0
        else:
            cores_physical = os.cpu_count() or 1
            cores_logical = cores_physical
            frequency_mhz = 0.0
        
        # Get CPU flags
        flags = self._get_cpu_flags()
        
        return CPUInfo(
            vendor=vendor,
            model=cpu_info or "Unknown",
            cores_physical=cores_physical,
            cores_logical=cores_logical,
            frequency_mhz=frequency_mhz,
            architecture=machine,
            flags=flags,
        )
    
    def _get_cpu_flags(self) -> List[str]:
        """Get CPU feature flags."""
        flags = []
        
        try:
            if platform.system() == "Linux":
                with open("/proc/cpuinfo", "r") as f:
                    for line in f:
                        if line.startswith("flags") or line.startswith("Features"):
                            flags = line.split(":")[1].strip().split()
                            break
            elif platform.system() == "Darwin":
                result = subprocess.run(
                    ["sysctl", "-a"],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                for line in result.stdout.split("\n"):
                    if "machdep.cpu.features" in line or "machdep.cpu.leaf7_features" in line:
                        flags.extend(line.split(":")[1].strip().lower().split())
        except Exception as e:
            self.logger.debug(f"Could not get CPU flags: {e}")
        
        return flags
    
    def _detect_memory(self) -> MemoryInfo:
        """Detect system memory information."""
        if PSUTIL_AVAILABLE:
            mem = psutil.virtual_memory()
            return MemoryInfo(
                total_mb=mem.total // (1024 * 1024),
                available_mb=mem.available // (1024 * 1024),
                used_mb=mem.used // (1024 * 1024),
                percent_used=mem.percent,
            )
        else:
            # Fallback
            return MemoryInfo(
                total_mb=32768,  # Assume 32GB
                available_mb=16384,
                used_mb=16384,
                percent_used=50.0,
            )
    
    def _detect_gpus(self) -> List[GPUInfo]:
        """Detect GPU information."""
        gpus = []
        
        # Try NVML for NVIDIA GPUs
        if self._nvml_initialized:
            try:
                device_count = pynvml.nvmlDeviceGetCount()
                for i in range(device_count):
                    handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                    
                    name = pynvml.nvmlDeviceGetName(handle)
                    if isinstance(name, bytes):
                        name = name.decode("utf-8")
                    
                    mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    total_mb = mem_info.total // (1024 * 1024)
                    free_mb = mem_info.free // (1024 * 1024)
                    
                    try:
                        driver = pynvml.nvmlSystemGetDriverVersion()
                        if isinstance(driver, bytes):
                            driver = driver.decode("utf-8")
                    except:
                        driver = None
                    
                    gpus.append(GPUInfo(
                        index=i,
                        name=name,
                        total_memory_mb=total_mb,
                        free_memory_mb=free_mb,
                        driver_version=driver,
                    ))
            except Exception as e:
                self.logger.debug(f"NVML detection failed: {e}")
        
        # Try nvidia-smi as fallback
        if not gpus:
            gpus = self._detect_nvidia_smi()
        
        # Try rocm-smi for AMD GPUs
        if not gpus:
            gpus = self._detect_rocm_smi()
        
        return gpus
    
    def _detect_nvidia_smi(self) -> List[GPUInfo]:
        """Detect NVIDIA GPUs using nvidia-smi."""
        gpus = []
        
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total,memory.free", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                check=True,
            )
            
            for i, line in enumerate(result.stdout.strip().split("\n")):
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 3:
                    name = parts[0]
                    total_str = parts[1].replace("MiB", "").replace("MB", "").strip()
                    free_str = parts[2].replace("MiB", "").replace("MB", "").strip()
                    
                    gpus.append(GPUInfo(
                        index=i,
                        name=name,
                        total_memory_mb=int(total_str),
                        free_memory_mb=int(free_str),
                    ))
        except Exception as e:
            self.logger.debug(f"nvidia-smi detection failed: {e}")
        
        return gpus
    
    def _detect_rocm_smi(self) -> List[GPUInfo]:
        """Detect AMD GPUs using rocm-smi."""
        gpus = []
        
        try:
            result = subprocess.run(
                ["rocm-smi", "--showproductname", "--showmeminfo", "vram"],
                capture_output=True,
                text=True,
                check=True,
            )
            
            # Parse rocm-smi output
            lines = result.stdout.strip().split("\n")
            # Basic parsing - would need more sophisticated parsing for full support
            self.logger.debug(f"rocm-smi detected: {len(lines)} lines")
            
        except Exception as e:
            self.logger.debug(f"rocm-smi detection failed: {e}")
        
        return gpus
    
    def _calculate_optimal_config(self, profile: HardwareProfile) -> OptimizationConfig:
        """Calculate optimal configuration for detected hardware."""
        self.logger.info("Calculating optimal configuration...")
        
        # Determine hardware type
        hardware_type = HardwareType.CPU
        if profile.gpus:
            # Check for CUDA
            if any("nvidia" in gpu.name.lower() for gpu in profile.gpus):
                hardware_type = HardwareType.CUDA
            # Check for ROCm
            elif any("amd" in gpu.name.lower() or "radeon" in gpu.name.lower() for gpu in profile.gpus):
                hardware_type = HardwareType.ROCM
        elif platform.system() == "Darwin" and "arm" in profile.cpu.architecture.lower():
            hardware_type = HardwareType.METAL
        
        # Calculate GPU layers
        n_gpu_layers = self._calculate_gpu_layers(profile)
        
        # Calculate context size based on available memory
        n_ctx = self._calculate_context_size(profile, n_gpu_layers)
        
        # Calculate batch sizes
        n_batch = min(512, n_ctx // 4)
        n_ubatch = min(256, n_batch // 2)
        
        # Calculate thread counts
        n_threads = max(4, profile.cpu.cores_logical // 2)
        n_threads_batch = max(2, profile.cpu.cores_logical // 4)
        
        # Memory settings
        use_mmap = True
        use_mlock = False  # Only enable if you have enough RAM
        
        # Offloading settings
        offload_kqv = n_gpu_layers > 0
        
        # Flash attention (requires specific hardware support)
        flash_attn = self._check_flash_attention_support(profile)
        
        config = OptimizationConfig(
            n_gpu_layers=n_gpu_layers,
            main_gpu=0,
            tensor_split=None,
            n_ctx=n_ctx,
            n_batch=n_batch,
            n_ubatch=n_ubatch,
            n_threads=n_threads,
            n_threads_batch=n_threads_batch,
            use_mmap=use_mmap,
            use_mlock=use_mlock,
            offload_kqv=offload_kqv,
            flash_attn=flash_attn,
            hardware_type=hardware_type,
        )
        
        self.logger.info(f"Optimal config: {n_gpu_layers} GPU layers, {n_ctx} context")
        
        return config
    
    def _calculate_gpu_layers(self, profile: HardwareProfile) -> int:
        """Calculate optimal number of GPU layers."""
        if not profile.gpus:
            return 0
        
        # Get primary GPU
        primary_gpu = profile.gpus[0]
        free_memory_mb = primary_gpu.free_memory_mb
        
        # Estimate layers based on available VRAM
        # Rough estimate: ~150MB per layer for 7B model at Q4_K_M
        memory_per_layer = 150
        
        # Reserve some memory for context and overhead
        reserved_memory = 1024  # 1GB reserved
        available_memory = max(0, free_memory_mb - reserved_memory)
        
        estimated_layers = available_memory // memory_per_layer
        
        # Cap at reasonable maximum
        max_layers = 35  # Typical for 7B models
        
        return min(estimated_layers, max_layers)
    
    def _calculate_context_size(self, profile: HardwareProfile, n_gpu_layers: int) -> int:
        """Calculate optimal context size."""
        # Base context size
        base_ctx = 4096
        
        if n_gpu_layers > 0 and profile.gpus:
            # Can use larger context with GPU offloading
            gpu_memory = profile.gpus[0].free_memory_mb
            
            if gpu_memory > 5000:  # > 5GB
                base_ctx = 8192
            if gpu_memory > 10000:  # > 10GB
                base_ctx = 16384
            if gpu_memory > 20000:  # > 20GB
                base_ctx = 32768
        
        # Adjust based on system RAM
        total_ram_gb = profile.memory.total_mb // 1024
        if total_ram_gb < 16:
            base_ctx = min(base_ctx, 4096)
        elif total_ram_gb >= 64:
            base_ctx = max(base_ctx, 8192)
        
        # Round to nearest 512
        return (base_ctx // 512) * 512
    
    def _check_flash_attention_support(self, profile: HardwareProfile) -> bool:
        """Check if flash attention is supported."""
        # Flash attention requires specific GPU support
        if not profile.gpus:
            return False
        
        # Check for NVIDIA GPUs with sufficient compute capability
        for gpu in profile.gpus:
            name_lower = gpu.name.lower()
            # Ampere (30 series) or newer
            if any(x in name_lower for x in ["rtx 30", "rtx 40", "a100", "h100"]):
                return True
        
        return False
    
    def get_recommended_model_size(self) -> str:
        """Get recommended model size based on hardware."""
        profile = self.profile()
        
        if profile.gpus:
            vram_mb = profile.gpus[0].total_memory_mb
            vram_gb = vram_mb / 1024
            
            if vram_gb >= 24:
                return "70B"
            elif vram_gb >= 16:
                return "34B"
            elif vram_gb >= 8:
                return "13B"
            elif vram_gb >= 6:
                return "7B"
        
        # CPU-only fallback
        ram_gb = profile.memory.total_mb / 1024
        
        if ram_gb >= 64:
            return "13B"
        elif ram_gb >= 32:
            return "7B"
        else:
            return "3B"
    
    def get_recommended_quantization(self) -> str:
        """Get recommended quantization level."""
        profile = self.profile()
        
        if profile.gpus:
            vram_gb = profile.gpus[0].total_memory_mb / 1024
            
            if vram_gb >= 16:
                return "Q5_K_M"  # High quality
            elif vram_gb >= 8:
                return "Q4_K_M"  # Balanced
            else:
                return "Q3_K_M"  # Compressed
        
        return "Q4_K_M"  # Default
    
    def export_profile(self, path: Path) -> None:
        """Export hardware profile to JSON file."""
        data = {
            "profile": self.profile().to_dict(),
            "optimization_config": self.get_optimization_config().to_dict(),
            "recommendations": {
                "model_size": self.get_recommended_model_size(),
                "quantization": self.get_recommended_quantization(),
            },
        }
        
        with open(path, "w") as f:
            json.dump(data, f, indent=2)


def get_optimal_config() -> OptimizationConfig:
    """Get optimal configuration for current hardware."""
    profiler = HardwareProfiler()
    return profiler.get_optimization_config()
