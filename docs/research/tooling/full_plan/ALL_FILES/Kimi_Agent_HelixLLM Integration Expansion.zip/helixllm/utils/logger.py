"""
Structured logging utility for HelixLLM.

Provides configurable logging with JSON formatting, rotation, and multiple output targets.
"""

import json
import logging
import logging.handlers
import sys
import traceback
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, asdict
from contextvars import ContextVar
import threading


class LogLevel(Enum):
    """Log level enumeration."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


@dataclass
class LogContext:
    """Contextual information for log entries."""
    request_id: Optional[str] = None
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    component: Optional[str] = None
    operation: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


# Context variable for request tracking
request_context: ContextVar[Optional[LogContext]] = ContextVar('request_context', default=None)


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def __init__(
        self,
        include_timestamp: bool = True,
        include_source: bool = True,
        include_context: bool = True
    ):
        super().__init__()
        self.include_timestamp = include_timestamp
        self.include_source = include_source
        self.include_context = include_context
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_entry: Dict[str, Any] = {
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
        }
        
        if self.include_timestamp:
            log_entry["timestamp"] = datetime.utcnow().isoformat() + "Z"
        
        if self.include_source:
            log_entry["source"] = {
                "file": record.pathname,
                "line": record.lineno,
                "function": record.funcName,
            }
        
        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else None,
                "message": str(record.exc_info[1]) if record.exc_info[1] else None,
                "traceback": traceback.format_exception(*record.exc_info),
            }
        
        # Add extra fields
        if hasattr(record, "extra"):
            log_entry["extra"] = record.extra
        
        # Add context if available
        if self.include_context:
            ctx = request_context.get()
            if ctx:
                log_entry["context"] = ctx.to_dict()
        
        return json.dumps(log_entry, default=str)


class ConsoleFormatter(logging.Formatter):
    """Human-readable console formatter with colors."""
    
    COLORS = {
        "DEBUG": "\033[36m",      # Cyan
        "INFO": "\033[32m",       # Green
        "WARNING": "\033[33m",    # Yellow
        "ERROR": "\033[31m",      # Red
        "CRITICAL": "\033[35m",   # Magenta
        "RESET": "\033[0m",
    }
    
    def __init__(self, use_colors: bool = True):
        super().__init__()
        self.use_colors = use_colors
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record for console output."""
        color = self.COLORS.get(record.levelname, "") if self.use_colors else ""
        reset = self.COLORS["RESET"] if self.use_colors else ""
        
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        
        formatted = f"{timestamp} | {color}{record.levelname:8}{reset} | {record.name} | {record.getMessage()}"
        
        if record.exc_info:
            formatted += "\n" + "".join(traceback.format_exception(*record.exc_info))
        
        return formatted


class Logger:
    """
    Structured logger for HelixLLM.
    
    Provides configurable logging with multiple output formats and destinations.
    
    Attributes:
        name: Logger name
        level: Minimum log level
        handlers: List of configured handlers
    
    Example:
        >>> logger = Logger("helixllm")
        >>> logger.info("Starting HelixLLM", extra={"version": "1.0.0"})
    """
    
    _loggers: Dict[str, "Logger"] = {}
    _lock = threading.Lock()
    
    def __new__(cls, name: str, *args, **kwargs) -> "Logger":
        """Singleton pattern - return existing logger if available."""
        with cls._lock:
            if name not in cls._loggers:
                instance = super().__new__(cls)
                cls._loggers[name] = instance
            return cls._loggers[name]
    
    def __init__(
        self,
        name: str,
        level: LogLevel = LogLevel.INFO,
        log_dir: Optional[Union[str, Path]] = None,
        max_bytes: int = 10 * 1024 * 1024,  # 10MB
        backup_count: int = 5,
        console_output: bool = True,
        json_output: bool = True,
        use_colors: bool = True,
    ):
        """
        Initialize the logger.
        
        Args:
            name: Logger name
            level: Minimum log level
            log_dir: Directory for log files (None for no file logging)
            max_bytes: Maximum bytes per log file
            backup_count: Number of backup files to keep
            console_output: Enable console output
            json_output: Use JSON formatting for files
            use_colors: Use colors in console output
        """
        # Avoid re-initialization for singleton
        if hasattr(self, "_initialized"):
            return
        self._initialized = True
        
        self.name = name
        self.level = level
        self.log_dir = Path(log_dir) if log_dir else None
        self.max_bytes = max_bytes
        self.backup_count = backup_count
        self.console_output = console_output
        self.json_output = json_output
        self.use_colors = use_colors
        
        self._logger = logging.getLogger(name)
        self._logger.setLevel(getattr(logging, level.value))
        self._logger.handlers = []  # Clear existing handlers
        
        self._setup_handlers()
    
    def _setup_handlers(self) -> None:
        """Configure log handlers."""
        # Console handler
        if self.console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(getattr(logging, self.level.value))
            console_handler.setFormatter(ConsoleFormatter(use_colors=self.use_colors))
            self._logger.addHandler(console_handler)
        
        # File handlers
        if self.log_dir:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            
            # Main log file
            main_log = self.log_dir / f"{self.name}.log"
            file_handler = logging.handlers.RotatingFileHandler(
                main_log,
                maxBytes=self.max_bytes,
                backupCount=self.backup_count,
            )
            file_handler.setLevel(getattr(logging, self.level.value))
            
            if self.json_output:
                file_handler.setFormatter(JSONFormatter())
            else:
                file_handler.setFormatter(
                    logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
                )
            self._logger.addHandler(file_handler)
            
            # Error log file (errors only)
            error_log = self.log_dir / f"{self.name}.error.log"
            error_handler = logging.handlers.RotatingFileHandler(
                error_log,
                maxBytes=self.max_bytes,
                backupCount=self.backup_count,
            )
            error_handler.setLevel(logging.ERROR)
            error_handler.setFormatter(JSONFormatter())
            self._logger.addHandler(error_handler)
    
    def _log(
        self,
        level: LogLevel,
        message: str,
        extra: Optional[Dict[str, Any]] = None,
        exc_info: Optional[tuple] = None,
    ) -> None:
        """Internal log method."""
        log_method = getattr(self._logger, level.value.lower())
        
        # Create log record with extra fields
        if extra:
            record = self._logger.makeRecord(
                self.name,
                getattr(logging, level.value),
                "",
                0,
                message,
                (),
                exc_info,
            )
            record.extra = extra
            self._logger.handle(record)
        else:
            log_method(message, exc_info=exc_info)
    
    def debug(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """
        Log debug message.
        
        Args:
            message: Log message
            extra: Additional fields to include
        """
        self._log(LogLevel.DEBUG, message, extra)
    
    def info(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """
        Log info message.
        
        Args:
            message: Log message
            extra: Additional fields to include
        """
        self._log(LogLevel.INFO, message, extra)
    
    def warning(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """
        Log warning message.
        
        Args:
            message: Log message
            extra: Additional fields to include
        """
        self._log(LogLevel.WARNING, message, extra)
    
    def error(
        self,
        message: str,
        extra: Optional[Dict[str, Any]] = None,
        exc_info: bool = True,
    ) -> None:
        """
        Log error message.
        
        Args:
            message: Log message
            extra: Additional fields to include
            exc_info: Include exception information
        """
        self._log(LogLevel.ERROR, message, extra, sys.exc_info() if exc_info else None)
    
    def critical(
        self,
        message: str,
        extra: Optional[Dict[str, Any]] = None,
        exc_info: bool = True,
    ) -> None:
        """
        Log critical message.
        
        Args:
            message: Log message
            extra: Additional fields to include
            exc_info: Include exception information
        """
        self._log(LogLevel.CRITICAL, message, extra, sys.exc_info() if exc_info else None)
    
    def exception(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """
        Log exception with full traceback.
        
        Args:
            message: Log message
            extra: Additional fields to include
        """
        self._log(LogLevel.ERROR, message, extra, sys.exc_info())
    
    @contextmanager
    def context(self, **kwargs) -> None:
        """
        Context manager for setting log context.
        
        Args:
            **kwargs: Context fields (request_id, session_id, etc.)
        
        Example:
            >>> with logger.context(request_id="abc123", component="inference"):
            ...     logger.info("Processing request")
        """
        ctx = LogContext(**kwargs)
        token = request_context.set(ctx)
        try:
            yield
        finally:
            request_context.reset(token)
    
    def set_level(self, level: LogLevel) -> None:
        """
        Set logger level.
        
        Args:
            level: New log level
        """
        self._logger.setLevel(getattr(logging, level.value))
        for handler in self._logger.handlers:
            handler.setLevel(getattr(logging, level.value))
    
    def add_handler(self, handler: logging.Handler) -> None:
        """
        Add custom handler.
        
        Args:
            handler: Logging handler to add
        """
        self._logger.addHandler(handler)
    
    def remove_handler(self, handler: logging.Handler) -> None:
        """
        Remove handler.
        
        Args:
            handler: Handler to remove
        """
        self._logger.removeHandler(handler)
    
    @classmethod
    def get_logger(cls, name: str) -> "Logger":
        """
        Get or create logger instance.
        
        Args:
            name: Logger name
        
        Returns:
            Logger instance
        """
        return cls(name)


# Convenience function for getting default logger
def get_logger(name: str = "helixllm") -> Logger:
    """Get default HelixLLM logger."""
    return Logger.get_logger(name)
