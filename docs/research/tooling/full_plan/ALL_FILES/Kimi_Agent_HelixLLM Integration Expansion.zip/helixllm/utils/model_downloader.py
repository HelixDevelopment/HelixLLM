"""
Model downloader for HelixLLM.

Downloads GGUF models from HuggingFace Hub with resume support and verification.
"""

import hashlib
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Union
from urllib.parse import urlparse
import json
import logging

# Optional imports with fallbacks
try:
    from huggingface_hub import hf_hub_download, HfApi, hf_hub_url
    from huggingface_hub.utils import RepositoryNotFoundError, RevisionNotFoundError
    HF_HUB_AVAILABLE = True
except ImportError:
    HF_HUB_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


@dataclass
class DownloadProgress:
    """Download progress information."""
    file_name: str
    downloaded_bytes: int
    total_bytes: int
    speed_mbps: float
    eta_seconds: float
    status: str  # "downloading", "completed", "error", "paused"
    
    @property
    def percent_complete(self) -> float:
        """Calculate percentage complete."""
        if self.total_bytes == 0:
            return 0.0
        return (self.downloaded_bytes / self.total_bytes) * 100


@dataclass
class ModelInfo:
    """Information about a downloadable model."""
    repo_id: str
    filename: str
    size_bytes: Optional[int]
    sha256: Optional[str]
    quantization: Optional[str]
    parameters: Optional[str]
    
    @property
    def size_gb(self) -> float:
        """Get size in gigabytes."""
        if self.size_bytes:
            return self.size_bytes / (1024 ** 3)
        return 0.0


class DownloadError(Exception):
    """Exception raised during model download."""
    pass


class VerificationError(Exception):
    """Exception raised during model verification."""
    pass


class ModelDownloader:
    """
    Downloads and manages GGUF models from HuggingFace Hub.
    
    Provides resume support, progress tracking, and checksum verification
    for reliable model downloads.
    
    Attributes:
        cache_dir: Directory for downloaded models
        token: HuggingFace API token
    
    Example:
        >>> downloader = ModelDownloader(cache_dir="./models")
        >>> model_path = downloader.download("TheBloke/Llama-2-7B-GGUF", "llama-2-7b.Q4_K_M.gguf")
    """
    
    # Common GGUF model repositories
    POPULAR_MODELS = {
        "llama-2-7b": {
            "repo_id": "TheBloke/Llama-2-7B-GGUF",
            "files": {
                "Q4_K_M": "llama-2-7b.Q4_K_M.gguf",
                "Q5_K_M": "llama-2-7b.Q5_K_M.gguf",
                "Q6_K": "llama-2-7b.Q6_K.gguf",
            },
        },
        "llama-2-13b": {
            "repo_id": "TheBloke/Llama-2-13B-GGUF",
            "files": {
                "Q4_K_M": "llama-2-13b.Q4_K_M.gguf",
                "Q5_K_M": "llama-2-13b.Q5_K_M.gguf",
            },
        },
        "mistral-7b": {
            "repo_id": "TheBloke/Mistral-7B-v0.1-GGUF",
            "files": {
                "Q4_K_M": "mistral-7b-v0.1.Q4_K_M.gguf",
                "Q5_K_M": "mistral-7b-v0.1.Q5_K_M.gguf",
            },
        },
        "mixtral-8x7b": {
            "repo_id": "TheBloke/Mixtral-8x7B-v0.1-GGUF",
            "files": {
                "Q4_K_M": "mixtral-8x7b-v0.1.Q4_K_M.gguf",
            },
        },
        "nomic-embed": {
            "repo_id": "nomic-ai/nomic-embed-text-v1.5-GGUF",
            "files": {
                "default": "nomic-embed-text-v1.5.Q4_K_M.gguf",
            },
        },
    }
    
    def __init__(
        self,
        cache_dir: Union[str, Path] = "./models",
        token: Optional[str] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """
        Initialize model downloader.
        
        Args:
            cache_dir: Directory for downloaded models
            token: HuggingFace API token for private models
            logger: Optional logger instance
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.token = token or os.environ.get("HF_TOKEN")
        self.logger = logger or logging.getLogger(__name__)
        
        self._lock = threading.Lock()
        self._active_downloads: Dict[str, DownloadProgress] = {}
        self._progress_callbacks: List[Callable[[DownloadProgress], None]] = []
        
        if not HF_HUB_AVAILABLE:
            self.logger.warning("huggingface_hub not available. Install with: pip install huggingface_hub")
    
    def download(
        self,
        repo_id: str,
        filename: str,
        local_dir: Optional[Union[str, Path]] = None,
        revision: Optional[str] = None,
        resume: bool = True,
        verify: bool = True,
        progress_callback: Optional[Callable[[DownloadProgress], None]] = None,
    ) -> Path:
        """
        Download a model file from HuggingFace Hub.
        
        Args:
            repo_id: HuggingFace repository ID
            filename: Name of the file to download
            local_dir: Local directory for download (default: cache_dir)
            revision: Git revision to download from
            resume: Enable resume for partial downloads
            verify: Verify checksum after download
            progress_callback: Callback for progress updates
        
        Returns:
            Path to downloaded file
        
        Raises:
            DownloadError: If download fails
            VerificationError: If verification fails
        """
        if not HF_HUB_AVAILABLE:
            raise DownloadError("huggingface_hub is required for downloads")
        
        local_dir = Path(local_dir) if local_dir else self.cache_dir
        local_dir.mkdir(parents=True, exist_ok=True)
        
        download_key = f"{repo_id}/{filename}"
        
        try:
            self.logger.info(f"Downloading {filename} from {repo_id}")
            
            # Register progress callback
            if progress_callback:
                self._progress_callbacks.append(progress_callback)
            
            # Initialize progress tracking
            self._active_downloads[download_key] = DownloadProgress(
                file_name=filename,
                downloaded_bytes=0,
                total_bytes=0,
                speed_mbps=0.0,
                eta_seconds=0.0,
                status="downloading",
            )
            
            # Download using huggingface_hub
            local_path = hf_hub_download(
                repo_id=repo_id,
                filename=filename,
                local_dir=str(local_dir),
                revision=revision,
                resume_download=resume,
                token=self.token,
                local_files_only=False,
            )
            
            # Update progress
            if download_key in self._active_downloads:
                progress = self._active_downloads[download_key]
                progress.status = "completed"
                progress.downloaded_bytes = progress.total_bytes
                self._notify_progress(progress)
            
            self.logger.info(f"Downloaded to {local_path}")
            
            # Verify if requested
            if verify:
                self.verify_file(Path(local_path), repo_id, filename)
            
            return Path(local_path)
            
        except RepositoryNotFoundError:
            raise DownloadError(f"Repository not found: {repo_id}")
        except RevisionNotFoundError:
            raise DownloadError(f"Revision not found: {revision}")
        except Exception as e:
            if download_key in self._active_downloads:
                self._active_downloads[download_key].status = "error"
            raise DownloadError(f"Download failed: {e}")
        finally:
            # Cleanup
            if download_key in self._active_downloads:
                del self._active_downloads[download_key]
            if progress_callback and progress_callback in self._progress_callbacks:
                self._progress_callbacks.remove(progress_callback)
    
    def download_popular(
        self,
        model_name: str,
        quantization: str = "Q4_K_M",
        **kwargs,
    ) -> Path:
        """
        Download a popular model by name.
        
        Args:
            model_name: Name of the popular model
            quantization: Quantization level
            **kwargs: Additional arguments for download()
        
        Returns:
            Path to downloaded file
        """
        if model_name not in self.POPULAR_MODELS:
            available = ", ".join(self.POPULAR_MODELS.keys())
            raise DownloadError(f"Unknown model: {model_name}. Available: {available}")
        
        model_info = self.POPULAR_MODELS[model_name]
        repo_id = model_info["repo_id"]
        
        if quantization not in model_info["files"]:
            available = ", ".join(model_info["files"].keys())
            raise DownloadError(f"Unknown quantization: {quantization}. Available: {available}")
        
        filename = model_info["files"][quantization]
        
        return self.download(repo_id, filename, **kwargs)
    
    def list_files(self, repo_id: str, revision: Optional[str] = None) -> List[str]:
        """
        List files in a HuggingFace repository.
        
        Args:
            repo_id: Repository ID
            revision: Git revision
        
        Returns:
            List of filenames
        """
        if not HF_HUB_AVAILABLE:
            raise DownloadError("huggingface_hub is required")
        
        try:
            api = HfApi(token=self.token)
            repo_files = api.list_repo_files(repo_id, revision=revision)
            return [f for f in repo_files if f.endswith(".gguf")]
        except Exception as e:
            raise DownloadError(f"Failed to list files: {e}")
    
    def get_model_info(self, repo_id: str, filename: str) -> ModelInfo:
        """
        Get information about a model file.
        
        Args:
            repo_id: Repository ID
            filename: Filename
        
        Returns:
            Model information
        """
        if not HF_HUB_AVAILABLE:
            raise DownloadError("huggingface_hub is required")
        
        try:
            api = HfApi(token=self.token)
            
            # Get file metadata
            url = hf_hub_url(repo_id, filename)
            
            # Parse filename for info
            quant = None
            params = None
            
            parts = filename.replace(".gguf", "").split(".")
            for part in parts:
                if part.startswith("Q") and "_" in part:
                    quant = part
                elif "B" in part and any(c.isdigit() for c in part):
                    params = part
            
            return ModelInfo(
                repo_id=repo_id,
                filename=filename,
                size_bytes=None,  # Would need to fetch from API
                sha256=None,
                quantization=quant,
                parameters=params,
            )
        except Exception as e:
            raise DownloadError(f"Failed to get model info: {e}")
    
    def verify_file(
        self,
        file_path: Path,
        repo_id: Optional[str] = None,
        filename: Optional[str] = None,
        expected_sha256: Optional[str] = None,
    ) -> bool:
        """
        Verify downloaded file integrity.
        
        Args:
            file_path: Path to file
            repo_id: Repository ID (to fetch expected hash)
            filename: Filename (to fetch expected hash)
            expected_sha256: Expected SHA256 hash
        
        Returns:
            True if verification passes
        
        Raises:
            VerificationError: If verification fails
        """
        self.logger.info(f"Verifying {file_path.name}")
        
        if not file_path.exists():
            raise VerificationError(f"File not found: {file_path}")
        
        # Get expected hash if not provided
        if not expected_sha256 and repo_id and filename and HF_HUB_AVAILABLE:
            try:
                api = HfApi(token=self.token)
                # Note: This is a simplified approach
                # In practice, you'd need to get the commit info
            except:
                pass
        
        # Calculate hash
        sha256_hash = hashlib.sha256()
        
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256_hash.update(chunk)
        
        calculated_hash = sha256_hash.hexdigest()
        
        if expected_sha256 and calculated_hash != expected_sha256:
            raise VerificationError(
                f"Hash mismatch for {file_path.name}: "
                f"expected {expected_sha256}, got {calculated_hash}"
            )
        
        self.logger.info(f"Verification passed for {file_path.name}")
        return True
    
    def delete_model(self, file_path: Union[str, Path]) -> bool:
        """
        Delete a downloaded model.
        
        Args:
            file_path: Path to model file
        
        Returns:
            True if deleted successfully
        """
        file_path = Path(file_path)
        
        try:
            if file_path.exists():
                file_path.unlink()
                self.logger.info(f"Deleted {file_path}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Failed to delete {file_path}: {e}")
            return False
    
    def list_downloaded_models(self) -> List[Dict[str, Any]]:
        """
        List all downloaded models in cache directory.
        
        Returns:
            List of model information dictionaries
        """
        models = []
        
        for file_path in self.cache_dir.glob("*.gguf"):
            stat = file_path.stat()
            models.append({
                "name": file_path.name,
                "path": str(file_path),
                "size_bytes": stat.st_size,
                "size_gb": stat.st_size / (1024 ** 3),
                "modified": stat.st_mtime,
            })
        
        return sorted(models, key=lambda x: x["modified"], reverse=True)
    
    def get_model_path(self, model_name: str) -> Optional[Path]:
        """
        Get path to a downloaded model by name.
        
        Args:
            model_name: Model filename
        
        Returns:
            Path to model if found, None otherwise
        """
        model_path = self.cache_dir / model_name
        if model_path.exists():
            return model_path
        
        # Try to find by partial match
        for file_path in self.cache_dir.glob("*.gguf"):
            if model_name in file_path.name:
                return file_path
        
        return None
    
    def _notify_progress(self, progress: DownloadProgress) -> None:
        """Notify all progress callbacks."""
        for callback in self._progress_callbacks:
            try:
                callback(progress)
            except Exception as e:
                self.logger.debug(f"Progress callback error: {e}")
    
    def cleanup_cache(self, max_age_days: int = 30) -> int:
        """
        Clean up old model files from cache.
        
        Args:
            max_age_days: Maximum age in days
        
        Returns:
            Number of files deleted
        """
        import time
        
        deleted_count = 0
        cutoff_time = time.time() - (max_age_days * 24 * 60 * 60)
        
        for file_path in self.cache_dir.glob("*.gguf"):
            if file_path.stat().st_mtime < cutoff_time:
                try:
                    file_path.unlink()
                    deleted_count += 1
                    self.logger.info(f"Cleaned up old model: {file_path.name}")
                except Exception as e:
                    self.logger.error(f"Failed to delete {file_path}: {e}")
        
        return deleted_count


def download_model(
    repo_id: str,
    filename: str,
    cache_dir: str = "./models",
    **kwargs,
) -> Path:
    """Convenience function for downloading a model."""
    downloader = ModelDownloader(cache_dir=cache_dir)
    return downloader.download(repo_id, filename, **kwargs)
